require('../settings/settings')
const fs = require('fs')

module.exports.detected = async (detect, vreyn, update) => {
  try {
    const groupMetadata = await vreyn.groupMetadata(update.id)
    const participants = await groupMetadata.participants
    const groupAdmins = await participants.filter((v) => v.admin !== null).map((i) => i.jid)
    const groupMembers = groupMetadata.participants
    if (detect) {
            const groupId = update.id
            const member = groupMembers.find(m => m.lid === update.author)
            const admin = member ? member.jid. : update.author
            const templates = {
                subject: `*@${admin.replace(/[^0-9]/g, '')}* telah mengubah nama grup menjadi @subject. Sesuatu dalam ruangan ini berubah.`,
                inviteCode: `*@${admin}* telah mereset tautan undangan grup: https://chat.whatsapp.com/@inviteCode. Gerbang dibuka kembali untuk yang berani.`,
                announceOn: `*@${
    admin.replace(/[^0-9]/g, '')
  }* telah menutup grup: hanya admin yang dapat mengirim pesan. Suara-suara biasa kini dibungkam.`,
                announceOff: `*@${
    admin.replace(/[^0-9]/g, '')
  }* telah membuka grup: semua peserta dapat mengirim pesan. Keramaian kembali menggema, untuk saat ini.`,
                restrictOn: `*@${
    admin.replace(/[^0-9]/g, '')
  }* telah membatasi perubahan info grup: hanya admin yang bisa mengubah. Rahasia grup kini dikunci.`,
                restrictOff: `*@${
    admin.replace(/[^0-9]/g, '')
  }* telah mengizinkan semua peserta mengubah info grup. Batas-batas dicabut, sesaat.`,
                memberOn: `*@${
    admin.replace(/[^0-9]/g, '')
  }* telah mengizinkan penambahan anggota ke grup. Jiwa-jiwa baru dapat masuk.`,
                memberOff: `*@${
    admin.replace(/[^0-9]/g, '')
  }* telah menonaktifkan penambahan anggota ke grup. Gerbang tertutup.`,
                aprovalOn: `*@${
    admin.replace(/[^0-9]/g, '')
  }* telah mengaktifkan persetujuan untuk bergabung ke grup. Tidak semua yang mengetuk akan diterima.`,
                aprovalOff: `*@${
    admin.replace(/[^0-9]/g, '')
  }* telah menonaktifkan persetujuan untuk bergabung ke grup. Siapa pun kini dapat bergabung.`
            }

            const makeText = (key, val = '') => {
                const template = templates[key]
                return val ? template.replace(`@${key}`, val) : template
            }

            let text = ''

            if ('subject' in update) text = makeText('subject', update.subject)
            else if ('inviteCode' in update) text = makeText('inviteCode', update.inviteCode)
            else if ('announce' in update) text = makeText(update.announce ? 'announceOn' : 'announceOff')
            else if ('restrict' in update) text = makeText(update.restrict ? 'restrictOn' : 'restrictOff')
            else if ('memberAddMode' in update) text = makeText(update.memberAddMode ? 'memberOn' : 'memberOff')
            else if ('joinApprovalMode' in update) text = makeText(update.joinApprovalMode ? 'aprovalOn' : 'aprovalOff')
            

            if (text) {
                await vreyn.sendTextWithMentions(update.id, text, null);
            }
        }
    } catch (err) {
        console.error('[❌ ERROR groups.update]', err)
    }
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`)
  delete require.cache[file]
  require(file)
})