require('../settings/settings')
const { generateWAMessageFromContent, generateWAMessage, prepareWAMessageMedia, downloadContentFromMessage, InteractiveMessage, proto, delay
} = require(viewserc)
const axios = require('axios')
const chalk = require('chalk')
const fs = require('fs')
const FileType = require('file-type')
const nou = require('node-os-utils')
const os = require('os')
const path = require('path')
let setting = JSON.parse(fs.readFileSync('./config-db-set.json'));

module.exports.welcome = async (detect, iswel, isleft, vreyn, anu) => {
  try {
    const { getInput, notifGroup } = require('../data-utils/scrape')
    const metadata = await vreyn.groupMetadata(anu.id)
    const participants = anu.participants
    const memeg = metadata.participants.length;
    const groupName = metadata.subject
    const groupDesc = metadata.desc
    const isWelcomeEnabled = global.db.data.chats[anu.id]?.wlcm;
    const isLeftEnabled = global.db.data.chats[anu.id]?.left;
    
    const welcomeType = setting.tipewelcome || "v1";
    
    let avatarUrl, ppgroup;
    const num = participants[0];
    const mentionedJid = [num].map(v => v + '@s.whatsapp.net');
    
    try {
      avatarUrl = await vreyn.profilePictureUrl(num, 'image');
    } catch {
      avatarUrl = 'https://telegra.ph/file/750ed3947ea3722c20b77.png';
    }
    
    try {
      ppgroup = await vreyn.profilePictureUrl(anu.id, 'image')
    } catch {
      ppgroup = 'https://telegra.ph/file/c3f3d2c2548cbefef1604.jpg'
    }
    
    const welcomeOptions = {
     backgroundURL: thumbwl,
     avatarURL: avatarUrl,
     title: '👁️ W E L C O M E 👁️',
     description: 'Langkahmu sudah terdengar… dan kini kau tidak bisa pergi. 🩸',
     gcnameinf: `🔪 Tempat Pembantaian (Grup) : ${groupName}`,
     poweredBot: `Dijalankan oleh bayangan... ${global.wmbotfo}`,
     gcmemberke: `🕯️ Korban ke : ${metadata.participants.length}`
    };
    
    const goodbyeOptions = {
     backgroundURL: thumbgb,
     avatarURL: avatarUrl,
     title: '💀 G O O D B Y E 💀',
     description: 'Satu jiwa pergi… tapi bisikannya masih bergema di dinding ini. 👁️‍🗨️',
     gcnameinf: `⚰️ Arena Kegelapan : ${groupName}`,
     poweredBot: `Masih bernafas... untuk sementara — ${global.wmbotfo}`,
     gcmemberke: `🩸 Korban yang tersisa : ${metadata.participants.length + 1}`
    };
    
    if (anu.action == 'add' && (iswel || isWelcomeEnabled)) {
      if (global.db.data.chats[anu.id]?.text_welcome) {
        var get_teks_welcome = global.db.data.chats[anu.id].text_welcome;
        var replace_pesan = (get_teks_welcome.replace(/@user/gi, `@${num.split('@')[0]}`));
        var full_pesan = (replace_pesan.replace(/@group/gi, metadata.subject).replace(/@desc/gi, metadata.desc));
      } else {
        var full_pesan = `Welcome @${num.split('@')[0]}\nTo Group : ${groupName}`;
      }
      
      if (welcomeType === "v1") {
        const wlcmnotif = await notifGroup(welcomeOptions);
        const buttons = [
          { buttonId: `ppp`, buttonText: { displayText: '👁️ W E L C O M E 👁️' }, type: 1 }
        ];
        if (!mentionedJid.includes(num)) mentionedJid.push(num);
        vreyn.sendMessage(anu.id, {
          image: wlcmnotif,
          caption: full_pesan,
          footer: wm,
          buttons: buttons,
          contextInfo: {
            mentionedJid: mentionedJid,
            forwardingScore: 9999999,
            isForwarded: true
          },
          headerType: 1,
          viewOnce: true
        }, { quoted: null })
      } 
      else if (welcomeType === "v2") {
        if (!mentionedJid.includes(num)) mentionedJid.push(num);
        vreyn.sendMessage(anu.id, {
          text: full_pesan,
          contextInfo: {
            mentionedJid: mentionedJid,
            externalAdReply: {
              title: `👁️ W E L C O M E 👁️'`,
              body: `${botname}`,
              thumbnailUrl: ppgroup,
              sourceUrl: "https://whatsapp.com/channel/0029Vb6VXcz9RZATmwXt6n1F",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        });
      } 
      else if (welcomeType === "v3") {
        const wlcmnotif = await notifGroup(welcomeOptions);
        const buttons = [
          { buttonId: `ppp`, buttonText: { displayText: '👁️ W E L C O M E 👁️' }, type: 1 },
          { buttonId: `.intro`, buttonText: { displayText: 'Intro' }, type: 1 }
        ];
        if (!mentionedJid.includes(num)) mentionedJid.push(num);
        vreyn.sendMessage(anu.id, {
          image: wlcmnotif,
          caption: full_pesan,
          footer: wm,
          buttons: buttons,
          contextInfo: {
            mentionedJid: mentionedJid,
            forwardingScore: 9999999,
            isForwarded: true
          },
          headerType: 1,
          viewOnce: true
        }, { quoted: null });
      }
    }
    
    if (anu.action == 'remove' && (isleft || isLeftEnabled)) {
      if (global.db.data.chats[anu.id]?.text_left) {
        var get_teks_left = global.db.data.chats[anu.id].text_left;
        var replace_pesan = (get_teks_left.replace(/@user/gi, `@${num.split('@')[0]}`));
        var full_pesan = (replace_pesan.replace(/@group/gi, metadata.subject).replace(/@desc/gi, metadata.desc));
      } else {
        var full_pesan = `Goodbye @${num.split('@')[0]}\nTo Group ${groupName}`;
      }
      
      if (welcomeType === "v1") {
        const leftnotif = await notifGroup(goodbyeOptions);
        const buttonns = [
          { buttonId: `welcom`, buttonText: { displayText: '💀 G O O D B Y E 💀' }, type: 1 }
        ];
        if (!mentionedJid.includes(num)) mentionedJid.push(num);
        vreyn.sendMessage(anu.id, {
          image: leftnotif,
          caption: full_pesan,
          footer: wm,
          buttons: buttonns,
          contextInfo: {
            mentionedJid: mentionedJid,
            forwardingScore: 9999999,
            isForwarded: true
          },
          headerType: 1,
          viewOnce: true
        }, { quoted: null });
      } 
      else if (welcomeType === "v2") {
        if (!mentionedJid.includes(num)) mentionedJid.push(num);
        vreyn.sendMessage(anu.id, {
          text: full_pesan,
          contextInfo: {
            mentionedJid: mentionedJid,
            externalAdReply: {
              title: `💀 G O O D B Y E 💀`,
              body: `${botname}`,
              thumbnailUrl: ppgroup,
              sourceUrl: "https://whatsapp.com/channel/0029Vb6VXcz9RZATmwXt6n1F",
              mediaType: 1,
              renderLargerThumbnail: true
            }
          }
        });
      } 
      else if (welcomeType === "v3") {
        const leftnotif = await notifGroup(goodbyeOptions);
        const buttonns = [
          { buttonId: `welcom`, buttonText: { displayText: '💀 G O O D B Y E 💀' }, type: 1 },
          { buttonId: `welcom`, buttonText: { displayText: 'Satu jiwa pergi… tapi bisikannya masih bergema di dinding ini. 👁️‍🗨️' }, type: 1 }
        ];
        if (!mentionedJid.includes(num)) mentionedJid.push(num);
        vreyn.sendMessage(anu.id, {
          image: leftnotif,
          caption: full_pesan,
          footer: wm,
          buttons: buttonns,
          contextInfo: {
            mentionedJid: mentionedJid,
            forwardingScore: 9999999,
            isForwarded: true
          },
          headerType: 1,
          viewOnce: true
        }, { quoted: null });
      }
    }
    
if (detect) {
  if (anu.action === 'promote' || anu.action === 'demote') {
    console.log(anu)
    const isPromote = anu.action === 'promote';
    const groupMetadata = await vreyn.groupMetadata(anu.id)
    const groupMembers = groupMetadata.participants

    const adminMember = groupMembers.find(m => m.lid === anu.author);
    const admin = adminMember ? (adminMember.jid) : anu.author;

    for (let participant of anu.participants) {
    
      const targetMember = groupMembers.find(m => m.lid === participant);
      const target = targetMember ? (targetMember.jid) : participant;

      const actionText = isPromote
        ? `@${admin.split('@')[0]} Telah mempromosikan @${target.split('@')[0]} *menjadi admin*`
        : `@${admin.split('@')[0]} Telah menurunkan @${target.split('@')[0]} *dari admin*`;

      const teks = `${actionText}\n📍 Dari group: *${groupMetadata.subject}*`;

      await vreyn.sendTextWithMentions(anu.id, teks, null);
    }
  }
}
    
  } catch (err) {
    console.error(err);
  }
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`)
  delete require.cache[file]
  require(file)
})