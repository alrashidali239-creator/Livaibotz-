const fs = require('fs')

// =================== [ MESSAGE SETTINGS ] ===================
global.mess = {
  owner: "*Hehehe... cuma sang pemilik yang boleh pakai perintah ini... kau bukan dia, kan?*",
  prem: "*Hahaha... fitur ini hanya untuk mereka yang istimewa... yang sudah kuberi *hak istimewa*... bukan kau~*",
  grup: "*Hmm... tempat ini sepi... fitur ini hanya bisa kugunakan di tengah keramaian (grup)... bukan di sini...*",
  privat: "*Shhh... hanya di ruang rahasia (chat pribadi)... jangan coba-coba di sini... aku bisa marah~*",
  admin: "*Kau pikir bisa seenaknya? Hanya para penguasa grup (admin) yang boleh melakukannya... sisanya hanyalah pion...*",
  botadmin: "*Hahaha... aku belum jadi penguasa di sini (belum admin)... biarkan aku berkuasa dulu... baru kita mulai..*",
  op: "*Hehehe... hanya para yang *terpilih* (premium) bisa membuka rahasia ini... kau tidak cukup layak...*",
  or: "*Kau bukan salah satu dari para penjual jiwaku (reseller)... jadi jangan sentuh ini...*",
  ob: "*Hanya tuanku, sang pemilik bot, yang bisa memerintahku... kau hanyalah bayangan...*",
  oa: "*Hahaha... hanya para admin yang bisa bermain di sini... sisanya? jadi penonton saja~*"
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`)
  delete require.cache[file]
  require(file)
})