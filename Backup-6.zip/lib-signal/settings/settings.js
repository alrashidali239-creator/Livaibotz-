const fs = require('fs')
const pack = require('@root/package.json')
let setting = JSON.parse(fs.readFileSync('./config-db-set.json'))
// ================= [ PAIRING SETTINGS ] ================= //
global.pairing = false // false = pairing code | true = scan QR
global.paiCode = "LIVAIBOT" // Wajib 8 digit pairing code (custom)
global.broswer = "Firefox" // Server Browser 
// Browser Bisa Gunakan Opsi Lain, Tergantung Keamanan Privasi Kalian
// Chrome -- Paling Disaranin 
// Firefox -- Kalo Mau Ringan
// Edge
// Safari

global.viewserc = setting.servers

// ================= [ SYSTEM SETTINGS ] ================= //
global.runkeys = "luccane" // Custom Password Key
global.sessionName = "session" // Nama file session

// ================= [ BOT PROFILE SETTINGS ] ================= //
global.storename = "LuccaneXz Store" // Store name
global.botname = "𝕷𝖎𝖛𝖆𝖎𝕭𝖔𝖙𝖟 人工知能" // Bot name
global.ownername = "L-Desu" // Owner name
global.owner = "6283198520706" // Owner number
global.botNumber = "6283826148348" //  Bot number
global.version = pack.version // Version
global.pyvokzc = "S3cR3t!9" // User Id

global.packname = "𝕷𝖎𝖛𝖆𝖎𝕭𝖔𝖙𝖟 人工知能" // Sticker packname 
global.author = "𝕷𝖎𝖛𝖆𝖎𝕭𝖔𝖙𝖟 人工知能" // Sticker author

global.web = "https://whatsapp.com/channel/0029Vb6VXcz9RZATmwXt6n1F" // Home web
global.wm = "𝕷𝖎𝖛𝖆𝖎𝕭𝖔𝖙𝖟 人工知能" // Watermark thumbnail
global.wmbotfo = "𝕷𝖎𝖛𝖆𝖎𝕭𝖔𝖙𝖟 人工知能" // Pakai font default

// ================== [ ID & CHANNEL LINKS ] ================== //
global.chjid = "120363401873206748" // Channel Id Gaush pakai @
global.gcjid = "120363299084085584" // Group Id Gaush pakai @

global.sch = "https://whatsapp.com/channel/0029Vb6VXcz9RZATmwXt6n1F"
global.sgc = "https://chat.whatsapp.com/HM4hlpWZoX2G5rQ9USYlzi?mode=ems_copy_t"
global.stg = "-"
global.syt = "-"
global.sig = "https://instagram.com/ali.alshid"

// ================== [ MEDIA & REACTIONS ] ================== //
global.thumb = "https://files.catbox.moe/vh3dln.jpg" // Thumbnail bot utama 
global.thumb2 = "https://files.catbox.moe/vh3dln.jpg" // Thumbnail bot Opsional 
global.audiofetch = "https://files.catbox.moe/vh3dln.jpg" // Audio menu v6

global.thumbwl = "https://files.catbox.moe/vh3dln.jpg" // Background welcome
global.thumbgb = "https://files.catbox.moe/vh3dln.jpg" // Background goodbye
global.thumbpf = "https://files.catbox.moe/vh3dln.jpg" // Background profile
global.thumbwn = "https://files.catbox.moe/vh3dln.jpg" // Background owner profile 

global.reactload = "🔪" // React Messages 
global.vtampt = '`' // Don't change 
global.xvarc = "/" // Don't change 

global.vircsetz = ['☼', '✘', '✦', '✧', '❀', '○', '⏣', '♧', '々', '〆', '✎'] // Emoticon
global.swreact = ['😐', '🗿', '😮‍💨', '🥱', '😱', '😔', '🤔', '🫡'] // React Sw

// ================== [ BOT SEWA / RENTAL ] ================== //
global.botsewa = {
  day5: "3000", // = 5k
  day10: "5000", // = 10k
  day15: "10000", // = 15k
  day30: "12000", // = 30 
  dayunli: "80000" // = 70k
}
global.vreyni = "150000" // Harga Script 

// ================== [ PAYMENT SETTINGS ] ================== //
global.payment = {
  dana: "083198520706", // Dana
  gopay: "089670041381", // Gopay
  ovo: "083198520706", // Ovo
  rek: "-", // Rekening 
  qris: "https://files.catbox.moe/eoh9fq.jpg", // Qris url
  linkaja: "-", // LinkAja
  shopeepay: "-" // ShopeePay
}

// =================== [ SAWERIA ] =================== //
global.sw = {
  email: "luccanekaivanadmaja@gmail.com",
  password: "",
  username: ""
}

// ===================== [ - ] ====================== //

global.ssclear = true
// Ubah ke true buat auto clear sesi

global.localweb = false
// Ubah ke true jika ingin menghidupkan localhost web

// SISANYA LU BISA SETTING DI CONFIG-DB-SET.JSON

// =============== [ STATUS SEND FUNCTION ] ================ //
global.sendsq = (a, b) => {
  return {
    key: {
      remoteJid: 'status@broadcast',
      participant: '0@s.whatsapp.net'
    },
    message: {
      orderMessage: {
        itemCount: 1000,
        status: 1,
        surface: 1,
        message: a,
        orderTitle: '',
        thumbnail: b,
        sellerJid: '0@s.whatsapp.net'
      }
    }
  }
}

// ================= [ AUTO RELOAD CONFIG ] ================= //
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`)
  delete require.cache[file]
  require(file)
})