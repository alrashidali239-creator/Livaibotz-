
thumbnail1.jpg menggunakan ukuran foto 480x480
// Digunakan Di menu utama

thumbnail2.jpg meggunakan ukuran foto 480x169
// Digunakan Di menu v5

untuk thumb.mp4 hanya digunakan di setmenu type 6 (Menu Gif)
// Max ukuran video thumb.mp4 5mb, ga di sarankan lebih,
 biar menunya ga delay