const fs = require("fs");
const path = require("path");
const pluginsFolderPath = './plugin';

let handler = async (m, { vreyn, prefix, command }) => {
  try {
    const pluginFiles = fs.readdirSync(pluginsFolderPath).filter(file => file.endsWith(".js"));
    if (pluginFiles.length === 0) {
      return m.reply("Tidak ada file plugin ditemukan di folder plugin.");
    }

    let totalHandlerCommands = 0;
    let totalCaseCommands = 0;

    for (const file of pluginFiles) {
      const filePath = path.join(pluginsFolderPath, file);
      const fileContent = fs.readFileSync(filePath, "utf8");

      const commandMatches = fileContent.match(/handler\.command\s*=\s*\[([^\]]+)\]/);
      if (commandMatches) {
        const commands = commandMatches[1]
          .split(',')
          .map(cmd => cmd.trim().replace(/['"]/g, ''))
          .filter(cmd => cmd.length > 0);
        totalHandlerCommands += commands.length;
      }

      const caseMatches = fileContent.match(/(?<!\/\/)(case\s+['"][^'"]+['"])/g) || [];
      totalCaseCommands += caseMatches.length;
    }

    const countCasesInFile = (filepath) => {
      try {
        const content = fs.readFileSync(filepath, 'utf8');
        return (content.match(/(?<!\/\/)(case\s+['"][^'"]+['"])/g) || []).length;
      } catch (err) {
        console.error('Error membaca file:', filepath, err);
        return 0;
      }
    };

    const totalCasesvreyn = countCasesInFile('./vreyn.js');
    const totalTsCasesvreyn = countCasesInFile('./tsconfig/vreyn.ts');
    const totalFeaturePlugin = totalHandlerCommands + totalCaseCommands;
    const totalFeaturesAll = totalFeaturePlugin + totalCasesvreyn + totalTsCasesvreyn

    if (totalFeaturePlugin > 0 || totalCasesvreyn > 0) {
      try {
        await vreyn.sendMessage(m.chat, {
           pollResultMessage: {
               name: `*Total Feature List*\n*Total Semua Feature : ${totalFeaturesAll}*`, 
                   pollVotes: [
                    {
                       optionName: "Total Feature Plugin JS",
                       optionVoteCount: totalFeaturePlugin
                    },
                    {
                       optionName: "Total Feature Case JS",
                       optionVoteCount: totalCasesvreyn
                    },
                    {
                       optionName: "Total Feature Case TS",
                       optionVoteCount: totalTsCasesvreyn
                    }
               ]
           } 
        }, { quoted: m })

      } catch (err) {
        await m.reply(`
*Total Feature Plugin JS :* ${totalFeaturePlugin}
*Total Feature Case JS :* ${totalCasesvreyn}
*Total Feature Case TS :* ${totalTsCasesvreyn}

*Total Semua Feature :* ${totalFeaturesAll}

> ${global.botname}`);
      }
    } else {
      m.reply("Gagal Mendeteksi fitur apapun...");
    }
  } catch (err) {
    console.error(err);
    m.reply("Terjadi kesalahan: " + err.message);
  }
};

handler.help = ["totalfeature"];
handler.tags = ["plugin"];
handler.command = ["totalplug", "fitur", "totalfunct", "totalfunction", "totalcase", "totalplugin", "totalpl", "ttf", "totalfitur", "totalfeature"];

module.exports = handler;