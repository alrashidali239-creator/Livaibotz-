const fs = require("fs");
const path = require("path");

const pluginsFolderPath = './plugin';

let handler = async (m, { vreyn, isOwner, prefix, command, text }) => {
  if (!isOwner) return m.reply("Fitur ini hanya tersedia untuk pemilik bot.")
  let t = text.split(' ');
  const pluginName = t[0];

  if (!pluginName) {
    return m.reply(`*Format salah!*\nPenggunaan: ${prefix + command} nama_file\n\nContoh: ${prefix + command} ex_plugin`);
  }

  if (!m.quoted || !m.quoted.text) {
    return m.reply(`Harap balas pesan dengan kode plugin setelah menggunakan perintah ${prefix + command}`);
  }

  const pluginCode = m.quoted.text.trim();

  const pluginFilePath = path.join(pluginsFolderPath, pluginName + '.js');

  try {

    fs.writeFileSync(pluginFilePath, pluginCode);
    m.reply(`Plugin ${pluginName}.js telah berhasil ditambahkan ke folder plugins.\nSilahkan Restart Untuk Memulai Perubahan`);
  } catch (err) {
    m.reply(`Gagal menambahkan plugin ${pluginName}: ${error.message}`);
  }
};

handler.help = ["addplug"];
handler.tags = ["owner"];
handler.command = ["addplug", "addplugin", "addpg", "pluginadd", "pgadd", "plugin", "tambahplugin", "tambahplug", "buatplugin", "createplugin", "newplugin", "pluginbaru", "installplugin", "uplplugin", "uploadplugin", "applugin", "addplg"]

module.exports = handler;
