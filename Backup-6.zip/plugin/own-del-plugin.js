const fs = require("fs");
const path = require("path");

const pluginsFolderPath = './plugin';

let handler = async (m, { vreyn, isOwner, prefix, command, text }) => {
  if (!isOwner) return m.reply("Fitur ini hanya tersedia untuk pemilik bot.")

  let t = text.split(' ');

  if (t.length < 1) {
    return m.reply(`*Format salah!*\nPenggunaan: ${prefix + command} nama plugins\n\nUntuk menghapus plugin, gunakan format: ${prefix + command} nama_plugin`);
  }

  const pluginName = t[0];

  const availablePlugins = getAvailablePlugins();

  if (!availablePlugins.includes(pluginName)) {
    return m.reply(`Plugin tidak ditemukan. Berikut adalah daftar plugin yang tersedia:\n\n${availablePlugins.join("\n")}`);
  }

  const pluginFilePath = path.join(pluginsFolderPath, pluginName + '.js');

  try {
    fs.unlinkSync(pluginFilePath); 
    m.reply(`Plugin ${pluginName} telah berhasil dihapus.\nSilahkan Restart Bot Untuk Perubahan`);
  } catch (error) {
    m.reply(`Gagal menghapus plugin ${pluginName}: ${error.message}`);
  }
};

function getAvailablePlugins() {
  const pluginFiles = fs.readdirSync(pluginsFolderPath);
  return pluginFiles.filter(file => file.endsWith(".js")).map(file => file.replace(".js", ""));
}

handler.help = ["deleteplugin"];
handler.tags = ["owner"];
handler.command = ["dp", "delplug", "delplugin", "delpg", "dpug", "deleteplugin", "deleteplug", "removeplugin", "removeplug", "hapusplugin", "hapusplug", "uninstallplugin", "uninstallplug", "rmplugin", "rmplug", "delplg", "delp", "deletepg"]

module.exports = handler;
