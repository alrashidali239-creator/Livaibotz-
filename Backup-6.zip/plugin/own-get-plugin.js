const fs = require("fs");
const path = require("path");

const pluginsFolderPath = './plugin';

function readJSFiles(folderPath) {
  let pluginCodes = [];

  try {
    const files = fs.readdirSync(folderPath);

    files.forEach((file) => {
      const filePath = path.join(folderPath, file);
      const stat = fs.statSync(filePath);

      if (stat.isDirectory()) {
        pluginCodes = pluginCodes.concat(readJSFiles(filePath));
      } else {
        if (path.extname(file) === '.js') {
          const code = fs.readFileSync(filePath, 'utf-8');
          pluginCodes.push(`*Get Plugin ${file}*\n\n\`\`\`${code}\`\`\`\n\n`);
        }
      }
    });
  } catch (error) {
    console.error("Terjadi kesalahan saat membaca folder:", error.message);
  }

  return pluginCodes;
}

let handler = async (m, { vreyn, isOwner, prefix, command, text }) => {
  if (!isOwner) return m.reply("Fitur ini hanya tersedia untuk pemilik bot.")

  let t = text.split(' ');

  if (t.length < 1) {
    return m.reply(`*Format salah!*\nPenggunaan: ${prefix + command} nama plugins\n\nPLUGINS YANG TERSEDIA:\n${getAvailablePlugins()}`);
  }

  const pluginName = t[0];

  const pluginCodes = readJSFiles(pluginsFolderPath);

  if (pluginCodes.length === 0) {
    return m.reply("Tidak ada file plugin yang ditemukan di folder.");
  }

  const availablePlugins = getAvailablePlugins();

  if (!availablePlugins.includes(pluginName)) {
    return m.reply(`Plugin tidak ditemukan. Berikut adalah daftar plugin yang tersedia:\n\n${availablePlugins.join("\n")}`);
  }

  const pluginCode = pluginCodes.find(code => code.includes(pluginName));
  return m.reply(`Isi plugin:\n\n${pluginCode}`);
};

function getAvailablePlugins() {
  const pluginFiles = fs.readdirSync(pluginsFolderPath);
  return pluginFiles.filter(file => file.endsWith(".js")).map(file => file.replace(".js", ""));
}

handler.help = ["getplugin"];
handler.tags = ["owner"];
handler.command = ["gp", "getplug", "getplugin", "ambilplug", "ambilplugin", "ambilpg", "fetchplugin", "fetchplug", "downloadplugin", "downloadplug", "dlplugin", "dlplug", "ambilplg", "getpg", "pluginget", "pgget"]

module.exports = handler;
