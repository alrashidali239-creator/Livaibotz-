let fs = require('fs')

let handler = async (m, { vreyn, text, args, isOwner, command, prefix }) => {
if (!text) return m.reply(`*Example*: ${prefix + command} @tag/number tools/alkitab.js`)
let who;
try {
if (!isOwner) return m.reply('Khusus owner!!')
if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted.sender } catch (err) {
if (m.isGroup) who = args[0] + "@s.whatsapp.net"
}
if (!who) return m.reply(`tag/number ! ! !`)
if (!args[1]) return m.reply(`plugin (name)`)
const isValid = await clientx.onWhatsApp(q + "@s.whatsapp.net");
if (isValid.length == 0) {
return m.reply("Number not in whatsapp!");
 }
var user_bot = await fs.readFileSync(`./plugin/${args[1]}.js`)
clientx.sendMessage(who, {
document: user_bot,
caption: 'Get - Plugins',
mimetype: 'document/application',
fileName: `${args[1]}`
})
m.reply('Success sending file to :' + args[0])
}

handler.help = ["sendplugin"]
handler.tags = ["owner"]
handler.command = ["sendplugin", "sendplug", "send-plugin", "send-plug", "kirimplugin", "kirimplugin", "kirim-plugin", "kirim-plug", "uploadplug", "uploadplugin", "uplplug", "uplplugin", "shareplugin", "shareplug", "pluginshare", "bagiplugin", "bagiplug", "spg", "splg"]

module.exports = handler;