const saldoplus = 1;
const fs = require('fs')
let setting = JSON.parse(fs.readFileSync('./config-db-set.json'));

let handler = async (m, { vreyn, command, args }) => {
  if (setting.rpgsetStats) return m.reply('Fitur rpg dimatikan oleh owner')
  if (!db.data.users[m.sender] || !db.data.users[m.sender].rpg) return m.reply('Kamu belum join RPG')

  let suffix = command.replace(/^atm/i, "").trim();

  let count;

  if (suffix) {
    if (/^all$/i.test(suffix) || /^all$/i.test(args[0])) {
      count = Math.floor(global.db.data.users[m.sender].bank / saldoplus);
    } else {
      let raw = args[0] ? args[0] : suffix;
      count = Math.floor(Number(raw));
    }
  } else if (args[0]) {
    if (/^all$/i.test(args[0])) {
      count = Math.floor(global.db.data.users[m.sender].bank / saldoplus);
    } else {
      count = Math.floor(Number(args[0]));
    }
  } else {
    count = 1;
  }

  if (!Number.isFinite(count) || isNaN(count)) {
    return m.reply('Jumlah tidak valid. Masukkan angka yang benar atau gunakan "all". Contoh: atm 5 atau atm all');
  }

  count = Math.max(1, Math.floor(count));

  const userBank = global.db.data.users[m.sender].bank || 0;

  if (userBank >= saldoplus * count) {
    if (!global.db.data.erpg) global.db.data.erpg = {};
    if (!global.db.data.erpg[m.sender]) global.db.data.erpg[m.sender] = { saldo: 0 };

    global.db.data.users[m.sender].bank -= saldoplus * count;
    global.db.data.erpg[m.sender].saldo += count;

    m.reply(`-${saldoplus * count} saldo\n+${count} ATM`);
  } else {
    const maxCanSave = Math.floor(userBank / saldoplus);
    if (maxCanSave <= 0) {
      return m.reply(`Saldo kamu tidak mencukupi untuk menabung.`);
    }
    return m.reply(`Saldo tidak mencukupi untuk menabung ${count} ATM. Kamu bisa menabung maksimal ${maxCanSave} ATM.`);
  }
};

handler.help = ["atm", "atmpull", "atmwithdraw", "atmambil", "atmkeluar", "atm-tarik", "atmkeluarin", "atm-cairkan", "atmtake", "atm-penarikan"];
handler.tags = ["rpg"];
handler.command = ["atm", "atmambil", "atmwithdraw", "atmpull", "atm-tarik", "atmkeluar", "atmtake", "atmkeluarin", "atm-cairkan", "atm-penarikan"];

module.exports = handler;