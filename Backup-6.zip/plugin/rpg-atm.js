const saldoplus = 1;
const fs = require('fs')
let setting = JSON.parse(fs.readFileSync('./config-db-set.json'));
let handler = async (m, { vreyn, command, args }) => {
  if (setting.rpgsetStats) return m.reply('Fitur rpg dimatikan oleh owner')
  if (!db.data.users[m.sender] || !db.data.users[m.sender].rpg) return m.reply('Kamu belum join RPG')
  let count = command.replace(/^atm/i, "");
  count = count
    ? /all/i.test(count)
      ? Math.floor(global.db.data.users[m.sender].saldo / saldoplus)
      : parseInt(count)
    : args[0]
      ? parseInt(args[0])
      : 1;
  count = Math.max(1, count);
  if (global.db.data.users[m.sender].saldo >= saldoplus * count) {
    global.db.data.users[m.sender].saldo -= saldoplus * count;
    global.db.data.erpg[m.sender].bank += count;
    m.reply(`-${saldoplus * count} saldo\n+ ${count} ATM`);
  } else
    m.reply(`saldo tidak mencukupi untuk menabung ${count} ATM`);
};
handler.help = ["atm", "atmall"];
handler.tags = ["rpg"];
handler.command = ["atm", "atmall"];

module.exports = handler;
