let fs = require("fs");
let setting = JSON.parse(fs.readFileSync('./config-db-set.json'));
let handler = async (m, { vreyn }) => {
 if (setting.rpgsetStats) return m.reply('Fitur rpg dimatikan oleh owner')
  if (!db.data.users[m.sender] || !db.data.users[m.sender].rpg) return m.reply('Kamu belum join RPG')
  let who;
  if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender;
  else who = m.sender;
  let anu;
  if (global.db.data.users[who]) {
    anu = `
🏦 Bank *${global.db.data.erpg[who].bank}*
*${global.db.data.users[who].exp}* Exp ✨
*${global.db.data.users[who].limit}* Limit 📊
*${global.db.data.users[who].saldo}* Money 💵`;
  } else {
    anu = `User tidak ditemukan`;
  }
  await vreyn.sendMessage(
    m.chat,
    {
      text: anu,
      contextInfo: {
        externalAdReply: {
          title: "ISI DOMPET",
          body: "info Dompet User Bot",
          thumbnailUrl: "https://telegra.ph/file/bb562cfd966da4ed5b81a.jpg",
          sourceUrl: "",
          mediaType: 1,
          renderLargerThumbnail: true,
        },
      },
    },
    { quoted: m },
  );
};

handler.help = ["dompet"];
handler.tags = ["rpg"];
handler.command = ["dompet"];

module.exports = handler;
