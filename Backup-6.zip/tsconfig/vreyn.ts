// @ts-nocheck

import fs from 'fs';
import path from 'path';
import axios from 'axios'
import * as cheerio from "cheerio";
import fetch from 'node-fetch'
import { pickRandom } from '../x-system/myfunc'
import { CatBox } from '../lib-signal/data-utils/scrape'

interface Message {
  chat: string;
  text: string;
  body: string;
  sender: string;
  isGroup: any;
  quoted?: any;
  msg?: {
    fileSha256?: Buffer;
    mimetype?: string;
  };
  args?: string[];
  command?: string;
  reply: (text: string) => void;
}

async function vreynHandler(
  vreyn: any,
  m: Message,
  chatUpdate: any,
  mek: any,
  store: any,
  prefix: any,
  command: any,
  version: any,
  ownername: any,
  botname: any,
  wm: any,
  db: any,
  p_c: any,
  isOwner: any,
  isAdmins: any,
  isPremium: any,
  text: any,
  mess: any,
  botNumber: any,
  quoted: any,
  mime: any,
  viewserc: any,
  reactload: any
): Promise<void> {
  
    const onlyOwn = () => {
      m.reply(mess.owner)
    }
    const onlyPrem = () => {
      m.reply(mess.prem)
    }
    const onlyGrup = () => {
      m.reply(mess.grup)
    }
    const onlyPrivat = () => {
      m.reply(mess.privat)
    }
    const onlyAdmin = () => {
      m.reply(mess.admin)
    }
    const onlyBotAdmin = () => {
      m.reply(mess.botadmin)
    }
    const onlyOp = () => {
      m.reply(mess.op)
    }
    const onlyOr = () => {
      m.reply(mess.or)
    }
    const onlyOb = () => {
      m.reply(mess.ob)
    }
    const onlyOa = () => {
      m.reply(mess.oa)
    }
    let body = m.body
    const args = body.trim().split(/ +/).slice(1)
    const more = String.fromCharCode(8206)
    const readMore = more.repeat(4001)
    
    async function xreact() {
      vreyn.sendMessage(from, {
        react: {
          text: reactload,
          key: m.key
        }
      })
    }

  switch (command) {
    case 'tests': {
      m.reply(`typescript`);
    }
    break;

    case 'botinformation':
    case 'botinfo':
    case 'infobot': {
      try {
        const pluginsFolderPath = './plugin';
        const pluginFiles = fs.readdirSync(pluginsFolderPath).filter((file: string) => file.endsWith('.js'));

        if (pluginFiles.length === 0) {
          return m.reply("Tidak ada file plugin ditemukan di folder plugin.");
        }

        let totalHandlerCommands = 0;
        let totalCaseCommands = 0;

        for (const file of pluginFiles) {
          const filePath = path.join(pluginsFolderPath, file);
          const fileContent = fs.readFileSync(filePath, 'utf-8');

          const commandMatches = fileContent.match(/handler\.command\s*=\s*([^]+)/);
          if (commandMatches) {
            const commands = commandMatches[1]
              .split(',')
              .map((cmd: string) => cmd.trim().replace(/['"]/g, ''))
              .filter((cmd: string) => cmd.length > 0);
            totalHandlerCommands += commands.length;
          }

          const caseMatches = fileContent.match(/(?<!\/\/)(case\s+['"][^'"]+['"])/g) || [];
          totalCaseCommands += caseMatches.length;
        }

        const countCasesInFile = (filepath: string): number => {
          try {
            const content = fs.readFileSync(filepath, 'utf-8');
            return (content.match(/(?<!\/\/)(case\s+['"][^'"]+['"])/g) || []).length;
          } catch (err) {
            console.error('Error membaca file:', filepath, err);
            return 0;
          }
        };

        const totalCasesvreyn = countCasesInFile('./vreyn.js');
        const totalFeaturePlugin = totalHandlerCommands + totalCaseCommands;
        const totalFeaturesAll = totalFeaturePlugin + totalCasesvreyn;

        if (totalFeaturePlugin > 0 || totalCasesvreyn > 0) {
          m.reply(`
*INFORMASI BOT*

Bot Name: ${botname}
Owner Name: ${ownername}
Type: (case × plugin)
Prefix: Multi Prefix
Total Fitur Plugin: ${totalFeaturePlugin}
Total Fitur Case: ${totalCasesvreyn}
Total Semua Fitur: ${totalFeaturesAll}
Total error: Nothing
Versi: ${version}
Total user: ${Object.values(db.data.users).length} Users
          `);
        } else {
          m.reply("Gagal Mendeteksi...");
        }
      } catch (err) {
        console.error(err);
        m.reply((err as Error).toString());
      }
    }
      break;

    case 'channelcreate':
    case 'chcreate':
    case 'createchannel':
    case 'createch': {
      if (!isOwner) return onlyOwn()

      if (!text.includes(',')) {
        return m.reply(`Masukkan nama dan deskripsi channel dengan format:\n${p_c} Nama Channel, Deskripsi opsional`);
      }

      let [name, ...descParts] = text.split(',');
      let description = descParts.join(',').trim() || '';

      try {
        let data = await vreyn.newsletterCreate(name.trim(), description, "ALL");
        let chlink = `https://whatsapp.com/channel/${data.invite}`;
        m.reply(`Berhasil membuat channel!\n\n*Nama:* ${data.name}\n*Deskripsi:* ${data.description || 'Tidak ada'}\n\n*Link channel:*\n${chlink}`);
      } catch (e) {
        console.error(e);
        m.reply('Gagal membuat channel. Pastikan akunmu bisa membuat channel dan coba lagi nanti.');
      }
    }
      break;
      
      case 'channeljoin':
      case 'joinchannel':
      case 'chjoin':
      case 'joinch': {
      if (!isOwner) return onlyOwn()
      if (!text) return m.reply(`Masukkan link!! contoh ${p_c} linknya`)
      if (!args[0].includes('whatsapp.com/channel/')) return m.reply('Harus berupa link channel WhatsApp!')

    let result = args[0].split('https://whatsapp.com/channel/')[1]
    let data = await vreyn.newsletterMetadata("invite", result)

    await vreyn.newsletterFollow(data.id)
    await vreyn.sendMessage(m.chat, {
        text: 'Sukses join ke channel.'
    }, { quoted: m })
    }
    break
    
    case 'begimanakah':
    case 'bagaimana':
    case 'bagaimanakah': {
    if (!text) return m.reply(`Penggunaan ${p_c} text\n\nContoh : ${p_c} cara mengatasi sakit hati`)
    const gimana = ['Gak Gimana2', 'Sulit Itu Bro', 'Maaf Bot Tidak Bisa Menjawab', 'Coba Deh Cari Di Gugel', 'astaghfirallah Beneran???', 'Pusing ah', 'Owhh Begitu:(', 'Gimana yeee']
    const ya = gimana[Math.floor(Math.random() * gimana.length)]
    m.reply(`Pertanyaan : Bagaimanakah ${text}\nJawaban : ${ya}`)
    }
    break
    
    case 'rating':
    case 'nilai':
    case 'rate': {
    if (!text) return m.reply(`Penggunaan ${p_c} text\n\nContoh : ${p_c} Gambar aku`)
    const ra = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
    const te = ra[Math.floor(Math.random() * ra.length)]
    m.reply(`Rate : ${text}\nJawaban : *${te}%*`)
    }
    break
    
    case 'wangi':
    case 'wangyy':
    case 'wangy': {
    if (!text) return m.reply(`Contoh: ${p_c} nama seseorang atau tag`)
    let qq = m.mentionedJid[0] 
  ? m.mentionedJid[0].replace(/[^0-9]/g, '') 
  : m.quoted 
    ? m.quoted.sender.replace(/[^0-9]/g, '') 
    : ''
    let teks = `@${qq} @${qq} @${qq} ❤️ ❤️ ❤️ WANGY WANGY WANGY WANGY HU HA HU HA HU HA, aaaah baunya rambut @${qq} wangyy aku mau nyiumin aroma wangynya @${qq} AAAAAAAAH ~ Rambutnya.... aaah rambutnya juga pengen aku elus-elus ~~ AAAAAH @${qq} keluar pertama kali di anime juga manis ❤️ ❤️ ❤️ banget AAAAAAAAH @${qq} AAAAA LUCCUUUUUUUUUUUUUUU............ @${qq} AAAAAAAAAAAAAAAAAAAAGH ❤️ ❤️ ❤️apa ? @${qq} itu gak nyata ? Cuma HALU katamu ? nggak, ngak ngak ngak ngak NGAAAAAAAAK GUA GAK PERCAYA ITU DIA NYATA NGAAAAAAAAAAAAAAAAAK PEDULI BANGSAAAAAT !! GUA GAK PEDULI SAMA KENYATAAN POKOKNYA GAK PEDULI. ❤️ ❤️ ❤️ @${qq} gw ... @${qq} di laptop ngeliatin gw, @${qq} .. kamu percaya sama aku ? aaaaaaaaaaah syukur ${q} aku gak mau merelakan @${qq} aaaaaah ❤️ ❤️ ❤️ YEAAAAAAAAAAAH GUA MASIH PUNYA @${qq} SENDIRI PUN NGGAK SAMA AAAAAAAAAAAAAAH`
	vreyn.sendTextWithMentions(m.chat, teks, m)
    }
    break
    
    case 'deviceinfo':
    case 'infodevice':
    case 'gdevice':
    case 'getdevice': {
    let { getDevice } = require(viewserc)
    const device = await getDevice(m.quoted ? m.quoted.id : m.key.id)
    m.reply(device)
    }
    break
    
    case 'tagme':
    case 'tagmy': {
    vreyn.sendTextWithMentions(m.chat, `@${m.sender.split`@`[0]}`, m)
    }
    break
    
    case 'hadir':
    case 'absen': {
    if (!m.isGroup) return onlyGrup()
    let id = m.chat
    vreyn.absen = vreyn.absen ? vreyn.absen : {}
    if (!(id in vreyn.absen)) return m.reply(`🚩 _*Tidak ada absen berlangsung digrup ini!*_\n\n*${prefix}mulaiabsen* - untuk memulai absen`)

    let absen = vreyn.absen[id]
    if (!Array.isArray(absen[1])) absen[1] = [] 
    if (typeof absen[2] !== 'string') absen[2] = '-' 
    
    const wasVote = absen[1].includes(m.sender)
    if (wasVote) return m.reply('🚩 *Kamu sudah absen!*')
    absen[1].push(m.sender)
    m.reply(`Done!`)
    let d = new Date
    let date = d.toLocaleDateString('id', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    })
    let list = absen[1].map((v, i) => `│ ${i + 1}. @${v.split`@`[0]}`).join('\n')
    m.reply(`*「 ABSEN 」*

Tanggal: ${date}
${absen[2]}

┌ *List absen:*
│ 
│ Total: ${absen[1].length}
${list}
│ 
└────

_${wm}_`)
    }
    break
    
    case 'listabsen':
    case 'absencek':
    case 'cekabsen': {
    if (!m.isGroup) return onlyGrup()
    let id = m.chat
    vreyn.absen = vreyn.absen ? vreyn.absen : {}
    if (!(id in vreyn.absen)) return m.reply(`🚩 _*Tidak ada absen berlangsung digrup ini!*_\n\n*${prefix}mulaiabsen* - untuk memulai absen`)

    let d = new Date
    let date = d.toLocaleDateString('id', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    })

    let absen = Array.isArray(vreyn.absen[id][1]) ? vreyn.absen[id][1] : []
    let description = typeof vreyn.absen[id][2] === 'string' ? vreyn.absen[id][2] : '-'

    let list = absen.map((v, i) => `│ ${i + 1}. @${v.split`@`[0]}`).join('\n')
    let teks = `*「 ABSEN 」*

Tanggal: ${date}
${description}

┌ *List absen:*
│ 
│ Total: ${absen.length}
${list}
│ 
└────

_${wm}_`
    vreyn.sendTextWithMentions(m.chat, teks, m)
    }
    break
    
    case 'hapusabsen':
    case 'deteleabsen':
    case 'delabsen': {
    if (!m.isGroup) return onlyGrup()
    if (!isAdmins) return onlyAdmin()
    let id = m.chat
    vreyn.absen = vreyn.absen ? vreyn.absen : {}
    if (!(id in vreyn.absen)) return m.reply(`🚩 _*Tidak ada absen berlangsung digrup ini!*_\n\n*${prefix}mulaiabsen* - untuk memulai absen`)
    delete vreyn.absen[id]
    m.reply(`Berhasil hapus absen!`)
    }
    break
    
    case 'startabsen':
    case 'mulaiabsen': {
    if (!m.isGroup) return onlyGrup()
    if (!isAdmins) return onlyAdmin()
    vreyn.absen = vreyn.absen ? vreyn.absen : {}
    let id = m.chat
    if (id in vreyn.absen) {
    return m.reply(`🚩 _*Masih ada absen di chat ini!*_\n\n*${prefix}hapusabsen* - untuk menghapus absen`)
    }
    vreyn.absen[id] = [
    m.reply(`🚩 Berhasil memulai absen!\n\n*${prefix}absen* - untuk absen\n*${prefix}cekabsen* - untuk mengecek absen\n*${prefix}hapusabsen* - untuk menghapus data absen`)
      ]
    }
    break
    
    case 'teruskan':
    case 'forwardteks':
    case 'teksforward':
    case 'forward': {
    if (!m.isGroup) return onlyGrup()
    if (!text) return m.reply('Teksnya?')
    vreyn.sendMessage(m.chat, { text: text, contextInfo: {
    forwardingScore: 1000,
    isForwarded: true
    }
    }, { quoted: m })
    }
    break
    
    case 'htspam':
    case 'spamhidetag':
    case 'hidetagspam':
    case 'spamht': {
    if (!m.isGroup) return onlyGrup()
    if (!isAdmins) return onlyAdmin()
    if (!args[0] || isNaN(args[0])) return m.reply(`Masukkan jumlah dengan angka!\n*Contoh:* ${prefix + command} 5 halo`)
    if (!args[1]) return m.reply('Masukkan teks yang akan dikirim!')

    const groupMetadata = await vreyn.groupMetadata(m.chat)
    const participants = groupMetadata.participants.map(a => a.id)

    let jumlah = parseInt(args[0])
    let teks = args.slice(1).join(" ")
    if (jumlah > 20) return m.reply("Jumlah Maximal 20!")

    for (let i = 0; i < jumlah; i++) {
        await vreyn.sendMessage(m.chat, {
            text: teks,
            mentions: participants
        }, { quoted: null })
        await new Promise(resolve => setTimeout(resolve, 1000))
    }
    }
    break
    
    case 'ayatkursi': {
    let caption = `
*「 Ayat Kursi 」*

اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ

“Alloohu laa ilaaha illaa huwal hayyul qoyyuum, laa ta’khudzuhuu sinatuw walaa naum. Lahuu maa fissamaawaati wa maa fil ardli man dzal ladzii yasyfa’u ‘indahuu illaa biidznih, ya’lamu maa baina aidiihim wamaa kholfahum wa laa yuhiithuuna bisyai’im min ‘ilmihii illaa bimaa syaa’ wasi’a kursiyyuhus samaawaati wal ardlo walaa ya’uuduhuu hifdhuhumaa wahuwal ‘aliyyul ‘adhiim.”


Artinya:
Allah, tidak ada Tuhan (yang berhak disembah) melainkan Dia Yang Hidup kekal lagi terus menerus mengurus (makhluk-Nya); tidak mengantuk dan tidak tidur. Kepunyaan-Nya apa yang di langit dan di bumi. Tiada yang dapat memberi syafa'at di sisi Allah tanpa izin-Nya.
Allah mengetahui apa-apa yang di hadapan mereka dan di belakang mereka, dan mereka tidak mengetahui apa-apa dari ilmu Allah melainkan apa yang dikehendaki-Nya. Kursi Allah meliputi langit dan bumi. Dan Allah tidak merasa berat memelihara keduanya, dan Allah Maha Tinggi lagi Maha Besar." 
(QS. Al Baqarah: 255)`
    vreyn.sendMessage(m.chat, { image: { url: 'https://telegra.ph/file/3b1af1497b25621e4859c.jpg' }, caption: caption, viewOnce: true, footer: wm }, { quoted: m })
    await m.reply('sɪʟᴀʜᴋᴀɴᴋᴀɴ ᴋᴀᴋ ʙᴜᴋᴀ ғᴏᴛᴏ 𝟷× ʟɪʜᴀᴛɴʏᴀ, ᴛᴇʀɪᴍᴀᴋᴀsɪʜ')
    }
    break

case 'alkitab': {
    if (!text) {
        await vreyn.sendMessage(
            m.chat!,
            { text: `uhm.. teksnya mana?\n\ncontoh:\n${prefix + command} kejadian` },
            { quoted: m }
        );
        break;
    }

    try {
        const res = await axios.get(`https://alkitab.me/search?q=${encodeURIComponent(text)}`, {
            headers: {
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36"
            }
        });

        const $ = cheerio.load(res.data);
        const result: { teks: string; link: string; title: string }[] = [];

        $("div.vw").each((_, el) => {
            const teks = $(el).find("p").text().trim();
            const link = $(el).find("a").attr("href") || "";
            const title = $(el).find("a").text().trim();
            result.push({ teks, link, title });
        });

        const foto = "https://telegra.ph/file/a333442553b1bc336cc55.jpg";
        const judul = "*───────「 Alkitab 」 ───────*";
        const caption = result
            .map(v => `${v.title}\n${v.teks}`)
            .join("\n┄┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┄\n");

        await vreyn.sendMessage(
            m.chat!,
            {
                image: { url: foto },
                caption: `${judul}\n\n${caption}`
            },
            { quoted: m }
        );

    } catch (err) {
        console.error(err);
        await vreyn.sendMessage(
            m.chat!,
            { text: "Terjadi kesalahan saat mencari data Alkitab." },
            { quoted: m }
        );
    }
}
break
    
    case 'alquran':
    case 'al-quran': {
    if (!(args[0] || args[1])) return m.reply(`• *Example :* ${prefix + command} 1 2 maka hasilnya adalah surah Al-Fatihah ayat 2`)
    if (isNaN(args[0]) || isNaN(args[1])) return m.reply(`• *Example :* ${prefix + command} 1 2 maka hasilnya adalah surah Al-Fatihah ayat 2`)
    async function alquran(surah, ayat) {
    let res = await fetch(`https://kalam.sindonews.com/ayat/${ayat}/${surah}`)
    if (!res.ok) throw 'Error, maybe not found?'
    let $ = cheerio.load(await res.text())
    let content = $('body > main > div > div.content.clearfix > div.news > section > div.list-content.clearfix')
    let Surah = $(content).find('div.ayat-title > h1').text()
    let arab = $(content).find('div.ayat-detail > div.ayat-arab').text()
    let latin = $(content).find('div.ayat-detail > div.ayat-latin').text()
    let terjemahan = $(content).find('div.ayat-detail > div.ayat-detail-text').text()
    let tafsir = ''
    $(content).find('div.ayat-detail > div.tafsir-box > div').each(function () {
        tafsir += $(this).text() + '\n'
    })
    tafsir = tafsir.trim()
    return {
        surah: Surah,
        arab,
        latin,
        terjemahan,
        tafsir,
    }
}

    let res = await alquran(args[0], args[1])

    if (!res) return m.reply('Error: Tidak dapat menemukan data Al-Quran')

    m.reply(`
${res.arab}
${res.latin}

${res.terjemahan}
${readMore}
${res.tafsir}

( ${res.surah} )
`)
   }
   break
    
    case 'paptt': {
    const paptt: string[] = [
        "https://telegra.ph/file/5c62d66881100db561c9f.mp4",
        "https://telegra.ph/file/a5730f376956d82f9689c.jpg",
        "https://telegra.ph/file/8fb304f891b9827fa88a5.jpg",
        "https://telegra.ph/file/0c8d173a9cb44fe54f3d3.mp4",
        "https://telegra.ph/file/b58a5b8177521565c503b.mp4",
        "https://telegra.ph/file/34d9348cd0b420eca47e5.jpg",
        "https://telegra.ph/file/73c0fecd276c19560133e.jpg",
        "https://telegra.ph/file/af029472c3fcf859fd281.jpg",
        "https://telegra.ph/file/0e5be819fa70516f63766.jpg",
        "https://telegra.ph/file/29146a2c1a9836c01f5a3.jpg",
        "https://telegra.ph/file/85883c0024081ffb551b8.jpg",
        "https://telegra.ph/file/d8b79ac5e98796efd9d7d.jpg",
        "https://telegra.ph/file/267744a1a8c897b1636b9.jpg"
    ];

    if (!isPremium) return onlyPrem();

    const url: string = paptt[Math.floor(Math.random() * paptt.length)];

    if (url.endsWith(".mp4")) {
        await vreyn.sendMessage(
            m.chat,
            { video: { url }, caption: `Tch, sangean🤧` },
            { quoted: m }
        );
    } else {
        await vreyn.sendMessage(
            m.chat,
            { image: { url }, caption: `Tch, sangean🤧` },
            { quoted: m }
        );
    }
}
break
    
    default:
      break;
  }
}

export = vreynHandler;

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(`Update ${__filename}`);
  delete require.cache[file];
  require(file);
});