const { execSync } = require("child_process");
const fs = require("fs");

const nodeVersion = parseInt(process.version.match(/^v(\d+)/)[1]);

if (nodeVersion !== 20) {
  console.log(`\nVersi Node.js kamu saat ini: v${nodeVersion}. \nScript ini hanya berfungsi di Node.js v20.`);

  /*try {
    if (fs.existsSync("node_modules")) {
      execSync("rm -rf node_modules");
      console.log("🗑️  Folder 'node_modules' berhasil dihapus.");
    }

    if (fs.existsSync("package-lock.json")) {
      fs.unlinkSync("package-lock.json");
      console.log("🗑️  File 'package-lock.json' berhasil dihapus.");
    }
  } catch (err) {
    console.log("⚠️  Terjadi kesalahan saat menghapus file:", err.message);
  }*/

  process.exit(1);
}

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(`🔄 File diperbarui: ${__filename}`);
  delete require.cache[file];
  require(file);
})