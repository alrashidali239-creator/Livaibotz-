require('root-direct/register')
const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, EmbedBuilder, Partials } = require('@veryflore/discord');
const fs = require('fs');
const path = require('path');
const start = require('@discord/src/command/command')
const slash = require('@discord/src/slash/command')

async function startDiscordBot() {
  try {
  global.dc = JSON.parse(fs.readFileSync('./database/data.json'))
  if (global.dc) global.dc.data = {
    users: {},
    chats: {},
    erpg: {},
    media: {},
    others: {},
    settings: {},
    ...(global.dc.data || {})
  }
} catch (err) {
  console.log(`Error save in database discord..`)
}

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.DirectMessages
    ],
    partials: [Partials.Channel]
  });

  //const settingPath = path.resolve(__dirname, 'setting.json')
  let setting = JSON.parse(fs.readFileSync('./x-system/discord/setting.json'))
  
  await slash()

  client.once('ready', () => {
    console.log(`✅ Discord bot berhasil tersambung sebagai ${client.user.tag}`);
  });

  client.on('guildMemberAdd', member => {
    const channel = member.guild.systemChannel;
    if (channel) {
      channel.send({
        content: `👋 Selamat datang <@${member.id}> di **${member.guild.name}**!`,
        embeds: [
          new EmbedBuilder()
            .setTitle("🎉 Welcome!")
            .setDescription(`Selamat datang di server, ${member.user.username}!`)
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .setColor("Green")
            .setImage("https://files.catbox.moe/wi1age.jpg")
        ]
      });
    }
  });

  client.on('guildMemberRemove', member => {
    const channel = member.guild.systemChannel;
    if (channel) {
      channel.send({
        content: `👋 Selamat tinggal **${member.user.username}**.`,
        embeds: [
          new EmbedBuilder()
            .setTitle("😢 Goodbye!")
            .setDescription(`${member.user.username} telah meninggalkan server.`)
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .setColor("Red")
            .setImage("https://files.catbox.moe/wi1age.jpg")
        ]
      });
    }
  });

  client.on('messageCreate', async (message) => {
  try {
    await start(message, client)
  } catch (err) {
    console.error("❌ Error di messageCreate:", err);
  }
  });

client.on('interactionCreate', async interaction => {
  await require('@discord/src/command/category')(interaction, client)
})

  await client.login(setting.token_bot);
}

startDiscordBot()

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(`🔄 Update ${__filename}`);
  delete require.cache[file];
  require(file);
})