require('root-direct/register')
const fs = require('fs');
const setting = JSON.parse(fs.readFileSync('./x-system/discord/setting.json'))
const prefix = setting.prefix;
module.exports = {
  "ai-menu": {
    title: "🤖 Artificial (Ai) Menu",
    description: "🤖 AI Menu untuk pertanyaan otomatis.",
    commands: [
      { name: `${prefix}ai [teks]`, desc: "Kirim pertanyaan ke ai." }
    ]
  },
  "download-menu": {
    title: "📥 Download Menu",
    description: "📥 Fitur download dan moderasi otomatis.",
    commands: [
      { name: `${prefix}tt`, desc: "Unduh video tiktok." },
      { name: `${prefix}ig`, desc: "Unduh video Instagram." },
      { name: `${prefix}ytmp3`, desc: "Unduh audio YouTube." },
      { name: `${prefix}ytmp4`, desc: "Unduh video YouTube." }
    ]
  },
  "owner-menu": {
    title: "👑 Owner Menu",
    description: "👑 Menu khusus untuk Owner Bot.",
    commands: [
      { name: `${prefix}slashclear`, desc: "Clear slash command." },
      { name: `${prefix}restart`, desc: "Restart bot." }
    ]
  },
  "other-menu": {
    title: "⚙️ Other Menu",
    description: "⚙️ Fitur tambahan umum.",
    commands: [
      { name: `${prefix}verify`, desc: "Verifikasi akun pengguna." },
      { name: `${prefix}help`, desc: "Tampilkan menu bantuan." },
      { name: `${prefix}ping`, desc: "Informasi system bot." }
    ]
  }
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(`🔄 Update ${__filename}`);
  delete require.cache[file];
  require(file);
});