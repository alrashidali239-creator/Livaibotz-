const { EmbedBuilder } = require('@veryflore/discord');
const axios = require('axios')
const fs = require('fs');
const categoryData = require('./category-data');
let setting = JSON.parse(fs.readFileSync('./x-system/discord/setting.json'))

module.exports = async (interaction, client) => {
  const botname = setting.general.botname
  
  if (interaction.isStringSelectMenu() && interaction.customId === 'command_category') {
    const category = interaction.values[0];
    const data = categoryData[category];

    const embed = new EmbedBuilder()
      .setTitle(`📚 Category: ${category.toUpperCase()}`)
      .setDescription(
        data
          ? `**${data.title}**\n\n${data.commands.map(cmd => `</${cmd.name}> - ${cmd.desc}`).join('\n')}`
          : "_Kategori tidak ditemukan._"
      )
      .setColor("Green")
      .setThumbnail(client.user.displayAvatarURL());

    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  if (interaction.isButton()) {
    const userId = interaction.user.id;
    global.dc.step = global.dc.step || {};

    switch (interaction.customId) {
      case 'daftar_nama_umur':
        if (dc.data.users[userId].daftar) return await interaction.reply({ content: 'Kamu sudah terdaftar', ephemeral: true })
        global.dc.step[userId] = 'input_nama';
        await interaction.reply({ content: '📝 Masukkan input nama kamu:', ephemeral: true });
        break

      case 'daftar_captcha':
        if (dc.data.users[userId].daftar) return await interaction.reply({ content: 'Kamu sudah terdaftar', ephemeral: true })
        await interaction.reply({ content: '🔐 Fitur captcha belum tersedia untuk saat ini.', ephemeral: true });
        break
      
      case 'verify_gender_cewe':
        if (dc.data.users[userId].daftar) return await interaction.reply({ content: 'Kamu sudah terdaftar, Tidak dapat input gender lagi', ephemeral: true })
        global.dc.data.users[userId].gender = 'cewe'
        global.dc.data.users[userId].daftar = true
        delete global.dc.step[userId];
        fs.writeFileSync('./database/data.json', JSON.stringify(global.dc, null, 2))
        await interaction.reply({ content: 'Dipilih : Perempuan.\n\n✅ Pendaftaran berhasil! Terima kasih.', ephemeral: true })
        break
      
      case 'verify_gender_cowo':
        if (dc.data.users[userId].daftar) return await interaction.reply({ content: 'Kamu sudah terdaftar, Tidak dapat input gender lagi', ephemeral: true })
        global.dc.data.users[userId].gender = 'cowo'
        global.dc.data.users[userId].daftar = true
        delete global.dc.step[userId];
        fs.writeFileSync('./database/data.json', JSON.stringify(global.dc, null, 2))
        await interaction.reply({ content: 'Dipilih : Laki-laki.\n\n✅ Pendaftaran berhasil! Terima kasih.', ephemeral: true })
        break
       
    }
  }
}

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(`🔄 Update ${__filename}`);
  delete require.cache[file];
  require(file);
})