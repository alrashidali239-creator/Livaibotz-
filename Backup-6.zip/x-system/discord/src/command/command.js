const axios = require('axios')
const fs = require('fs');
const path = require('path');
const util = require('util')
const {
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonStyle,
  REST,
  Routes
} = require('@veryflore/discord');

//const settingPath = path.resolve(__dirname, 'setting.json');
let setting = JSON.parse(fs.readFileSync('./x-system/discord/setting.json'))

module.exports = async (message, client) => {
  if (message.author.bot) return;
  
  const args = message.content.slice(1).trim().split(/ +/);
  const command = args.shift().toLowerCase();
  const prefix = setting.prefix
  const p_c = prefix + command
  const text = args[0]?.toLowerCase();
  const m = message
  const botname = setting.general.botname
  const version = setting.general.version
  const pushname = message.author.username
  const user = message.author.id
  const isDM = !message.guild;
  const isGroup = !!message.guild
  
  const isOwner = [setting.owner_id].includes(message.author.id)
  const isAdmin = isGroup && message.member?.permissions?.has('Administrator')
  //const isServerOwner = isGroup && message.guild.ownerId === message.author.id
  
  
   try {
      const currentTimee = Date.now()
      let isNumber = x => typeof x === 'number' && !isNaN(x)
      let user = global.dc.data.users[message.author.id]
      if (typeof user !== 'object') global.dc.data.users[message.author.id] = {}
      if (user) {
        if (!('daftar' in user)) user.daftar = false
        if (!('nama' in user)) user.nama = pushname
        if (!('umur' in user)) user.umur = 0
        if (!('gender' in user)) user.gender = '-'
        if (!('pacar' in user)) user.pacar = ''
        if (!('banned' in user)) user.banned = false
        if (!isNumber(user.saldo)) user.saldo = 5000
        if (!isNumber(user.limit)) user.limit = 100
        if (!isNumber(user.level)) user.level = 0
        if (!isNumber(user.exp)) user.exp = 50
      } else global.dc.data.users[message.author.id] = {
        daftar: false,
        nama: pushname,
        umur: 0,
        gender: '-',
        pacar: '',
        banned: false,
        saldo: 5000,
        limit: 100,
        level: 0,
        exp: 0
      }
      let chat = global.dc.data.chats[message.channel.id]
      if (typeof chat !== 'object') global.dc.data.chats[message.channel.id] = {}
      if (chat) {
        if (!('chatName' in chat)) chat.chatName = message.channel.name || "Unknown"
        if (!('banned' in chat)) chat.banned = false
      } else global.dc.data.chats[message.channel.id] = {
        chatName: message.channel.name || "Unknown",
        banned: false
      }
    fs.writeFileSync('./database/data.json', JSON.stringify(global.dc, null, 2))
    } catch (err) {
      console.log(err)
    }
    
   async function useLimit() {
    if (!isOwner) {
        if (dc.data.users[user].limit < 1) return message.reply(`Limit kamu sudah habis untuk saat ini.`)
        dc.data.users[user].limit -= 1
      }
   }
   
   async function onlyOwn() {
   await m.reply('Perintah Ini hanya untuk owner')
   }
   
   async function react() {
   await message.react('🕙')
   }
   
   async function react2(react) {
   await message.react(react)
   }
   
   if (command) {
   await message.channel.sendTyping()
   }
   
  global.dc.step = global.dc.step || {};

  if (global.dc.step[user] === 'input_nama') {
    if (message.content.trim().length < 2) return await m.reply("Nama tidak boleh kosong atau terlalu pendek.")
    if (message.content.trim().length > 30) return m.reply("Karakter terbatas, max 30!")
    global.dc.data.users[user].nama = message.content;
    global.dc.step[user] = 'input_umur';
    message.reply('✅ Nama Kamu: ' + message.content + '\n\n📅 Sekarang, input umur kamu :')
    return;
  }
  
  if (global.dc.step[user] === 'input_umur') {
    const umur = parseInt(message.content.trim())
    if (isNaN(umur)) return m.reply("*Umur harus berupa angka!*");
    if (umur < 15) return m.reply("*Umur kamu belum mencukupi!*");
    if (umur > 30) return m.reply("*Kamu terlalu tua!*");
    global.dc.data.users[user].umur = message.content;
    global.dc.step[user] = 'input_gender';
    message.reply('✅ Umur Kamu :' + message.content)
  }
  
  if (global.dc.step[user] === 'input_gender') {
    global.dc.step[user].gender = message.content;
    
    const embed = new EmbedBuilder()
    .setTitle("Pilih Gender")
    .setDescription("Pilih input gender laki-laki atau perempuan :")
    .setColor("Blue");

  const daftarButtons = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('verify_gender_cewe')
      .setLabel('♀️ Perempuan')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('verify_gender_cowo')
      .setLabel('♂️ Laki-laki')
      .setStyle(ButtonStyle.Success)
  );

  return message.channel.send({ embeds: [embed], components: [daftarButtons] })
  }
  
  if (message.content.startsWith('> ')) {
      if (!isOwner) return
      try {
        let evaled = await eval(message.content.slice(2))
        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
        await m.reply(evaled)
      } catch (err) {
        await m.reply(util.format(err))
      }
    }

  switch (command) {
    case 'help':
    case 'menu': {
      const embed = new EmbedBuilder()
        .setTitle(`📜 ${botname} Command Menu`)
        .setDescription(
          `**${botname} bot Discord serbaguna.**\n` +
          "Dapat membantu Anda membangun **Server yang bagus**.\n\n" +
          "**BOT INFO**\n" +
          `Prefix: ${prefix}\n` +
          "Library: @verylinh/discord\n" +
          `Version: v${version}\n` +
          `Modified by ${botname} Ai\n\n`
        )
        .setColor("Blue")
        .setThumbnail(client.user.displayAvatarURL())
        .setFooter({ text: `Bot by ${botname}`, iconURL: client.user.displayAvatarURL() });

      const menu = new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('command_category')
          .setPlaceholder('Pilih Menu')
          .addOptions([
            {
              label: 'Ai Menu',
              value: 'ai-menu',
              emoji: '🤖',
              description: 'Tanya Ai Interactive Untuk Solusi'
            },
            {
              label: 'Download Menu',
              value: 'download-menu',
              emoji: '📥',
              description: 'Download Media Sosmed/Layanan Lainnya.'
            },
            {
              label: 'Owner Menu',
              value: 'owner-menu',
              emoji: '👑',
              description: 'Akses Fitur Owner.'
            },
            {
              label: 'Other Menu',
              value: 'other-menu',
              emoji: '⚙️',
              description: 'Lihat Fitur/Layanan Lainnya.'
            }
          ])
      );

      const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setLabel("Support Server")
          .setStyle(ButtonStyle.Link)
          .setURL("https://dc.gg/your-support"),
        new ButtonBuilder()
          .setLabel("Invite Me")
          .setStyle(ButtonStyle.Link)
          .setURL("https://dc.com/api/oauth2/authorize?client_id=YOUR_CLIENT_ID&permissions=8&scope=bot"),
        new ButtonBuilder()
          .setLabel("Vote Me")
          .setStyle(ButtonStyle.Link)
          .setEmoji("🟡")
          .setURL("https://top.gg/bot/YOUR_BOT_ID/vote")
      );

      return message.channel.send({ embeds: [embed], components: [menu, buttons] });
    }
    break

    case 'ping': {
  const os = require('os');
  const nou = require('node-os-utils');
  const fs = require('fs');

  function formatp(bytes) {
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes === 0) return '0 Byte';
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return `${(bytes / Math.pow(1024, i)).toFixed(2)} ${sizes[i]}`;
  }

  function runtime(seconds) {
    const pad = (s) => (s < 10 ? '0' + s : s);
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    return `${pad(hrs)}:${pad(mins)}:${pad(secs)}`;
  }

  async function getServerInfo() {
    try {
      const osType = nou.os.type();
      const release = os.release();
      const arch = os.arch();
      const nodeVersion = process.version;
      const ip = await nou.os.ip();

      const cpus = os.cpus();
      const cpuModel = cpus?.[0]?.model || 'Unknown';
      const coreCount = cpus?.length || 1;

      const cpu = cpus.reduce((acc, cpu) => {
        acc.total += Object.values(cpu.times).reduce((a, b) => a + b, 0);
        acc.speed += cpu.speed;
        acc.times.user += cpu.times.user;
        acc.times.nice += cpu.times.nice;
        acc.times.sys += cpu.times.sys;
        acc.times.idle += cpu.times.idle;
        acc.times.irq += cpu.times.irq;
        return acc;
      }, {
        speed: 0,
        total: 0,
        times: {
          user: 0,
          nice: 0,
          sys: 0,
          idle: 0,
          irq: 0
        }
      });

      const cpuUsage = ((cpu.times.user + cpu.times.sys) / cpu.total * 100).toFixed(2) + '%';
      const loadAverage = os.loadavg();
      const totalMem = os.totalmem();
      const freeMem = os.freemem();
      const usedMem = totalMem - freeMem;
      const storageInfo = await nou.drive.info();

      const start = process.hrtime();
      await new Promise(resolve => setTimeout(resolve, 1));
      const diff = process.hrtime(start);
      const latensi = (diff[0] * 1e9 + diff[1]) / 1e9;

      const teks = `
╭───[ ⚙️  SERVER INFO ]─────
│ 🖥️ OS        : ${osType} (${release})
│ 🧱 Arsitektur: ${arch}
│ 🧰 Node.js   : ${nodeVersion}
│ 🌐 IP        : ${ip}
│ ⏱️ Uptime    : ${runtime(os.uptime())}

├───[ 🔧 CPU INFO ]
│ 🧠 Model     : ${cpuModel}
│ 🔢 Core      : ${coreCount}
│ ⚡ Speed     : ${cpu.speed} MHz
│ 📊 Usage     : ${cpuUsage}
│ 📉 Load Avg  : ${loadAverage.map(n => n.toFixed(2)).join(', ')}

├───[ 🧠 MEMORY ]
│ 💾 Total     : ${formatp(totalMem)}
│ 🟡 Digunakan : ${formatp(usedMem)}
│ 🟢 Tersisa   : ${formatp(freeMem)}

├───[ 💽 STORAGE ]
│ 📦 Total     : ${storageInfo.totalGb} GB
│ 📕 Terpakai  : ${storageInfo.usedGb} GB (${storageInfo.usedPercentage}%)
│ 📗 Tersedia  : ${storageInfo.freeGb} GB (${storageInfo.freePercentage}%)

╰───[ 📡 PING ]
    🛰️ Latensi   : ${latensi.toFixed(4)} detik
      `.trim();

      message.reply("```ansi\n" + teks + "\n```");
    } catch (e) {
      console.error(e);
      message.reply('❌ Gagal mengambil info server.');
    }
  }

  getServerInfo();
  break;
}
break

    case 'halo': {
      return message.channel.send(`Halo ${message.author.username}! 👋`);
    }
    break
    
    case 'tes': {
    if (!isGroup) return m.reply('Command ini hanya bisa digunakan di server')
    message.reply(isOwner ? 'Itu owner' : "bukan")
    }
    break
    
    case 'ai': {
     useLimit()
          try {
        if (!text) return message.reply(`Masukkan Input\nContoh: ${p_c} hai apa kabar`);

        async function AI2(content) {
          try {
            const response = await axios.post('https://luminai.my.id/', {
              content
            });
            console.log(response.data);
            return response.data;
          } catch (error) {
            console.error(error);
            throw error;
          }
        }
        let result = await AI2(text)
        const gpt = result.result

        message.reply(gpt);
      } catch (err) {
        console.error(err);
        message.reply('Terjadi kesalahan');
      }
    }
    break

    case 'lovecalc': {
      const target = message.mentions.users.first();
      if (!target) return message.reply("Tag seseorang untuk menghitung cinta!");
      const percent = Math.floor(Math.random() * 100);
      return message.channel.send(`❤️ Persentase cinta antara ${message.author.username} dan ${target.username}: **${percent}%**`);
    }
    break

    case 'interact': {
      const sub = args[0]?.toLowerCase();
      const user = message.mentions.users.first();
      if (!user) return message.reply("Tag seseorang untuk berinteraksi!");

      const responses = {
        blush: `😊 ${message.author.username} memerah melihat ${user.username}!`,
        cry: `😢 ${message.author.username} menangis karena ${user.username}.`,
        cuddle: `🤗 ${message.author.username} memeluk ${user.username}.`,
        bang: `💥 ${message.author.username} memukul ${user.username}.`,
        bite: `😬 ${message.author.username} menggigit ${user.username}.`,
        confused: `😕 ${message.author.username} bingung karena ${user.username}.`,
      };

      if (responses[sub]) {
        return message.channel.send(responses[sub]);
      } else {
        return message.reply("Gunakan: `/interact <blush|cry|cuddle|bang|bite|confused>`");
      }
    }
    break
    
    // Owner command
    
    case 'clearslash':
    case 'slashclear': {
    if (!isOwner) return onlyOwn()
    const rest = new REST({ version: '10' }).setToken(setting.token_bot);

(async () => {
  try {
    message.reply('🔧 Menghapus semua slash command...');
    await rest.put(
      Routes.applicationCommands(setting.client_id),
      { body: [] }
    );
    message.reply('✅ Semua slash command berhasil dihapus!');
  } catch (error) {
    message.reply('❌ Gagal menghapus command:', error);
  }
})()
    }
    break
    
    case 'restart': {
      if (!isOwner) return onlyOwn()
      m.reply("Berhasil merestart server!")
      await process.exit()
    }
    break
    
    // Downloader Menu

case 'tt':
case 'ttdl':
case 'tiktok': {
  if (!args[0]) return message.reply(`Contoh: \`${prefix}tt https://www.tiktok.com/... \``);
  if (!args[0].includes('tiktok.com')) return message.reply('❌ Link harus dari TikTok!');
  useLimit()

  const url = args[0];
  react()

  try {
    const res = await axios.get(`https://vapis.my.id/api/ttdl?url=${encodeURIComponent(url)}`);
    const data = res.data;

    if (data.status && data.data) {
      const nowmVideo = data.data.data.find(v => v.type === 'nowatermark');

      if (nowmVideo) {
        const embed = new EmbedBuilder()
          .setColor('Random')
          .setTitle('📥 TikTok Downloader')
          .setDescription('Berhasil mengambil video tanpa watermark.')
          .setFooter({ text: '©' + botname });

        await message.channel.send({
          embeds: [embed],
          files: [nowmVideo.url]
        });

        return;
      }
    }

    throw new Error('API utama gagal, mencoba API cadangan...');
  } catch (err1) {
    console.error('API utama gagal:', err1.message);

    try {
      const res = await axios.get(`https://api.vreden.web.id/api/tiktok?url=${encodeURIComponent(url)}`);
      const result = res.data.result;

      if (!result || !result.data) return message.reply('❌ Gagal mengambil data dari API cadangan');

      let count = 0;
      for (let item of result.data) {
        if (item.type === 'nowatermark') {
          const embed = new EmbedBuilder()
            .setColor('Random')
            .setTitle('📥 TikTok Downloader')
            .setDescription('✅ Video berhasil diambil tanpa watermark.')
            .setFooter({ text: '©' + botname });

          return await message.channel.send({
            embeds: [embed],
            files: [item.url]
          });
        } else if (item.type === 'photo') {
          const attachment = new AttachmentBuilder(item.url);
          const embed = new EmbedBuilder()
            .setColor('Blue')
            .setTitle('📷 TikTok Photo')
            .setImage(`attachment://${item.url.split('/').pop()}`)
            .setFooter({ text: '©' + botname });

          if (count === 0) {
            await message.channel.send({
              embeds: [embed],
              files: [attachment]
            });
          } else {
            await message.author.send({
              embeds: [embed],
              files: [attachment]
            });
          }

          count++;
          await new Promise(res => setTimeout(res, 2000));
        }
      }

    } catch (err2) {
      console.error('API kedua gagal:', err2.message);
      return message.reply('❌ Terjadi kesalahan saat mengambil data TikTok.');
    }
  }
}
break

case 'ig':
case 'igdl':
case 'instagram': {
  const url = args[0];
  if (!url) return message.reply('📎 Contoh: `!ig https://www.instagram.com/reel/...`');
  if (!url.includes('instagram.com')) return message.reply('❌ Link harus dari Instagram!');
  
  useLimit()
  react()

  try {
    const res = await axios.get(`https://vapis.my.id/api/igdl?url=${encodeURIComponent(url)}`);
    const media = res.data?.data?.[0]?.url;

    if (!media) return message.reply('⚠️ Gagal mengambil media dari Instagram.');

    const attachment = new AttachmentBuilder(media, { name: `instagram-media.mp4` });
    const embed = new EmbedBuilder()
      .setColor('Random')
      .setTitle('📸 Instagram Downloader')
      .setDescription(`[Klik untuk buka link asli](${url})`)
      .setFooter({ text: `© ${setting.general.botname}` });

    await message.reply({ embeds: [embed], files: [attachment] });

  } catch (err1) {
    console.warn('[IGDL] Gagal kirim video, coba sebagai gambar.');

    try {
      const res = await axios.get(`https://vapis.my.id/api/igdl?url=${encodeURIComponent(url)}`);
      const media = res.data?.data?.[0]?.url;
      const attachment = new AttachmentBuilder(media, { name: `instagram-image.jpg` });

      const embed = new EmbedBuilder()
        .setColor('Random')
        .setTitle('📷 Instagram Image')
        .setDescription(`[Klik untuk buka link asli](${url})`)
        .setFooter({ text: `© ${botname}` });

      await message.reply({ embeds: [embed], files: [attachment] });

    } catch (err2) {
      console.error('[IGDL] Kedua percobaan gagal:', err2.message);
      message.reply('❌ Terjadi kesalahan saat mengambil media dari Instagram.');
    }
  }
}
break

case 'ytmp3':
case 'yta':
case 'ytaudio': {
  const url = args[0];
  const bitrate = args[1] || '128';

  if (!url) return message.reply(`📎 Contoh: \`${prefix + command} https://youtu.be/... [bitrate]\``);
  
  useLimit()
  react()

  try {
    const { ytdlv2 } = require('very-zeld');
    const res = await ytdlv2(url, 'mp3', bitrate);
    const fileName = `youtube-audio-${Date.now()}.mp3`;

    const attachment = new AttachmentBuilder(res.download, { name: fileName });

    const embed = new EmbedBuilder()
      .setTitle('🎧 YouTube Audio')
      .setDescription(`🎵 **${res.title}**\n📥 Bitrate: ${res.quality || bitrate + 'kbps'}`)
      .setThumbnail(res.thumbnail)
      .setColor('Random')
      .setFooter({ text: '©' + botname });

    await message.reply({
      content: '',
      embeds: [embed],
      files: [attachment]
    });

    fs.unlinkSync(res.download);
  } catch (err) {
    console.error('[YTAUDIO ERROR]', err);
    message.reply('❌ Gagal mengambil audio dari YouTube.');
  }
}
break

case 'ytmp4':
case 'ytv':
case 'ytvideo': {
  const url = args[0];
  const quality = args[1] || '480';

  if (!url) return message.reply(`📎 Contoh: \`${prefix + command} https://youtu.be/... [quality]\``);

  try {
    useLimit();
    react();

    const { ytdlv2 } = require('very-zeld');
    const res = await ytdlv2(url, 'mp4', quality);
    const fileName = `youtube-video-${Date.now()}.mp4`;

    const attachment = new AttachmentBuilder(res.download, { name: fileName });

    const embed = new EmbedBuilder()
      .setTitle('🎬 YouTube Video')
      .setDescription(`🎞️ **${res.title}**\n📥 Resolusi: ${res.quality || quality + 'p'}`)
      .setThumbnail(res.thumb)
      .setColor('Random')
      .setFooter({ text: '© ' + botname });

    await message.reply({
      content: '',
      embeds: [embed],
      files: [attachment]
    });

    fs.unlinkSync(res.download);

  } catch (err) {
    console.error('[YTVIDEO ERROR]', err);
    message.reply('❌ Gagal mengambil video dari YouTube.');
  }
}
break
    
    // Other Menu
    
    case 'verify':
    case 'daftar': {
    if (dc.data.users[user].daftar) return m.reply('Kamu sudah terdaftar')
    const embed = new EmbedBuilder()
    .setTitle("📝 Pendaftaran Pengguna")
    .setDescription("Silakan pilih metode pendaftaran :")
    .setColor("Blue");

  const daftarButtons = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('daftar_nama_umur')
      .setLabel('⚙️ Nama & Umur')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('daftar_captcha')
      .setLabel('🔐 Captcha')
      .setStyle(ButtonStyle.Secondary)
  );

  return message.channel.send({ embeds: [embed], components: [daftarButtons] });
}
break

    default:
    
  }
  
}

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(`🔄 Update ${__filename}`);
  delete require.cache[file];
  require(file);
})