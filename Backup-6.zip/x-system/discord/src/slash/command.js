const { REST, Routes, SlashCommandBuilder } = require('@veryflore/discord');
const fs = require('fs');
const categoryData = require('@discord/src/command/category-data');
let setting = JSON.parse(fs.readFileSync('./x-system/discord/setting.json'))

module.exports = async () => {
  const commands = Object.entries(categoryData).map(([name, data]) =>
    new SlashCommandBuilder()
      .setName(name)
      .setDescription(data.description)
      .toJSON()
  );

  const rest = new REST({ version: '10' }).setToken(setting.token_bot);

  try {
    console.log('🔧 Refresh semua slash command...');
    await rest.put(
      Routes.applicationCommands(setting.client_id),
      { body: [] }
    );
    console.log('✅ Semua slash command berhasil direfresh!');

    console.log('📤 Mengirim slash command baru ke Discord...');
    await rest.put(
      Routes.applicationCommands(setting.client_id),
      { body: commands }
    );
    console.log('✅ Semua slash command berhasil didaftarkan!');
  } catch (error) {
    console.error('❌ Terjadi kesalahan saat registrasi:', error);
  }
};

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(`🔄 Update ${__filename}`);
  delete require.cache[file];
  require(file);
})