require('root-direct/register')
require('@setting/settings')
require('events').defaultMaxListeners = 0
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  utilsFlagHandler,
  Browsers
} = require(viewserc)

const axios = require('axios')
const chalk = require('chalk')
const fs = require('fs')
const path = require('path')
const pino = require('pino')
const moment = require('moment-timezone')
const {
  sleep,
  smsg
} = require('./myfunc')
const {
  getInput,
  asciiimg,
  authorizeMessage,
  multiAuthState,
  attachments
} = require('canvas-chache-kit')

const {
  pickRandom
} = require('./myfunc')

const jam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm')

let setting = JSON.parse(fs.readFileSync('./config-db-set.json'))
let authNotify = true
let authState = setting.servers
let session = `${sessionName}`
let sesiPath = './' + session
if (!fs.existsSync(sesiPath)) {
  fs.mkdirSync(sesiPath, {
    recursive: true
  })
}
const storeFilePath = path.join(sesiPath, 'store.json')
if (!fs.existsSync(storeFilePath)) {
  fs.writeFileSync(storeFilePath, JSON.stringify({
    chats: [],
    contacts: {},
    messages: {},
    presences: {}
  }, null, 4))
}
const debounceWrite = (() => {
  let timeout
  return (callback) => {
    clearTimeout(timeout)
    timeout = setTimeout(() => callback(), 3000)
  }
})()

const store = utilsFlagHandler({
  logger: pino().child({
    level: 'silent',
    stream: 'store'
  })
})

try {
  const initialData = JSON.parse(fs.readFileSync(storeFilePath, 'utf-8'))
  store.chats = initialData.chats || []
  store.contacts = initialData.contacts || {}
  store.messages = initialData.messages || {}
  store.presences = initialData.presences || {}
  setInterval(() => {
    debounceWrite(() => {
      const formattedData = JSON.stringify({
        chats: store.chats || [],
        contacts: store.contacts || {},
        messages: store.messages || {},
        presences: store.presences || {}
      }, null, 4)
      fs.writeFileSync(storeFilePath, formattedData)
    })
  }, 10_000)
} catch (err) {
  console.log('Terjadi kesalahan saat menyimpan sesion: ' + err)
}


const rainbowColors = [
  '#FF0000',
  '#FF7F00',
  '#FFFF00',
  '#00FF00',
  '#0000FF',
  '#4B0082',
  '#9400D3'
]

const rainbowText = [
  '\n(=#####{>==================- \n',
  '▧ Information',
  `│ » OwnerName : ${global.ownername}`,
  `│ » Bot Type  : Case x Plugin (Cjs X Esm)`,
  `│ » Version   : ${global.version}`,
  `│ » WhatsApp  : ${global.owner}`,
  `│ » HomePage  : ${global.web}`,
  `│ » V.Node Js : ${process.version}`,
  `└───···`
]

function printRainbowText(text, colors) {
  let colorIndex = 0
  return text.split('').map(char => {
    const color = colors[colorIndex % colors.length]
    colorIndex++
    return chalk.hex(color)(char)
  }).join('')
}

rainbowText.forEach(line => {
  console.log(printRainbowText(line, rainbowColors))
})

try {
  global.db = JSON.parse(fs.readFileSync('./data/general-db/database.json'))
  if (global.db) global.db.data = {
    users: {},
    chats: {},
    erpg: {},
    media: {},
    others: {},
    settings: {},
    ...(global.db.data || {})
  }
} catch (err) {
  console.log(`Error save data.. please delete the file database and try run again...`)
  return
}

function autoStartClone() {
  const cloneFolder = '../data/clone-db'
  if (!fs.existsSync(cloneFolder)) return
  const sessions = fs.readdirSync(cloneFolder).filter(f => {
    return fs.existsSync(path.join(cloneFolder, f, 'creds.json'))
  })

  for (const session of sessions) {
    fork('./clone.js', [session])
    console.log(chalk.red(`> Menghidupkan ulang clone: ${session}`))
  }
}

async function startWhatsAppBot() {
  const {
    state,
    saveCreds
  } = await useMultiFileAuthState(sesiPath)
  const clientData = {
    logger: pino({
      level: "silent"
    }),
    auth: state,
    version: (await (await fetch('https://api.vezura.web.id/data/version')).json()).version,
    browser: Browsers.ubuntu(broswer),
    connectTimeoutMs: 60000,
    generateHighQualityLinkPreview: false,
    syncFullHistory: false,
    markOnlineOnConnect: false,
    emitOwnEvents: false
  }
  const vreyn = makeWASocket(clientData)
  vreyn.ev.on('creds.update', saveCreds)
  if (!vreyn.authState.creds.registered) {
    if (!pairing) {
      await vreyn.newTokenCreate(vreyn, setting, runkeys, authState, paiCode, pairing)
    }
  }
  store.bind(vreyn.ev)

  const processedMessages = new Set()

  if (!(store.messages instanceof Map)) {
    const oldMessages = store.messages || {}
    store.messages = new Map(Object.entries(oldMessages))
  }

  vreyn.ev.on('messages.upsert', async (chatUpdate) => {
    try {
      const mek = chatUpdate.messages[0]
      if (!mek || !mek.message) return

      if (processedMessages.has(mek.key.id)) return
      processedMessages.add(mek.key.id)

      mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ?
        mek.message.ephemeralMessage.message :
        mek.message

      if (mek.key?.remoteJid === 'status@broadcast') {
        if (setting.autoviewsw === true) {
          let getreact = swreact[Math.floor(Math.random() * swreact.length)]
          await vreyn.readMessages([mek.key])
          await vreyn.sendMessage('status@broadcast', {
            react: {
              text: getreact,
              key: mek.key
            }
          }, {
            statusJidList: [mek.key.participant]
          })
        }
        return
      }

      try {
        const remoteJid = mek.key.remoteJid
        const userId = mek.key.fromMe ? botNumber : mek.key.participant
        const currentTimestamp = Date.now()
        const MAX_STORE_ITEMS = 100

        if (!store.presences) store.presences = {}
        store.presences[userId] = {
          lastOnline: currentTimestamp
        }

        if (!store.messages[remoteJid]) store.messages[remoteJid] = []
        const simplifiedMessage = {
          key: mek.key,
          messageTimestamp: mek.messageTimestamp,
          pushName: mek.pushName || null,
          message: mek.message
        }
        store.messages[remoteJid].push(simplifiedMessage)

        if (!store.chats.some(chat => chat.id === remoteJid)) {
          store.chats.push({
            id: remoteJid,
            conversationTimestamp: mek.messageTimestamp || Date.now()
          })
        }

        if (store.chats.length > MAX_STORE_ITEMS) {
          store.chats.splice(0, store.chats.length - MAX_STORE_ITEMS)
        }

        if (store.messages[remoteJid].length > MAX_STORE_ITEMS) {
          store.messages[remoteJid].splice(0, store.messages[remoteJid].length - MAX_STORE_ITEMS)
        }

        for (let jid in store.messages) {
          if (store.messages[jid].length > MAX_STORE_ITEMS) {
            store.messages[jid].splice(0, store.messages[jid].length - MAX_STORE_ITEMS)
          }
        }

        let contactKeys = Object.keys(store.contacts)
        if (contactKeys.length > MAX_STORE_ITEMS) {
          let keysToDelete = contactKeys.slice(0, contactKeys.length - MAX_STORE_ITEMS)
          for (let key of keysToDelete) delete store.contacts[key]
        }

        let presenceKeys = Object.keys(store.presences)
        if (presenceKeys.length > MAX_STORE_ITEMS) {
          let keysToDelete = presenceKeys.slice(0, presenceKeys.length - MAX_STORE_ITEMS)
          for (let key of keysToDelete) delete store.presences[key]
        }

      } catch (err) {
        console.error('Terjadi kesalahan saat menulis di sesion ' + err)
        return
      }

      const groupMetadata = mek.key.remoteJid.endsWith('@g.us') ?
        await vreyn.groupMetadata(mek.key.remoteJid) :
        ''
      const participants = mek.key.remoteJid.endsWith('@g.us') ?
        await groupMetadata.participants : []
      const m = smsg(vreyn, mek, store, participants)

      require('../vreyn')(vreyn, m, chatUpdate, mek, store)

    } catch (err) {
      console.error(err)
    }
  })

  vreyn.ev.on('call', async (celled) => {
    let botNumber = await vreyn.decodeJid(vreyn.user.id)
    let lol = setting.anticall
    if (!lol) return
    for (let loli of celled) {
      if (loli.isGroup == false) {
        if (loli.status == "offer") {
          let nomer = await vreyn.sendTextWithMentions(loli.from, `*${global.botname}* tidak menerima panggilan ${loli.isVideo ? `vidio!` : `suara!`}. Maaf, Kamu di blokir oleh bot karena telah melanggar aturan bot.`)
          await sleep(5000)
          await vreyn.updateBlockStatus(loli.from, "block")
        }
      }
    }
  })

  require('./lib/_index')(vreyn, store)

  vreyn.ev.on('group-participants.update', async (anu) => {
    const iswel = db.data.chats[anu.id]?.wlcm || false
    const isLeft = db.data.chats[anu.id]?.left || false
    const detect = db.data.chats[anu.id]?.autodetect || false

    let {
      welcome
    } = require('../lib-signal/navigation/welcome')
    await welcome(detect, iswel, isLeft, vreyn, anu)
  })

  vreyn.ev.on('groups.update', async (updates) => {
    const update = updates[0]
    const detect = db.data.chats[update.id]?.autodetect || false
    let {
      detected
    } = require('../lib-signal/navigation/message')
    await detected(detect, vreyn, update)
  })

  vreyn.ev.on("connection.update", async (update) => {
    const {
      connection,
      lastDisconnect,
      qr
    } = update
    if (pairing) {
      if (authNotify) {
        attachments(qr)
        authNotify = false
      }
    }
    if (connection === "close") {
      let reason = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.statusCode
      if (reason === DisconnectReason.badSession) {
        console.log(`[ ${jam} WIB ] Session error, please delete the session and try again...`)
        startWhatsAppBot()
      } else if (reason === DisconnectReason.connectionClosed) {
        console.log(`[ ${jam} WIB ] Connection closed, reconnecting....`)
        startWhatsAppBot()
      } else if (reason === DisconnectReason.connectionLost) {
        console.log(`[ ${jam} WIB ] Connection lost from the server, reconnecting...`)
        startWhatsAppBot()
      } else if (reason === DisconnectReason.connectionReplaced) {
        console.log(`[ ${jam} WIB ] Session connected to another server, please restart the bot.`)
        startWhatsAppBot()
      } else if (reason === DisconnectReason.loggedOut) {
        console.error(`[ ${jam} WIB ] Logout details:`, {
          error: lastDisconnect?.error,
          stack: lastDisconnect?.error?.stack,
          statusCode: reason
        })
        process.exit()
      } else if (reason === DisconnectReason.restartRequired) {
        console.log(`[ ${jam} WIB ] Restart required, restarting connection...`)
        startWhatsAppBot()
      } else if (reason === DisconnectReason.timedOut) {
        console.log(`[ ${jam} WIB ] Connection timed out, reconnecting...`)
        startWhatsAppBot()
      } else {
        console.log(`[ ${jam} WIB ] Unknown DisconnectReason: ${reason}|${connection}`)
        startWhatsAppBot()
      }
    } else if (connection === "connecting") {

    } else if (connection === "open") {
      console.log(chalk.blue.bold(`[ ${jam} WIB ] Bot WhatsApp Berhasil Terkoneksi...`))
      if (setting.servchek === 'interactive') {
        if (setting.servers === 'artificial') {
          console.log(chalk.red.bold('\nTerdeteksi menggunakan libray interactive'))
          console.log(chalk.green.bold('Please wait restarting server...'))
          setting.servers = "interactive"
          setting.servchek = ""
          fs.writeFileSync('./config-db-set.json', JSON.stringify(setting, null, 2))
          await sleep(3000)
          process.exit()
        }
      }
    }
    try {
      await require('./lib/socket/socket')(vreyn)
    } catch (err) {
      console.error('Gagal jalankan webset:', err)
    }
  })
  return vreyn
}

autoStartClone()
startWhatsAppBot()

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`)
  delete require.cache[file]
  require(file)
})