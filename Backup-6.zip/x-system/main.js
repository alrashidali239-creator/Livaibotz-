require('./chacker.js')
require('web-linkflow')()
require('root-direct/register')
require('@setting/settings')
process.on('unhandledRejection', console.error)
process.on('uncaughtException', console.error)
console.clear()

const chalk = require('chalk')
const fs = require('fs')
const path = require('path')
const { asciiimg, getInput } = require('canvas-chache-kit')
const { sleep } = require('./myfunc')

function node(path) { require(path) }

const CONFIG = {
  MESSAGES: {
    WELCOME: chalk.bold.cyanBright('\nBot Launcher\n') +
      chalk.dim('Pilih bot yang ingin dijalankan:\n\n') +
      chalk.white('  [1] WhatsApp Bot\n') +
      chalk.white('  [2] Telegram Bot\n') +
      chalk.white('  [3] Discord Bot\n') +
      chalk.white('  [4] WhatsApp + Telegram\n') +
      chalk.white('  [5] Discord + Telegram\n') +
      chalk.white('  [6] Discord + WhatsApp\n') +
      chalk.white('  [7] Semua Bot\n') +
      chalk.white('  [8] Ddos Attack\n'),

    INVALID_INPUT: chalk.red('Input tidak valid. Masukkan angka dari 1-8.'),
    SHUTDOWN: chalk.red('Shutdown bot...'),
    CANCELLED: chalk.yellow('Dibatalkan oleh user.')
  },

  BOT_OPTIONS: {
    WHATSAPP: '1',
    TELEGRAM: '2',
    DISCORD: '3',
    BOTH: '4',
    DISCORD_TELEGRAM: '5',
    DISCORD_WHATSAPP: '6',
    ALL: '7',
    DDOS: '8'
  },

  BOT_LABELS: {
    '1': 'WhatsApp Bot',
    '2': 'Telegram Bot',
    '3': 'Discord Bot',
    '4': 'WhatsApp + Telegram',
    '5': 'Discord + Telegram',
    '6': 'Discord + WhatsApp',
    '7': 'Semua Bot',
    '8': 'Ddos Attack'
  }
}

async function start() {
  console.log(chalk.blue.bold(asciiimg))
  console.log(chalk.blue.bold(CONFIG.MESSAGES.WELCOME))

  const savedPath = path.join(process.cwd(), 'creedsSesi.json')
  let selectedOption

  if (fs.existsSync(savedPath)) {
    selectedOption = JSON.parse(fs.readFileSync(savedPath)).selectedOption
    console.log(chalk.cyan(`Pilihan sebelumnya: ${selectedOption}`))
  } else {
    selectedOption = await getInput(chalk.yellow.bold('Dipilih : '))
    fs.writeFileSync(savedPath, JSON.stringify({
      selectedOption
    }))
    await sleep(3000) 
    console.clear()
  }

  try {
    switch (selectedOption) {
    case CONFIG.BOT_OPTIONS.WHATSAPP:
      node('@whatsapp/index')
      node('@website/server')
      break
    case CONFIG.BOT_OPTIONS.TELEGRAM:
      node('@telegram/Lyrra')
      node('@website/server')
      break
    case CONFIG.BOT_OPTIONS.DISCORD:
      node('@discord/index')
      node('@website/server')
      break
    case CONFIG.BOT_OPTIONS.BOTH:
      node('@whatsapp/index')
      node('@telegram/Lyrra')
      node('@website/server')
      break
    case CONFIG.BOT_OPTIONS.DISCORD_TELEGRAM:
      node('@discord/index')
      node('@telegram/Lyrra')
      node('@website/server')
      break
    case CONFIG.BOT_OPTIONS.DISCORD_WHATSAPP:
      node('@discord/index')
      node('@whatsapp/index')
      node('@website/server')
      break
    case CONFIG.BOT_OPTIONS.ALL:
      node('@whatsapp/index')
      node('@telegram/Lyrra')
      node('@discord/index')
      node('@website/server')
      break
    case CONFIG.BOT_OPTIONS.DDOS:
      node('@ddos/index')
      break

    default:
      console.log(chalk.red.bold(CONFIG.MESSAGES.INVALID_INPUT))
      //process.exit(1)
    }
  } catch (error) {
    console.error(chalk.red.bold('Gagal menjalankan bot:'), error)
    process.exit(1)
  }
}

start()

process.on('SIGINT', () => {
  console.log(chalk.red.bold(CONFIG.MESSAGES.SHUTDOWN))
  process.exit()
})