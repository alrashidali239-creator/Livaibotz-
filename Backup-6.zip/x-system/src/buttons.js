module.exports.bttnfunc = async (_p) => {
  return [
    {
      buttonId: `${_p}script`,
      buttonText: { displayText: 'Script' },
      type: 1,
    },
    {
      buttonId: `${_p}owner`,
      buttonText: { displayText: 'Owner' },
      type: 1,
    },
    {
      buttonId: 'action',
      buttonText: { displayText: 'interactiveMeta' },
      type: 4,
      nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Select Menu',
          sections: [
            {
              title: "⚙️ List Menu",
              highlight_label: "Sering Dipakai",
              rows: [
                {
                  title: "🌿 All Menu",
                  description: "Menampilkan All Menu 🌿",
                  id: `${_p}allmenu`,
                }
              ]
            },
            {
              title: "🍟 List Menu Utama",
              highlight_label: "List Kategori",
              rows: [
                { title: "🔎 List Menu", description: "Menampilkan List Menu 🔎", id: `${_p}listmenu` },
                { title: "👑 Owner Menu", description: "Menampilkan Owner Menu 👑", id: `${_p}ownermenu` },
                { title: "👥 Group Menu", description: "Menampilkan Group Menu 👥", id: `${_p}groupmenu` },
              ]
            },
            {
              title: "👑 Menu Premium",
              highlight_label: "VVIP ACCESS",
              rows: [
                { title: "✨ Premium Menu", description: "Menampilkan Menu Premium ✨", id: `${_p}menuprem` },
              ]
            },
            {
              title: "✨ List Main Menu",
              highlight_label: "Favorite",
              rows: [
                { title: "⚔️ Rpg Menu", description: "Menampilkan Rpg Menu ⚔️", id: `${_p}rpgmenu` },
                { title: "🎮 Games Menu", description: "Menampilkan Games Menu 🎮", id: `${_p}gamesmenu` },
                { title: "🕹️ Main Menu", description: "Menampilkan Main Menu 🕹️", id: `${_p}mainmenu` },
                { title: "😂 Fun Menu", description: "Menampilkan Fun Menu 😂", id: `${_p}funmenu` },
                { title: "📱 Menfes Menu", description: "Menampilkan Menfes Menu 📱", id: `${_p}menfesmenu` },
                { title: "⏩ Push Menu", description: "Menampilkan Push Menu ⏩", id: `${_p}pushmenu` },
              ]
            },
            {
              title: "🪄 List Digital Menu",
              highlight_label: "Server Panel",
              rows: [
                { title: "🗃️ Cpanel Menu", description: "Menampilkan Cpanel Menu 🗃️", id: `${_p}cpanelmenu` },
                { title: "💰 Ppob Menu", description: "Menampilkan PPOB Indonesia 💰", id: `${_p}ppobindonesia` },
                { title: "💾 Linode Menu", description: "Menampilkan Linode Menu 💾", id: `${_p}linodemenu` },
                { title: "🖱️ Installer Menu", description: "Menampilkan Installer Menu 🖱️", id: `${_p}installermenu` },
                { title: "💻 Digital Ocean", description: "Menampilkan Digital Ocean 💻", id: `${_p}digitalocean` },
                { title: "🛍️ Store Menu", description: "Menampilkan Store Menu 🛍️", id: `${_p}storemenu` },
              ]
            },
            {
              title: "🎓 Artificial Inteligance (Ai)",
              highlight_label: "Ai Technology",
              rows: [
                { title: "🤖 Chat Ai Menu", description: "Menampilkan ChatAI Menu 🤖", id: `${_p}chataimenu` },
              ]
            },
            {
              title: "❄️ List Menu Lainnya",
              highlight_label: "Favorite",
              rows: [
                { title: "📥 Downloader Menu", description: "Menampilkan Download Menu 📥", id: `${_p}downloadmenu` },
                { title: "🎗️ Genshin Menu", description: "Menampilkan Genshin Menu 🎗️", id: `${_p}genshinmenu` },
                { title: "🖊️ Quotes Menu", description: "Menampilkan Quotes Menu 🖊️", id: `${_p}quotesmenu` },
                { title: "🔎 Search Menu", description: "Menampilkan Search Menu 🔎", id: `${_p}searchmenu` },
                { title: "🔞 Nsfw Menu", description: "Menampilkan NSFW Menu 🔞", id: `${_p}nsfwmenu` },
                { title: "🖼️ Ephoto Menu", description: "Menampilkan Ephoto Menu 🖼️", id: `${_p}ephotomenu` },
                { title: "🙆🏻‍♀️ Cecan Menu", description: "Menampilkan Cecan Menu 🙆🏻‍♀️", id: `${_p}cecanmenu` },
                { title: "🔖 Tools Menu", description: "Menampilkan Tools Menu 🔖", id: `${_p}toolsmenu` },
                { title: "🎙️ Voice Menu", description: "Menampilkan Voice Menu 🎙️", id: `${_p}voicemenu` },
                { title: "☪️ Islamic Menu", description: "Menampilkan Islamic Menu ☪️", id: `${_p}islammenu` },
                { title: "✍🏻 Maker Menu", description: "Menampilkan Maker Menu ✍🏻", id: `${_p}makermenu` },
                { title: "🪄 Stalk Menu", description: "Menampilkan Stalk Menu 🪄", id: `${_p}stalkmenu` },
                { title: "⛩️ Anime Menu", description: "Menampilkan Anime Menu ⛩️", id: `${_p}animemenu` },
                { title: "🔏 Encrypt Menu", description: "Menampilkan Encrypt Menu 🔏", id: `${_p}encryptmenu` },
                { title: "🎁 Others Menu", description: "Menampilkan Others Menu 🎁", id: `${_p}othersmenu` },
              ]
            },
            {
              title: "🐾 Bug/Virtex",
              highlight_label: "System Killer",
              rows: [
                { title: "⚖️ Bug Menu", description: "Menampilkan Menu Bug ⚖️", id: `${_p}bugmenu` },
              ]
            },
            {
              title: "🕊️ Tentang Bot Ini",
              highlight_label: "Script Bot Premium",
              rows: [
                { title: "💳 Bot Script", description: "Menampilkan Script Bot 💳", id: `${_p}script` },
                { title: "📑 Bot Information", description: "Menampilkan Informasi Bot 📑", id: `${_p}infobot` },
              ]
            },
          ],
        }),
      },
    },
  ]
}