require('../telegram/lib-signal/setting-tele');
const setupCallbackHandlers = require('../telegram/lib-signal/callback');
const {
  Telegraf,
  Markup
} = require('telegraf');
const fetch = require('node-fetch');
const axios = require('axios');
const BOT_TOKEN = global.teleToken;
const userCooldown = new Map();
const fs = require('fs')
const chalk = require('chalk')
const crypto = require('crypto')
const FormData = require('form-data');
const cheerio = require("cheerio")
const path = require('path');
const pathDb = path.resolve(__dirname, 'database/database.json');
const codeBlock = require('../telegram/lib-signal/sendCode'); 
let settingPath = path.resolve(__dirname, 'config-setting.json');
let setting = JSON.parse(fs.readFileSync(settingPath));
const {
  checkSimilarity,
  totalFitur,
  createPanel
} = require('../telegram/lib-signal/handler')
const teaturedtotals = totalFitur();
const formatAudio = ['mp3', 'm4a'];
const formatVideo = ['mp4', '360', '480', '720', '1080'];

const lyreact = async (Lyrra, emoji = messWait) => {
  await Lyrra.reply(emoji, {
    reply_to_message_id: Lyrra.message.message_id
  })
}

// ====================== LOAD DATABASE ======================
let rawDb = {};

try {
  if (fs.existsSync(pathDb)) {
    rawDb = JSON.parse(fs.readFileSync(pathDb, 'utf8'));
  } else {
    rawDb = { data: { users: {}, rpg: {}, others: {}, settings: {} } };
    fs.writeFileSync(pathDb, JSON.stringify(rawDb, null, 2));
  }

  rawDb.data = {
    users: rawDb.data?.users || {},
    rpg: rawDb.data?.rpg || {},
    others: rawDb.data?.others || {},
    settings: rawDb.data?.settings || {}
  };

  global.db = rawDb;
  console.log('✅ Database berhasil dimuat.');
} catch (err) {
  console.error('❌ Gagal memuat database. Coba hapus file dan jalankan ulang.');
  rawDb = {
    data: {
      users: {},
      rpg: {},
      others: {},
      settings: {}
    }
  };
  global.db = rawDb;
}


global.ytmp4LinkCache = global.ytmp4LinkCache || new Map();

// =============== DEEPFAKE MAKER CLIENT ===============
class DeepFakeMakerClient {
  constructor() {
    this.baseUrl = "https://apiv1.deepfakemaker.io";
    this.PUBLIC_KEY = `MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDa2oPxMZe71V4dw2r8rHWt59gH
W5INRmlhepe6GUanrHykqKdlIB4kcJiu8dHC/FJeppOXVoKz82pvwZCmSUrF/1yr
rnmUDjqUefDu8myjhcbio6CnG5TtQfwN2pz3g6yHkLgp8cFfyPSWwyOCMMMsTU9s
snOjvdDb4wiZI8x3UwIDAQAB`;
    this.appId = "ai_df";
    this.appSecret = "NHGNy5YFz7HeFb";
    this.userID = DeepFakeMakerClient.randomString(64);
  }

  static randomString(n = 16) {
    return Array.from({ length: n }, () =>
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".charAt(
        Math.floor(Math.random() * 62)
      )
    ).join("");
  }

  static aesEncryptBase64(text, keyStr) {
    const buf = Buffer.from(keyStr, "utf8");
    const cipher = crypto.createCipheriv("aes-128-cbc", buf, buf);
    let enc = cipher.update(text, "utf8", "base64");
    return enc + cipher.final("base64");
  }

  generateParams() {
    const t = Math.floor(Date.now() / 1000);
    const nonce = this.userID;
    const secret = DeepFakeMakerClient.randomString(16);
    const secret_key = crypto
      .publicEncrypt(
        { key: this.PUBLIC_KEY, padding: crypto.constants.RSA_PKCS1_PADDING },
        Buffer.from(secret, "utf8")
      )
      .toString("base64");
    const signPayload = `${this.appId}:${this.appSecret}:${t}:${nonce}:${secret_key}`;
    const sign = DeepFakeMakerClient.aesEncryptBase64(signPayload, secret);
    return { app_id: this.appId, t, nonce, sign, secret_key };
  }

  async getUploadSign(fileBuffer) {
    const resp = await axios.post(
      `${this.baseUrl}/api/user/v2/upload-sign`,
      {
        filename: `NB_${DeepFakeMakerClient.randomString(32)}_${Date.now()}.png`,
        hash: crypto.createHash("sha256").update(fileBuffer).digest("hex"),
        user_id: this.userID,
      },
      {
        params: this.generateParams(),
        headers: {
          accept: "*/*",
          "content-type": "application/json",
          origin: "https://deepfakemaker.io",
          referer: "https://deepfakemaker.io/",
        },
      }
    );
    return resp.data.data;
  }       
    


  async uploadFileToUrl(fileBuffer) {
    const { url, object_name } = await this.getUploadSign(fileBuffer);
    await axios.put(url, fileBuffer, {
      headers: {
        "Content-Type": "image/png",
        "Content-Length": fileBuffer.length,
      },
    });
    return `https://cdn.deepfakemaker.io/${object_name}`;
  }

  async createTask(prompt, imageUrl, output_format = "png") {
    const resp = await axios.post(
      `${this.baseUrl}/api/replicate/v1/free/nano/banana/task`,
      {
        prompt,
        platform: "nano_banana",
        images: [imageUrl],
        output_format,
        user_id: this.userID,
      },
      {
        params: this.generateParams(),
        headers: {
          accept: "*/*",
          "content-type": "application/json",
          origin: "https://deepfakemaker.io",
          referer: "https://deepfakemaker.io/",
        },
      }
    );
    return resp.data.data.task_id;
  }

  async waitForTask(taskId) {
    while (true) {
      const resp = await axios.get(
        `${this.baseUrl}/api/replicate/v1/free/nano/banana/task`,
        {
          params: { ...this.generateParams(), task_id: taskId, user_id: this.userID },
          headers: {
            accept: "*/*",
            origin: "https://deepfakemaker.io",
            referer: "https://deepfakemaker.io/",
          },
        }
      );
      const body = resp.data;
      if (body && body.msg === "success" && body.data) {
        return body.data;
      } else if (body && body.msg !== "processing" && body.data) {
        throw new Error(body.msg || "Task gagal");
      }
      await new Promise((res) => setTimeout(res, 5000));
    }
  }
}
 // ======== END ======== //

function parseDuration(durationStr) {
  if (durationStr.toLowerCase() === 'permanen') return 'Permanen';
  const match = durationStr.match(/^(\d+)([dhm])$/i);
  if (!match) return null;
  const num = parseInt(match[1], 10);
  const unit = match[2].toLowerCase();
  if (unit === 'd') return Date.now() + num * 24 * 60 * 60 * 1000;
  if (unit === 'h') return Date.now() + num * 60 * 60 * 1000;
  if (unit === 'm') return Date.now() + num * 60 * 1000;
  return null;
}

      // ==========   Helper Premium User  ============ //
function formatTime(ms) {
  if (ms <= 0) return '0 menit';
  const days = Math.floor(ms / (24 * 60 * 60 * 1000));
  const hours = Math.floor((ms % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
  const minutes = Math.floor((ms % (60 * 60 * 1000)) / (60 * 1000));
  return `${days} hari, ${hours} jam, ${minutes} menit`;
}
const PREMIUM_FILE = path.join(__dirname, 'database', 'premium.json');
if (!fs.existsSync(PREMIUM_FILE)) fs.writeFileSync(PREMIUM_FILE, '[]');
          // ==========   End  ============ //

function saveDatabase() {
  fs.writeFileSync(pathDb, JSON.stringify(db, null, 2));
}

let saveTimeout = null;
function scheduleSave() {
  if (saveTimeout) clearTimeout(saveTimeout);
  saveTimeout = setTimeout(() => {
    try {
      fs.writeFileSync(pathDb, JSON.stringify(db, null, 2));
    } catch (err) {
      console.error('❌ Gagal menyimpan database:', err);
    }
  }, 1000);
}
// ======== Escape MarkdownV2 Function ======== //
function escapeMarkdown(text = '') {
  return text.replace(/([_*\[\]()~`>#+\-=|{}.!\\])/g, '\\$1');
}

// ======== User Language Function ======== //
function getUserLang(userId) {
  const user = global.db.data.users[userId] || {};
  const lang = user.bahasa;

  const validLangs = ['Indonesia','Melayu','English','日本語','中文'];
  if (validLangs.includes(lang)) return lang;

  return 'Indonesia'; // default bahasa
}

global.saveDatabase = function (db) {
  try {
    fs.writeFileSync(pathDb, JSON.stringify(db, null, 2));
  } catch (e) {
    console.error('Gagal menyimpan database:', e.message);
  }
};


global.i18n = {
  Indonesia: {
    greeting: "Halo!",
    help: "Gunakan tombol di bawah untuk menjelajahi fitur bot.",
    info_title: "Informasi Bot",
    info_text: "Saya adalah bot Telegram canggih yang dibuat untuk membantu Anda.",
    settings_title: "Pengaturan Bot",
    lang_choose: "Silakan pilih bahasa yang ingin digunakan:",
    lang_set: "Bahasa berhasil diubah ke",
    not_allowed: "Anda tidak memiliki izin untuk melihat informasi ini.",
    back: "⬅️ Kembali",
    menu_main: "🏠 Menu Utama",
    bot_label: "Bot",
    made_by: "Dibuat dengan ❤️ oleh @rbonlym",
    setting_not_available: "Pengaturan belum tersedia.",
    error_generic: "⚠️ Terjadi kesalahan. Coba lagi nanti."
  },
  Melayu: {
    greeting: "Hai!",
    help: "Gunakan butang di bawah untuk meneroka ciri bot.",
    info_title: "Maklumat Bot",
    info_text: "Saya bot Telegram pintar yang dicipta untuk membantu anda.",
    settings_title: "Tetapan Bot",
    lang_choose: "Sila pilih bahasa yang ingin digunakan:",
    lang_set: "Bahasa telah ditukar kepada",
    not_allowed: "Anda tidak mempunyai kebenaran untuk melihat maklumat ini.",
    back: "⬅️ Kembali",
    menu_main: "🏠 Menu Utama",
    bot_label: "Bot",
    made_by: "Dibuat dengan ❤️ oleh @rbonlym",
    setting_not_available: "Tetapan belum tersedia.",
    error_generic: "⚠️ Ralat berlaku. Cuba lagi nanti."
  },
  English: {
    greeting: "Hello!",
    help: "Use the buttons below to explore bot features.",
    info_title: "Bot Information",
    info_text: "I'm a smart Telegram bot built to assist you.",
    settings_title: "Bot Settings",
    lang_choose: "Please select the language you want to use:",
    lang_set: "Language has been changed to",
    not_allowed: "You are not allowed to view this information.",
    back: "⬅️ Back",
    menu_main: "🏠 Main Menu",
    bot_label: "Bot",
    made_by: "Created with ❤️ by @rbonlym",
    setting_not_available: "Settings not available yet.",
    error_generic: "⚠️ An error occurred. Please try again."
  },
  日本語: {
    greeting: "こんにちは！",
    help: "下のボタンを使ってボットの機能を確認してください。",
    info_title: "ボット情報",
    info_text: "私はあなたを助けるために作られたスマートなTelegramボットです。",
    settings_title: "ボット設定",
    lang_choose: "使用したい言語を選択してください：",
    lang_set: "言語が変更されました：",
    not_allowed: "この情報を見る権限がありません。",
    back: "⬅️ 戻る",
    menu_main: "🏠 メインメニュー",
    bot_label: "ボット",
    made_by: "@rbonlym ❤️で作られました -",
    setting_not_available: "設定はまだ利用できません。",
    error_generic: "⚠️ エラーが発生しました。もう一度お試しください。"
  },
  中文: {
    greeting: "你好！",
    help: "使用下面的按钮浏览机器人的功能。",
    info_title: "机器人信息",
    info_text: "我是一个为帮助你而创建的智能Telegram机器人。",
    settings_title: "机器人设置",
    lang_choose: "请选择要使用的语言：",
    lang_set: "语言已更改为",
    not_allowed: "您没有权限查看此信息。",
    back: "⬅️ 返回",
    menu_main: "🏠 主菜单",
    bot_label: "机器人",
    made_by: "@rbonlym ❤️ 由以下人员创建 -",
    setting_not_available: "设置暂不可用。",
    error_generic: "⚠️ 发生错误，请稍后再试。"
  }
};

function escapeHTML(s = '') {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}


function createAutoSaveProxy(obj) {
  return new Proxy(obj, {
    set(target, prop, value) {
      target[prop] = (typeof value === 'object' && value !== null)
        ? createAutoSaveProxy(value)
        : value;
      scheduleSave();
      return true;
    },
    deleteProperty(target, prop) {
      delete target[prop];
      scheduleSave();
      return true;
    },
    get(target, prop) {
      if (typeof target[prop] === 'object' && target[prop] !== null) {
        return createAutoSaveProxy(target[prop]);
      }
      return target[prop];
    }
  });
}
const db = createAutoSaveProxy(rawDb);

const CONFIG_TELE = {
  ADMIN_IDS: [idAdmins],
  ERROR_CHANNEL_ID: -1003182420264,
  COMMANDS: {
    START: 'start',
    HELP: 'help',
    INFO: 'info',
    SETTINGS: 'settings',
    STATS: 'stats'
  },
  MESSAGES: {
    WELCOME: `✨ Hallo! Saya ${botname2} bot Telegram canggih, Yang diciptakan oleh seorang jenius yang bernama ${ownername2}\nGunakan /menu untuk melihat fitur yang tersedia.`,
    HELP: `📋 &quot;Perintah yang tersedia:&quot;
/start - Mulai bot
/help - Bantuan
/info - Informasi bot
/settings - Pengaturan


🌴 &quot;List Menu&quot;
&quot;/allmenu - Menampilkan All Menu&quot;
&quot;/menuperintah - Menampilkan Menu Perintah / help&quot;
&quot;/menudownload - Menampilkan Menu Download&quot;
&quot;/menuislamic - Menampung Menu Islam&quot;
&quot;/menusearch - Menampilkan Menu Search&quot;
&quot;/menuowner - Menampilkan Menu Owner&quot;
&quot;/menunsfw - Menampilkan Nsfw Menu&quot;
&quot;/menurpg - Menampilkan Rpg Menu&quot;
&quot;/menuanime - Menampilkan Anime Menu&quot;
&quot;/menuother - Menampilkan Other Menu&quot;

Feature Aktif : ${teaturedtotals}
©${botname2}`,
  },
  ERROR_MESSAGES: {
    DEFAULT: '⚠️ Terjadi kesalahan. Silakan coba lagi nanti.',
    ADMIN_ONLY: '⛔ Perintah ini hanya untuk admin!'
  }
};

const handlerlist = {
  perintah: [
    '/start',
    '/help',
    '/info',
    '/settings'
  ],
  download: [
    '/tiktok',
    '/ttaudio',
    '/pinterest',
    '/play',
    '/douyin',
    '/instagram',
    '/mediafire',
    '/facebook',
    '/twitter',
    '/threads',
    '/capcut',
    '/spotify',
    '/gdrive',
    '/terabox',
    '/xvideodl',
    '/xnxxdl',
    '/pinterest',
    '/pastebin',
    '/lirik',
    '/ytmp3',
    '/ytmp4'
  ],
  group: [
      '/autowelcome (on/off)',
      '/autogoodbye (on/off)',
      '/setwelcome',
      '/pincomment'
  ],
  search: [
    '/play',
    '/pinterest'
  ],
  tools: [
    '/hd    (reply photo)',
    '/hdvid (reply video)'
  ],
    islamic: [
    '/jadwalsholat',
    '/alquran',
    '/asmaulhusna',
    '/niatsholat',
    '/surah',
    '/berdoa',
    '/ayatkursi',
    '/gislam',
    '/kataislam',
    '/pantunislam'
  ],
  owner: [
      '/addreseller',
      '/backup',
      '/addcase',
      '/delcase',
      '/getcase',
  ],
  panel: [
      '/1gb',
      '/2gb',
      '/3gb',
      '/4gb',
      '/5gb',
      '/6gb',
      '/7gb',
      '/8gb',
      '/9gb',
      '/10gb',
      '/unli',
      '/addres',
      '/delres'
  ],
  nsfw: [
    '/waifu',
    '/paptt',
    '/neko',
    '/shinobu',
    '/megumin',
    '/bully',
    '/cuddle',
    '/cry',
    '/hug',
    '/awoo',
    '/kiss',
    '/lick',
    '/pat',
    '/smug',
    '/bonk',
    '/yeet',
    '/blush',
    '/smile',
    '/wave',
    '/highfive',
    '/handhold',
    '/nom',
    '/bite',
    '/glomp',
    '/slap',
    '/kill',
    '/happy',
    '/wink',
    '/poke',
    '/dance',
    '/cringe',
    '/trap',
    '/blowjob',
    '/hentai',
    '/boobs',
    '/ass',
    '/pussy',
    '/thighs',
    '/lesbian',
    '/lewdneko',
    '/cum'
  ],
  rpg: [
    '/joinrpg',
    '/exitrpg',
    '/inventory'
  ],
  anime: [
    '/akiyama',
    '/ana',
    '/art',
    '/asuna',
    '/ayuzawa',
    '/boruto',
    '/bts',
    '/cartoon',
    '/chiho',
    '/chitoge',
    '/cosplay',
    '/cosplayloli',
    '/cosplaysagiri',
    '/cyber',
    '/deidara',
    '/doraemon',
    '/elaina',
    '/emilia',
    '/erza',
    '/exo',
    '/gamewallpaper',
    '/gremory',
    '/hacker',
    '/hestia',
    '/hinata',
    '/husbu',
    '/inori',
    '/islamic',
    '/isuzu',
    '/itachi',
    '/itori',
    '/jennie',
    '/jiso',
    '/justina',
    '/kaga',
    '/kagura',
    '/kakasih',
    '/kaori',
    '/keneki',
    '/kotori',
    '/kurumi',
    '/lisa',
    '/madara',
    '/megumin',
    '/mikasa',
    '/mikey',
    '/miku',
    '/minato',
    '/mountain',
    '/naruto',
    '/neko2',
    '/nekonime',
    '/nezuko',
    '/onepiece',
    '/pentol',
    '/pokemon',
    '/programming',
    '/randomnime',
    '/randomnime2',
    '/rize',
    '/rose',
    '/sagiri',
    '/sakura',
    '/sasuke',
    '/satanic',
    '/shina',
    '/shinka',
    '/shinomiya',
    '/shizuka',
    '/shota',
    '/shortquote',
    '/space',
    '/technology',
    '/tejina',
    '/toukachan',
    '/tsunade',
    '/yotsuba',
    '/yuki',
    '/yulibocil',
    '/yumeko'
  ],
  other: [
    '/daftar',
    '/sticker',
    '/totalfitur'
  ]
}

const startTelegramBot = () => {
try {
  console.log('Bot telegram berhasil tersambung..');
  if (!BOT_TOKEN) {
    console.error('Token Telegram kamu tidak valid / tidak ditemukan!');
    return;
  }

  const Lyrra = new Telegraf(BOT_TOKEN);

  Lyrra.use(async (Lyrra, next) => {
    try {
      await next();
    } catch (err) {
      console.error('Bot error:', err);
      if (Lyrra.reply) {
        await Lyrra.reply(CONFIG_TELE.ERROR_MESSAGES.DEFAULT);
      }
      await Lyrra.telegram.sendMessage(
        CONFIG_TELE.ERROR_CHANNEL_ID,
        `🚨 <b>Error:</b>\n<code>${err.message}</code>`, {
          parse_mode: 'HTML'
        }
      );
    }
  });

  Lyrra.use((Lyrra, next) => {
    Lyrra.isAdmin = Lyrra.from?.id && CONFIG_TELE.ADMIN_IDS.includes(Lyrra.from.id);
    return next();
  });

  Lyrra.on('message', async (Lyrra, next) => {
    const sender = Lyrra.from.id.toString();
    if (!db.data.users[sender]) {
      db.data.users[sender] = {
        nama: Lyrra.from.first_name,
        umur: 0,
        daftar: false,
        banned: false,
        Lyrra: false,
        rpg: false,
        saldo: 5000,
        limit: 99999,
        exp: 3357
      };
    }
    next();
  })

// Auto welcome & goodbye config
const WELCOME_FILE = path.join(__dirname, 'database', 'welcome.json');
if (!fs.existsSync(WELCOME_FILE)) fs.writeFileSync(WELCOME_FILE, '{}');
let welcomeConfig = JSON.parse(fs.readFileSync(WELCOME_FILE, 'utf8'));

Lyrra.on('text', async (Lyrra) => {
  const fullText = Lyrra.message.text || '';
  const prefix = fullText.match(/^[°zZ#@+,.?=''():√%!¢£¥€π¤ΠΦ_&™©®Δ^βα¦|/\\©^]/)?.[0] || '.';
  const isCmd = fullText.startsWith(prefix);
  const command = isCmd ? fullText.slice(prefix.length).trim().split(' ')[0].toLowerCase() : '';
  
  const text = fullText.split(' ').slice(1).join(' ');
  const args = fullText.split(' ').slice(1);
  const sender = Lyrra.from.id.toString();
  const isAdmin = Lyrra.isAdmin;
  const now = Date.now();
  const cooldown = 3000; // 3 detik

// ========== CEK KEANGGOTAAN GRUP WAJIB ==========
const REQUIRED_CHAT_ID = -1003182420264; // Ganti dengan Chat ID grup kamu
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function isMemberOfRequiredGroup(userId) {
  try {
    const member = await Lyrra.telegram.getChatMember(REQUIRED_CHAT_ID, userId);
    return !['left', 'kicked'].includes(member.status);
  } catch (err) {
    console.error('Error cek keanggotaan grup:', err.message);
    return false;
  }
}

async function edit2(text1, text2) {
  const msgs = [text1, text2];
  const sent = await Lyrra.reply("Loading...");

  for (let i = 0; i < msgs.length; i++) {
    await sleep(800);
    await Lyrra.telegram.editMessageText(
      sent.chat.id,
      sent.message_id,
      undefined,
      msgs[i]
    );
  }
}

if (Lyrra.chat.type === 'private') {
  const isMember = await isMemberOfRequiredGroup(Lyrra.from.id);
  if (!isMember) {
    const jsSnippet = `//🔒 AKSES PRIVATE CHAT DITOLAK 🔒
---KAMU TERDETEKSI DILUAR GRUP!---
KETUK JOIN GRUP, LALU KEMBALI BUKA BOT DAN KETUK VERIFIKASI
MAKA AKSES PRIVATE CHAT BOT AKAN DIBUKA.

© ${wm2}`;

    const caption = `\`\`\`javascript\n${jsSnippet}\n\`\`\``;

    await Lyrra.replyWithVideo(
      { url: global.thumb33 },
      {
        caption,
        parse_mode: 'MarkdownV2',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🚪 JOIN GRUP', callback_data: 'join_group' },
              { text: '✅ VERIFIKASI', callback_data: 'verify_group' }
            ]
          ]
        }
      }
    );
    return;
  }
}

// ========== END CEK GRUP ==========
 
if (isCmd) {
  if (userCooldown.has(sender)) {
    const lastUsed = userCooldown.get(sender);
    if (now - lastUsed < cooldown) { // cooldown = 3000 (3 detik)
      const remaining = Math.ceil((cooldown - (now - lastUsed)) / 1000); // Pembagian benar untuk detik
      return Lyrra.reply(`⏳ *COOLDOWN*
Tunggu ${remaining} detik sebelum menggunakan command lagi.`);
    }
  }
  userCooldown.set(sender, now);
  if (userCooldown.size > 1000) {
    userCooldown.clear();
  }
}
    if (Lyrra.message && Lyrra.message.text && isCmd) {
      const user = Lyrra.from;
      const time = new Date().toLocaleTimeString('id-ID', {
        hour12: false
      });
      const isGroup = !!Lyrra.chat?.type?.includes('group');
      const senderName = user.first_name || 'Unknown';
      const args = fullText.split(' ').slice(1)

      const getDtckMsg = `
✧⋅──────⋅✦⋅──────⋅✧
│  ${chalk.bold.magenta('✧ TELEGRAM MESSAGE ✧')}
✧⋅──────⋅✦⋅──────⋅✧
│  ${chalk.cyan('⏳')} ${chalk.white('Time   :')} ${chalk.yellow(time)}
│  ${chalk.cyan('📩')} ${chalk.white('Chat   :')} ${chalk.green(isGroup ? 'Group 👥' : 'Private 🔒')}
│  ${chalk.cyan('👤')} ${chalk.white('Sender :')} ${chalk.hex('#FFA500')(senderName)}
│  ${chalk.cyan('✨')} ${chalk.white('Cmd    :')} ${chalk.redBright(command)}
✧⋅──────⋅✦⋅──────⋅✧`;

      console.log(getDtckMsg);
    }

// ===== CEK SIMILAR COMMAND DULU =====
if (isCmd) {
  if (!["start", "info", "settings", "help", "stats"].includes(command)) {
    const similar = checkSimilarity(command)
    if (similar) {
      await Lyrra.reply(`⚠️ *Command tidak ditemukan* Mungkin maksud kamu: /${similar.match} Kemiripan: ${similar.similarity}%`)
      return
    }
  }
}

if (isCmd) {
  if (db.data.users[sender].limit < 1) return Lyrra.reply(`Limit kamu sudah habis`)
  db.data.users[sender].limit -= 1
}

// ========== MULAI SWITCH CASE ==========
switch (command) {

case 'start': {
  try {
    const args = Lyrra.startPayload || (Lyrra.message?.text?.split(' ')[1]) || '';
    const user = Lyrra.from;
    const userId = user.id;

    // Ambil bahasa user dari database
    const lang = getUserLang(userId);

    // ================== CEKID DEEP LINK ==================
    if (args === 'cekid') {
      const username = user.username ? `@${user.username}` : '❌ Tidak ada username';
      const firstName = user.first_name || '-';
      const lastName = user.last_name ? ` ${user.last_name}` : '';
      const fullName = `${firstName}${lastName}`;

      const infoHtml = `🧩 <b>${global.i18n[lang].info_title}</b>\n\n` +
        `🙋‍♂️ <b>Nama:</b> ${escapeHTML(fullName)}\n` +
        `🆔 <b>User ID:</b> <code>${escapeHTML(String(userId))}</code>\n` +
        `🌐 <b>Username:</b> ${escapeHTML(username)}\n\n` +
        `© ${escapeHTML(global.wm2)}`;

      await Lyrra.reply(infoHtml, { parse_mode: 'HTML' });
      break;
    }

    // ================== START BIASA ==================
    const botInfo = await Lyrra.telegram.getMe();

    const startSnippet = `
✨ ${global.i18n[lang].greeting}
${global.i18n[lang].help}

🤖 ${escapeHTML(botInfo.first_name || botInfo.username)}
© ${escapeHTML(global.wm2)}
`;
    await Lyrra.replyWithPhoto(
      { url: global.thumb22 },
      {
        caption: `\`\`\`V1-ONLym\n${startSnippet}\n\`\`\``,
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [
              { text: 'ℹ️ Info', callback_data: 'show_info' },
              { text: '⚙️ Settings', callback_data: 'show_settings' }
            ],
            [
              { text: '📋 Buka Menu', callback_data: 'menu_open' }
            ]
          ]
        }
      }
    );

  } catch (err) {
    console.error('❌ Error di /start:', err);
    await Lyrra.reply('⚠️ Gagal memproses perintah start.');
  }
  break;
}

case 'menu':
case `${CONFIG_TELE.COMMANDS.HELP}`: {
  const userId = Lyrra.from.id;
  const lang = getUserLang(userId); // ambil bahasa user

  // Inline keyboard menu utama
  const inlineKeyboard = [
    [
      { text: '📥 Perintah', callback_data: 'menu_perintah' },
      { text: '💾 Download', callback_data: 'menu_download' }
    ],
    [
      { text: '☪️ Islamic', callback_data: 'menu_islamic' },
      { text: '🔍 Search', callback_data: 'menu_search' }
    ],
    [
      { text: '👑 Owner', callback_data: 'menu_owner' },
      { text: '🔞 NSFW', callback_data: 'menu_nsfw' }
    ],
    [
      { text: '⚔️ RPG', callback_data: 'menu_rpg' },
      { text: '🖼️ Anime', callback_data: 'menu_anime' }
    ],
    [
      { text: '📦 Other', callback_data: 'menu_other' },
      { text: '⚙️ Tools', callback_data: 'menu_tools' }
    ],
    [
      // Tambahkan tombol Setting Bahasa
      { text: '🌐 Language', callback_data: 'settings_lang' }
    ]
  ];

  const jsSnippet = `// Info Bot
✨ ${global.i18n[lang].greeting} ${global.botname2 || 'Bot'} Bot Telegram
${global.i18n[lang].help}

© ${wm2 || ''}`;

  const caption = `\`\`\`${global.storename2}\n${jsSnippet}\n\`\`\``;

  await Lyrra.replyWithPhoto(
    { url: thumb22 },
    {
      caption,
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: inlineKeyboard }
    }
  );
  break;
}


    case 'menuall':
    case 'allmenu': {
      let text = '';
      Object.keys(handlerlist).forEach(key => {
        if (key === 'perintah') {
          text += `📋 ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'download') {
          text += `💾 ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'group') {
          text += `👥 ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'islamic') {
          text += `☪️ ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'search') { 
          text += `🔍 ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'tools') {
          text += `⚙️ ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'owner (OWNER ONLY)') {
          text += `👑 ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'cpanel (RESELLER ONLY)') {
          text += `💻 ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'nsfw (PREMIUM ONLY)') {
          text += `🔞 ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'rpg') {
          text += `⚔️ ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'anime') {
          text += `🖼️ ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'other') {
          text += `📥 ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        }
        handlerlist[key].forEach(item => {
          text += `${item}\n`;
        });
        text += '\n';
      })
      Lyrra.reply(text)
    }
    break

    case 'perintahmenu':
    case 'menuperintah': {
      let text = '📋 Perintah Menu\n';
      handlerlist.perintah.forEach(item => {
        text += `${item}\n`;
      });
      Lyrra.reply(text);
    }
    break

    case 'downloadmenu':
    case 'menudownload': {
      let text = '💾 Download Menu\n';
      handlerlist.download.forEach(item => {
        text += `${item}\n`;
      });
      Lyrra.reply(text);
    }
    break 

    case 'groupmenu':
    case 'menugroup': {
      let text = '👥 Group Menu\n';
      handlerlist.download.forEach(item => {
        text += `${item}\n`;
      });
      Lyrra.reply(text);
    }
    break

    case 'toolsmenu':
    case 'menutools': {
      let text = '⚙️ Tools Menu\n';
      handlerlist.download.forEach(item => {
        text += `${item}\n`;
      });
      Lyrra.reply(text);
    }
    break 

    case 'islamicmenu':
    case 'menuislamic': {
      let text = '☪️ Islamic Menu\n';
      handlerlist.islamic.forEach(item => {
        text += `${item}\n`;
      });
      Lyrra.reply(text);
    }
    break

    case 'searchmenu':
    case 'menusearch': {
      let text = '🔍 Search Menu\n';
      handlerlist.search.forEach(item => {
        text += `${item}\n`;
      });
      Lyrra.reply(text);
    }
    break

    case 'ownermenu':
    case 'menuowner': {
      let text = '👑 Owner Menu\n';
      handlerlist.owner.forEach(item => {
        text += `${item}\n`;
      });
      Lyrra.reply(text);
    }
    break

    case 'cpanelmenu':
    case 'menucpanel': {
      let text = '💻 Panel Menu\n';
      handlerlist.panel.forEach(item => {
        text += `${item}\n`;
      });
      Lyrra.reply(text);
    }
    break

    case 'nsfwmenu':
    case 'menunsfw': {
      let text = '🔞 Nsfw Menu\n';
      handlerlist.nsfw.forEach(item => {
        text += `${item}\n`;
      });
      Lyrra.reply(text);
    }
    break

    case 'rpgmenu':
    case 'menurpg': {
      let text = '⚔️ Rpg Menu\n';
      handlerlist.rpg.forEach(item => {
        text += `${item}\n`;
      });
      Lyrra.reply(text);
    }
    break

    case 'animemenu':
    case 'menuanime': {
      let text = '🖼️ Anime Menu\n';
      handlerlist.anime.forEach(item => {
        text += `${item}\n`;
      });
      Lyrra.reply(text);
    }
    break

    case 'othermenu':
    case 'menuother': {
      let text = '📥 Other Menu\n';
      handlerlist.other.forEach(item => {
        text += `${item}\n`;
      });
      Lyrra.reply(text);
    }
    break

    case `${CONFIG_TELE.COMMANDS.INFO}`: {
      const botInfo = await Lyrra.telegram.getMe();
      return Lyrra.replyWithHTML(`🤖 <b>Bot:</b> @${botInfo.username}`);
    }
    break

    case `${CONFIG_TELE.COMMANDS.STATS}`: {
      if (!isAdmin) return Lyrra.reply(CONFIG_TELE.ERROR_MESSAGES.ADMIN_ONLY);
      return Lyrra.reply(`📊 Total uptime: ${process.uptime().toFixed(1)}s`);
    }
    break

    case 'jadwalsholat': {
      if (!text) return Lyrra.reply('Mau kota mana?')
      const kota = text.toLowerCase().replace(/\s+/g, '-')
      try {
        const {
          data
        } = await axios.get(`https://jadwal-sholat.tirto.id/kota-${kota}`)
        const $ = cheerio.load(data)
        const jadwalHariIni = $('tr.currDate td').map((i, el) => $(el).text()).get()

        const [tanggal, subuh, duha, dzuhur, ashar, maghrib, isya] = jadwalHariIni

        const jdwl = `
*JADWAL SHOLAT UNTUK HARI INI*
Tanggal: ${tanggal}
- Subuh: ${subuh}
- Dhuha: ${duha}
- Dzuhur: ${dzuhur}
- Ashar: ${ashar}
- Maghrib: ${maghrib}
- Isya: ${isya}
      `.trim()

        Lyrra.reply(jdwl)
      } catch (err) {
        console.error(err)
        Lyrra.reply('Terjadi kesalahan: ' + err.message)
      }
    }
    break

    case 'alquran': {
      if (!(args[0] && args[1])) {
        return Lyrra.reply(`• *Contoh:* /alquran 1 2\nHasilnya adalah surah Al-Fatihah ayat 2`, {
          parse_mode: "Markdown"
        })
      }

      if (isNaN(args[0]) || isNaN(args[1])) {
        return Lyrra.reply(`• *Contoh:* /alquran 1 2\nGunakan angka untuk surah dan ayat`, {
          parse_mode: "Markdown"
        })
      }

      try {
        const res = await fetch(`https://kalam.sindonews.com/ayat/${args[1]}/${args[0]}`)
        if (!res.ok) return Lyrra.reply('Terjadi kesalahan saat mengambil data.')

        const html = await res.text()
        const $ = cheerio.load(html)
        const content = $('body > main > div > div.content.clearfix > div.news > section > div.list-content.clearfix')
        const Surah = $(content).find('div.ayat-title > h1').text()
        const arab = $(content).find('div.ayat-detail > div.ayat-arab').text()
        const latin = $(content).find('div.ayat-detail > div.ayat-latin').text()
        const terjemahan = $(content).find('div.ayat-detail > div.ayat-detail-text').text()

        let tafsir = ''
        $(content).find('div.ayat-detail > div.tafsir-box > div').each(function () {
          tafsir += $(this).text() + '\n'
        })
        tafsir = tafsir.trim()

        const hasil = `
${arab}
${latin}

${terjemahan}
${tafsir}

( ${Surah} )
`.trim()

        Lyrra.reply(hasil)
      } catch (err) {
        console.error(err)
        Lyrra.reply('Terjadi kesalahan: ' + err)
      }
    }
    break

    case 'asmaulhusna': {
      try {
        const res = await fetch('https://islamic-api-zhirrr.vercel.app/api/asmaulhusna');
        const data = await res.json();
        const ye = data.data;

        const tks = '*ASMAUL HUSNA*\n\n' + ye.map((item) => {
          return `Urutan: ${item.index}\nLatin: ${item.latin}\nArab: ${item.arabic}\nTerjemahan ID: ${item.translation_id}\nTerjemahan EN: ${item.translation_en}\n`;
        }).join('\n');

        await Lyrra.reply(tks, {
          parse_mode: 'Markdown'
        });
      } catch (err) {
        console.error(err);
        await Lyrra.reply('Error cuy, coba lagi ntar!');
      }
    }
    break

    case 'niatsholat': {
      const fullText = Lyrra.message.text || '';
      const text = fullText.split(' ').slice(1).join(' ');

      try {
        const res = await fetch('https://islamic-api-zhirrr.vercel.app/api/niatshalat');
        const niatSholat = await res.json();

        if (!text) {
          let daftarNiat = '*DAFTAR NIAT SHOLAT*\n\n' + niatSholat.map((item) => `- ${item.name}`).join('\n');
          daftarNiat += `\n\nKetik *${Lyrra.message.text.split(' ')[0]} [nama sholat]* untuk melihat niat\nContoh: *${Lyrra.message.text.split(' ')[0]} subuh*`;
          await Lyrra.reply(daftarNiat, {
            parse_mode: 'Markdown'
          });
        } else {
          const hasil = niatSholat.find((item) =>
            item.name.toLowerCase().includes(text.toLowerCase())
          );

          if (hasil) {
            const tks = `*${hasil.name.toUpperCase()}*\n\n` +
              `*Arab:* ${hasil.arabic}\n` +
              `*Latin:* ${hasil.latin}\n` +
              `*Terjemahan:* ${hasil.terjemahan}`;
            await Lyrra.reply(tks, {
              parse_mode: 'Markdown'
            });
          } else {
            await Lyrra.reply('Niat sholat yang kamu cari tidak ditemukan. Coba cek lagi nama sholatnya!');
          }
        }
      } catch (err) {
        console.error(err);
        await Lyrra.reply('Error cuy, coba lagi ntar!');
      }
    }
    break

    case 'surah': {
      try {
        if (!text) {
          await Lyrra.reply('Ketik nomor surahnya! Contoh: *.surah 1* buat ambil ayat-ayat dari Al-Fatihah')
          return
        }

        const res = await fetch(`https://api.siputzx.my.id/api/s/surah?no=${text}`)
        const json = await res.json()
        const data = json.data

        if (data && data.length > 0) {
          let surahText = data.map((ayat, index) =>
            `Ayat ${index + 1}:\n` +
            `Arab: ${ayat.arab}\n` +
            `Latin: ${ayat.latin}\n` +
            `Terjemahan: ${ayat.indo}\n`
          ).join('\n\n')

          await Lyrra.reply(surahText)
        } else {
          await Lyrra.reply('Gak ketemu, cek lagi nomor surahnya!')
        }
      } catch (err) {
        console.error(err)
        await Lyrra.reply('Terjadi kesalahan: ' + err)
      }
    }
    break

    case 'kataislam': {
      async function AI(content) {
        try {
          const response = await axios.post('https://luminai.my.id/', {
            content,
            cName: "S-AI",
            cID: "S-AIbAQ0HcC"
          });

          return response.data
        } catch (error) {
          console.error(error)
          throw error
        }
      }

      let prompt = 'Berikan satu kata-kata atau quotes Islamic random yang sangat memotivasi, dan menginspirasi, jawab langsung ke intinya!'
      let hasil = await AI(prompt)
      Lyrra.reply(hasil.result)
    }
    break

    case 'pantunislam': {
      async function AI(content) {
        try {
          const response = await axios.post('https://luminai.my.id/', {
            content,
            cName: "S-AI",
            cID: "S-AIbAQ0HcC"
          });

          return response.data
        } catch (error) {
          console.error(error)
          throw error
        }
      }

      let prompt = 'Berikan satu kata-kata pantun Islamic random yang sangat memotivasi, dan menginspirasi, jawab langsung ke intinya!'
      let hasil = await AI(prompt)
      Lyrra.reply(hasil.result)
    }
    break

    case 'berdoa': {
      try {
        const res = await fetch('https://doa-doa-api-ahmadramadhan.fly.dev/api')
        const daftarDoa = await res.json()

        if (!text) {
          let listDoa = '*DAFTAR DOA*\n\n' + daftarDoa.map((item) => `- ${item.doa}`).join('\n')
          listDoa += '\n\nKetik *.doa [nama doa]* untuk melihat doa, contoh: *.doa doa sebelum tidur*'
          await Lyrra.reply(listDoa)
        } else {
          let hasil = daftarDoa.find((item) =>
            item.doa.toLowerCase().includes(text.toLowerCase())
          )

          if (hasil) {
            let tks = `*${hasil.doa.toUpperCase()}*\n\n` +
              `Ayat: ${hasil.ayat}\n` +
              `Latin: ${hasil.latin}\n` +
              `Artinya: ${hasil.artinya}`
            await Lyrra.reply(tks)
          } else {
            await Lyrra.reply('Doa yang lu cari ga ketemu cuy. Cek lagi nama doanya!')
          }
        }
      } catch (err) {
        console.error(err)
        await Lyrra.reply('Error cuy, coba lagi ntar!')
      }
    }
    break

    case 'gislam': {
      if (!text) return Lyrra.reply('Mau cari tentang apa?')

      async function islam(query) {
        try {
          const response = await fetch(`https://artikel-islam.netlify.app/.netlify/functions/api/ms?page=1&s=${encodeURIComponent(query)}`)
          const json = await response.json()
          if (json.success) {
            const articles = json.data.data
            let message = `Total artikel: ${articles.length}\n\n`
            articles.forEach((article, index) => {
              message += `${index + 1}. Judul: ${article.title}\nURL: ${article.url}\n\n`
            })
            return message
          } else {
            return 'Gagal mengambil data'
          }
        } catch (error) {
          return 'Terjadi kesalahan saat mengambil data'
        }
      }

      let hasil = await islam(text)
      Lyrra.reply(hasil)
    }
    break

    case 'ayatkursi': {
      try {
        const caption = `
*「 Ayat Kursi 」*

اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ

“Alloohu laa ilaaha illaa huwal hayyul qoyyuum, laa ta’khudzuhuu sinatuw walaa naum. Lahuu maa fissamaawaati wa maa fil ardli man dzal ladzii yasyfa’u ‘indahuu illaa biidznih, ya’lamu maa baina aidiihim wamaa kholfahum wa laa yuhiithuuna bisyai’im min ‘ilmihii illaa bimaa syaa’ wasi’a kursiyyuhus samaawaati wal ardlo walaa ya’uuduhuu hifdhuhumaa wahuwal ‘aliyyul ‘adhiim.”

*Artinya:*
Allah, tidak ada Tuhan (yang berhak disembah) melainkan Dia Yang Hidup kekal lagi terus menerus mengurus (makhluk-Nya); tidak mengantuk dan tidak tidur. Kepunyaan-Nya apa yang di langit dan di bumi. Tiada yang dapat memberi syafa'at di sisi Allah tanpa izin-Nya.
Allah mengetahui apa-apa yang di hadapan mereka dan di belakang mereka, dan mereka tidak mengetahui apa-apa dari ilmu Allah melainkan apa yang dikehendaki-Nya. Kursi Allah meliputi langit dan bumi. Dan Allah tidak merasa berat memelihara keduanya, dan Allah Maha Tinggi lagi Maha Besar." 
(QS. Al Baqarah: 255)`

        await Lyrra.reply(caption)

      } catch (err) {
        console.error(err)
        await Lyrra.reply('Gagal mengirim ayat kursi. Coba lagi nanti.')
      }
    }
    break

    case 'regristasi':
    case 'daftar': {
      if (db.data.users[sender].daftar) return Lyrra.reply('Kamu sudah terdaftar')
      const args = Lyrra.message.text.split(' ');

      if (args.length < 3) return Lyrra.reply('Format salah!\nGunakan: /daftar Nama Umur');

      const nama = args[1];
      const umur = parseInt(args[2]);
      if (isNaN(umur)) return Lyrra.reply('Umur harus berupa angka!');

      db.data.users[sender].nama = nama
      db.data.users[sender].umur = umur
      db.data.users[sender].daftar = true
      Lyrra.reply(`Berhasil mendaftar!\nNama: ${nama}\nUmur: ${umur}`);
    }
    break

    case 's':
    case 'stiker':
    case 'sticker': {
      const message = Lyrra.message;
      const reply = message.reply_to_message;

      if (!reply || (!reply.photo && !reply.video)) {
        return Lyrra.reply('Balas gambar atau video (≤10 detik) dengan perintah *sticker*');
      }

      try {
        if (reply.photo) {
          const file = reply.photo[reply.photo.length - 1].file_id;
          const fileLink = await Lyrra.telegram.getFileLink(file);
          await Lyrra.replyWithSticker({
            url: fileLink.href
          });
        } else if (reply.video) {
          const file = reply.video.file_id;
          if (reply.video.duration > 10) return Lyrra.reply('Videonya maksimal 10 detik ya!');
          const fileLink = await Lyrra.telegram.getFileLink(file);
          await Lyrra.replyWithSticker({
            url: fileLink.href
          });
        }
      } catch (err) {
        console.error(err);
        Lyrra.reply('Gagal membuat stiker!');
      }
    }
    break

    case 'ttf':
    case 'totalfeature':
    case 'totalfitur': {
      const jumlah = totalFitur();
      Lyrra.reply(`Total fitur aktif di bot ini: *${jumlah}*`, {
        parse_mode: 'Markdown'
      });
    }
    break

    case 'waifu':
    case 'neko':
    case 'shinobu':
    case 'megumin':
    case 'bully':
    case 'cuddle':
    case 'cry':
    case 'hug':
    case 'awoo':
    case 'kiss':
    case 'lick':
    case 'pat':
    case 'smug':
    case 'bonk':
    case 'yeet':
    case 'blush':
    case 'smile':
    case 'wave':
    case 'highfive':
    case 'handhold':
    case 'nom':
    case 'bite':
    case 'glomp':
    case 'slap':
    case 'kill':
    case 'happy':
    case 'wink':
    case 'poke':
    case 'dance':
    case 'cringe':
    case 'trap':
    case 'blowjob':
    case 'hentai':
    case 'boobs':
    case 'ass':
    case 'pussy':
    case 'thighs':
    case 'lesbian':
    case 'lewdneko':
    case 'cum': {
      const sender = Lyrra.from.id.toString();
      const isPremium = (() => {
        try {
          const premiumPath = path.join(__dirname, 'database', 'premium.json');
          if (!fs.existsSync(premiumPath)) return false;
          const premiumList = JSON.parse(fs.readFileSync(premiumPath, 'utf8'));
          const user = premiumList.find(u => u.id === sender);
          if (!user) return false;
          if (user.expired === 'Permanen') return true;
          return Date.now() < user.expired;
        } catch (e) {
          console.error('Error cek premium (waifu/nsfw):', e);
          return false; // Jika ada error saat baca file, anggap bukan premium
        }
      })();
      if (!isPremium) return Lyrra.reply('❌ Fitur ini hanya untuk user premium.');
      if (!Lyrra.chat?.type?.includes('private')) return Lyrra.reply('Fitur ini hanya bisa digunakan di chat pribadi!');

      try {
        let res = await fetch(`https://rule34.xxx/index.php?page=dapi&s=post&q=index&tags=${command}&json=1`)
        let data = await res.json()
        if (data && data[0]?.file_url) {
          return Lyrra.replyWithPhoto({
            url: data[0].file_url
          }, {
            caption: global.wm2
          })
        }
      } catch (err1) {
        try {
          let res2 = await fetch(`https://api.waifu.pics/nsfw/${command}`)
          let data2 = await res2.json()
          if (data2.url) {
            return Lyrra.replyWithPhoto({
              url: data2.url
            }, {
              caption: global.wm2
            })
          }
        } catch (err2) {
          try {
            let res3 = await fetch(`https://api.waifu.pics/sfw/${command}`)
            let data3 = await res3.json()
            if (data3.url) {
              return Lyrra.replyWithPhoto({
                url: data3.url
              }, {
                caption: global.wm2
              })
            }
          } catch (err3) {
            Lyrra.reply('Gagal mengambil gambar. Coba lagi nanti.')
          }
        }
      }
    }
    break;

    case 'paptt':
    case 'pap-tt':
    case 'bokeptt': {
      const sender = Lyrra.from.id.toString();
      const isPremium = (() => {
        try {
          const premiumPath = path.join(__dirname, 'database', 'premium.json');
          if (!fs.existsSync(premiumPath)) return false;
          const premiumList = JSON.parse(fs.readFileSync(premiumPath, 'utf8'));
          const user = premiumList.find(u => u.id === sender);
          if (!user) return false;
          if (user.expired === 'Permanen') return true;
          return Date.now() < user.expired;
        } catch (e) {
          console.error('Error cek premium (paptt):', e);
          return false; // Jika ada error saat baca file, anggap bukan premium
        }
      })();
      if (!isPremium) return Lyrra.reply('❌ Fitur ini hanya untuk user premium.');

      global.paptt = [
        "https://telegra.ph/file/5c62d66881100db561c9f.mp4",
        "https://telegra.ph/file/a5730f376956d82f9689c.jpg",
        "https://telegra.ph/file/8fb304f891b9827fa88a5.jpg",
        "https://telegra.ph/file/0c8d173a9cb44fe54f3d3.mp4",
        "https://telegra.ph/file/b58a5b8177521565c503b.mp4",
        "https://telegra.ph/file/34d9348cd0b420eca47e5.jpg",
        "https://telegra.ph/file/73c0fecd276c19560133e.jpg",
        "https://telegra.ph/file/af029472c3fcf859fd281.jpg",
        "https://telegra.ph/file/0e5be819fa70516f63766.jpg",
        "https://telegra.ph/file/29146a2c1a9836c01f5a3.jpg",
        "https://telegra.ph/file/85883c0024081ffb551b8.jpg",
        "https://telegra.ph/file/d8b79ac5e98796efd9d7d.jpg",
        "https://telegra.ph/file/267744a1a8c897b1636b9.jpg",
      ];
      let url = global.paptt[Math.floor(Math.random() * global.paptt.length)];

      if (url.endsWith('.mp4')) {
        await Lyrra.replyWithVideo({
          url
        }, {
          caption: 'Tch, sangean🤧'
        });
      } else {
        await Lyrra.replyWithPhoto({
          url
        }, {
          caption: 'Tch, sangean🤧'
        });
      }
    }
    break;

    // TikTok Downloader
case 'tiktok':
case 'tt':
case 'ttdl': {
  if (!text) return Lyrra.reply('Gunakan dengan format:\n\n/tt https://vt.tiktok.com/...')
  if (!text.includes('tiktok.com')) return Lyrra.reply('❌ Harus berupa link TikTok yang valid!')

  await lyreact(Lyrra)

  try {
    const res = await fetch(`https://api.vreyn.web.id/api/download/tiktok?url=${text}`)
    const data = await res.json()
    if (!data?.result?.data?.length) throw new Error('Data kosong / API error')

    const info = data.result
    const nowm = info.data.find(i => i.type === 'nowatermark')

    if (nowm?.url) {
      await Lyrra.replyWithVideo(
        { url: nowm.url },
        {
          caption: `🎬 *Video Info:*
- Region: ${info.region}
- Duration: ${info.duration}s

📊 *Statistik:*
- Views: ${info.stats.views}
- Likes: ${info.stats.likes}
- Comment: ${info.stats.comment}
- Share: ${info.stats.share}
- Download: ${info.stats.download}

📝 *Caption:*
${info.title}

© ${wm2}`,
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [
              [
                { text: '🎵 Download Audio', callback_data: `ttaudio_exec ${encodeURIComponent(text)}` }
              ],
              [
                { text: '✍️ Salin Perintah Manual', switch_inline_query_current_chat: `/ttaudio ${text}` }
              ]
            ]
          }
        }
      )
    } else {
      await Lyrra.reply('❌ Video tanpa watermark tidak ditemukan.')
    }
  } catch (err) {
    console.error('Error TikTok:', err)
    Lyrra.reply('❌ Gagal mengambil video TikTok.')
  }
}
break

case 'ttaudio':
case 'tiktokaudio':
case 'ttmp3':
case 'tiktokmp3': {
  if (!text) return Lyrra.reply(`📌 Contoh penggunaan:\n/${command} https://vt.tiktok.com/...`)
  if (!text.includes('tiktok.com')) return Lyrra.reply('❌ Harus berupa link TikTok yang valid!')

  await lyreact(Lyrra, '🎶TikTok Audio sedang diproses...') // efek emoji reaksi

  try {
    const fetch = (await import('node-fetch')).default
    const apiUrl = `https://api.nekolabs.my.id/downloader/tiktok?url=${encodeURIComponent(text)}`
    const res = await fetch(apiUrl)
    const data = await res.json()

    // 🔒 Validasi hasil API
    if (!data?.success || !data?.result?.musicUrl)
      throw new Error('Audio tidak ditemukan dalam hasil API.')

    // 🧩 Ambil data penting
    const result = data.result
    const title = (result.music_info?.title || result.title || 'Audio TikTok').replace(/[\\/:*?"<>|]/g, '')
    const artist = result.music_info?.author || result.author?.name || 'Tidak diketahui'
    const username = result.author?.username || ''
    const coverUrl = result.cover
    const audioUrl = result.musicUrl

    const caption = `🎧 *Audio TikTok*\n\n🎶 *Judul:* ${title}\n👤 *Artis:* ${artist} ${username ? `(${username})` : ''}\n\n© ${wm2}`

    // 🔹 Ambil cover TikTok sebagai thumbnail buffer
    const thumbBuffer = await fetch(coverUrl).then(r => r.arrayBuffer())

    // 🔊 Kirim audio dengan nama file sesuai judul + thumbnail + caption
    await Lyrra.replyWithAudio(
      {
        url: audioUrl,
        filename: `${title}.mp3`,
        thumbnail: { source: Buffer.from(thumbBuffer) }
      },
      {
        caption,
        parse_mode: 'Markdown'
      }
    )

  } catch (err) {
    console.error('❌ Error audio TikTok:', err)
    await Lyrra.reply('❌ Gagal mengambil audio dari TikTok. Pastikan link valid atau coba lagi nanti.')
  }

  break
}
    // Instagram Downloader
case 'igdl':
case 'instagram': {
  if (!text) return Lyrra.reply('📸 Contoh: /igdl https://www.instagram.com/reel/xxxx');
  if (!/instagram\.com\/(p|reel|stories|tv)\//i.test(text))
    return Lyrra.reply('❌ Harus berupa link postingan Instagram (reel, post, story, dll).');
  await lyreact(Lyrra, '📥Instagram sedang di proses...');
  try {
    const res = await fetch(`https://vapis.my.id/api/igdl?url=${encodeURIComponent(text)}`);
    const json = await res.json();

    if (!json?.data?.length) return Lyrra.reply('⚠️ Tidak ada media ditemukan di link tersebut.');

    const medias = json.data;
    const first = medias[0];
    const caption = `📷 *Instagram Downloader*\n🔗 ${text}\n\n© ${global.wm2}`;
    if (first.url.includes('.mp4')) {
      await Lyrra.telegram.sendVideo(
        Lyrra.chat.id,
        { url: first.url },
        { caption, parse_mode: 'Markdown' }
      );
    } else {
      await Lyrra.telegram.sendPhoto(
        Lyrra.chat.id,
        { url: first.url },
        { caption, parse_mode: 'Markdown' }
      );
    }
    if (medias.length > 1) {
      for (let i = 1; i < medias.length; i++) {
        const media = medias[i];
        const cap = `📷 *Instagram Media ${i + 1}/${medias.length}*\n\n© ${global.wm2}`;

        try {
          if (media.url.includes('.mp4')) {
            await Lyrra.telegram.sendVideo(Lyrra.chat.id, { url: media.url }, { caption: cap, parse_mode: 'Markdown' });
          } else {
            await Lyrra.telegram.sendPhoto(Lyrra.chat.id, { url: media.url }, { caption: cap, parse_mode: 'Markdown' });
          }
        } catch (err) {
          console.warn(`⚠️ Gagal kirim media ke-${i + 1}:`, err.message);
        }
      }
    }
  } catch (err) {
    console.error('Instagram error:', err.message);
    return Lyrra.reply('❌ Gagal mengunduh media Instagram. Coba kirim ulang linknya (pastikan publik).');
  }
}
break;

    // MediaFire Downloader
    case 'mediafiredown':
    case 'mfdown':
    case 'mf':
    case 'mediafire':
    case 'mfdl': {
      try {
        if (!text) return Lyrra.reply(`Contoh: /mfdown linknya`);
        if (!text.includes('mediafire.com')) return Lyrra.reply('Harus berupa link mediafire!');
        await lyreact(Lyrra)
        let api = await fetch(`https://api.vreden.web.id/api/mediafiredl?url=${text}`);
        let data = await api.json();
        data = data.result?.[0];

        if (!data || !data.link) {
          return Lyrra.reply('Gagal mendapatkan link download dari MediaFire.');
        }

        let fileNama = decodeURIComponent(data.nama || 'file.zip');
        let extension = fileNama.split('.').pop().toLowerCase();

        let mimetype = '';
        if (extension === 'mp4') mimetype = 'video/mp4';
        else if (extension === 'mp3') mimetype = 'audio/mp3';
        else mimetype = `application/${extension}`;

        await Lyrra.replyWithDocument({
          url: data.link
        }, {
          filename: fileNama,
          caption: `© ${wm2}`
        });
      } catch (err) {
        console.error('MediaFire error:', err);
        Lyrra.reply('Terjadi kesalahan: ' + err.message);
      }
    }
    break;

    // Facebook Downloader
    case 'fb':
    case 'fbdl':
    case 'facebook': {
      try {
        if (!text) return Lyrra.reply(`Contoh: /fbdl linknya`);
        if (!text.includes('facebook.com')) return Lyrra.reply('Harus berupa link facebook!');
        await lyreact(Lyrra)
        let jor = await fetch(`https://api.agatz.xyz/api/facebook?url=${encodeURIComponent(text)}`);
        jor = await jor.json();

        await Lyrra.replyWithVideo({
          url: jor.data.sd
        }, {
          caption: `© ${wm2}`
        });
      } catch (err) {
        console.error('Facebook error:', err);
        Lyrra.reply('Terjadi kesalahan: ' + err.message);
      }
    }
    break;

    // Threads Downloader
    case 'thdl':
    case 'threads': {
      try {
        if (!text) return Lyrra.reply(`Contoh: /thdl linknya`);
        if (!text.includes('threads.net')) return Lyrra.reply('Harus berupa link threads!');
        await lyreact(Lyrra)
        const response = await fetch(`https://api.vreden.web.id/api/threads?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.result && data.result.video) {
          await Lyrra.replyWithVideo({
            url: data.result.video
          }, {
            caption: `© ${wm2}`
          });
        } else {
          Lyrra.reply('Tidak dapat menemukan video dari link tersebut.');
        }
      } catch (err) {
        Lyrra.reply(`Terjadi kesalahan: ${err.message}`);
      }
    }
    break;

    // CapCut Downloader
    case 'ccdl':
    case 'capcut': {
      try {
        if (!text) return Lyrra.reply(`Contoh: /capcut linknya`);
        if (!text.includes('capcut.com') && !text.includes('capcut.net'))
          return Lyrra.reply('Harus berupa link capcut!');
        await lyreact(Lyrra)
        const response = await fetch(`https://api.vreden.web.id/api/capcut?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.result && data.result.video) {
          await Lyrra.replyWithVideo({
            url: data.result.video
          }, {
            caption: `© ${wm2}`
          });
        } else {
          Lyrra.reply('Tidak dapat menemukan video dari link tersebut.');
        }
      } catch (err) {
        console.error(err);
        Lyrra.reply('Terjadi kesalahan');
      }
    }
    break;

    // Spotify Downloader
    case 'spotify':
    case 'spotifydl': {
      if (!text) return Lyrra.reply(`Contoh: /spotify linknya`);
      if (!text.includes('spotify.com') && !text.includes('open.spotify'))
        return Lyrra.reply('Harus berupa link Spotify!');
      await lyreact(Lyrra)
      try {
        const response = await fetch(`https://api.vreden.web.id/api/spotify?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.result && data.result.audio) {
          await Lyrra.replyWithAudio({
            url: data.result.audio
          }, {
            title: data.result.title || 'Spotify Audio',
            performer: data.result.artist || 'Unknown Artist',
            caption: `© ${wm2}`
          });
        } else {
          Lyrra.reply('Tidak dapat menemukan audio dari link tersebut.');
        }
      } catch (err) {
        Lyrra.reply('Terjadi kesalahan: ' + err.message);
      }
    }
    break;

    // Google Drive Downloader
    case 'gddl':
    case 'gdrive': {
      try {
        if (!text) return Lyrra.reply(`Contoh: /gdrive linknya`);
        await lyreact(Lyrra)
        const response = await fetch(`https://api.siputzx.my.id/api/d/gdrive?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.data && data.data.download) {
          await Lyrra.replyWithDocument({
            url: data.data.download
          }, {
            filename: data.data.name || 'gdrive_download.zip',
            caption: `© ${wm2}`
          });
        } else {
          Lyrra.reply('Tidak dapat mengunduh file dari Google Drive.');
        }
      } catch (err) {
        console.error('Google Drive error:', err);
        Lyrra.reply('Terjadi kesalahan');
      }
    }
    break;

    // Terabox Downloader
    case 'terabox': {
      try {
        if (!text) return Lyrra.reply(`Contoh: /terabox linknya`);
        await lyreact(Lyrra)
        const response = await fetch(`https://api.vreden.web.id/api/terabox?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.result && data.result.download) {
          await Lyrra.replyWithDocument({
            url: data.result.download
          }, {
            filename: data.result.file_name || 'terabox_download.zip',
            caption: `© ${wm2}`
          });
        } else {
          Lyrra.reply('Tidak dapat mengunduh file dari Terabox.');
        }
      } catch (err) {
        Lyrra.reply('Terjadi kesalahan: ' + err.message);
      }
    }
    break;

    // XVideos Downloader
    case 'xvideodl':
    case 'xvidl': {
      if (!text) return Lyrra.reply(`Contoh: /xvideodl linknya`);
      await lyreact(Lyrra)
      try {
        let res = await fetch(`https://api.agatz.xyz/api/xvideodown?url=${encodeURIComponent(text)}`);
        let data = await res.json();

        if (data.data && data.data.url) {
          await Lyrra.replyWithVideo({
            url: data.data.url
          }, {
            caption: `*XVideos Download*\n\nJudul: ${data.data.title || '-'}\n© ${wm2}`
          });
        } else {
          Lyrra.reply('Tidak dapat mengunduh video dari XVideos.');
        }
      } catch (err) {
        console.error(err);
        Lyrra.reply('Terjadi kesalahan');
      }
    }
    break;

    // XNXX Downloader
    case 'xnxxdl':
    case 'xnxdl': {
      if (!text) return Lyrra.reply(`Contoh: /xnxxdl linknya`);
      await lyreact(Lyrra)
      try {
        let res = await fetch(`https://api.agatz.xyz/api/xnxxdown?url=${encodeURIComponent(text)}`);
        let data = await res.json();

        if (data.data && data.data.files && data.data.files.low) {
          await Lyrra.replyWithVideo({
            url: data.data.files.low
          }, {
            caption: `*XNXX Download*\n\nJudul: ${data.data.title || '-'}\nDurasi: ${data.data.duration || '-'}\n© ${wm2}`
          });
        } else {
          Lyrra.reply('Tidak dapat mengunduh video dari XNXX.');
        }
      } catch (err) {
        console.error(err);
        Lyrra.reply('Terjadi kesalahan');
      }
    }
    break;

    // Pinterest Downloader
    case 'pindl': {
      if (!text) return Lyrra.reply(`Contoh: /pinterest linknya`);
      await lyreact(Lyrra)
      try {
        const response = await fetch(`https://api.vreden.web.id/api/pinterest?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.result && data.result.image) {
          await Lyrra.replyWithPhoto({
            url: data.result.image
          }, {
            caption: `*Pinterest Download*\n\nJudul: ${data.result.title || '-'}\n© ${wm2}`
          });
        } else {
          Lyrra.reply('Tidak dapat mengunduh gambar dari Pinterest.');
        }
      } catch (err) {
        Lyrra.reply('Terjadi kesalahan: ' + err.message);
      }
    }
    break;

    // Pastebin Getter
    case 'pastebin': {
      if (!text) return Lyrra.reply(`Contoh: /pastebin linknya`);
      await lyreact(Lyrra)
      try {
        const response = await fetch(`https://vapis.my.id/api/pastebin?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.data) {
          // Send as document if content is long
          if (data.data.length > 1000) {
            await Lyrra.replyWithDocument({
              source: Buffer.from(data.data),
              filename: 'pastebin_content.txt'
            }, {
              caption: `© ${wm2}`
            });
          } else {
            await Lyrra.reply(`Pastebin Content:\n\n${data.data}`);
          }
        } else {
          Lyrra.reply('Tidak dapat mengambil konten dari Pastebin.');
        }
      } catch (err) {
        Lyrra.reply('Terjadi kesalahan: ' + err.message);
      }
    }
    break;

    // Lyrics Getter
    case 'lirikget':
    case 'getlirik':
    case 'lirik': {
      if (!text) return Lyrra.reply(`Contoh: /lirik judul_lagu`);
      await lyreact(Lyrra)
      try {
        const response = await fetch(`https://api.vreden.web.id/api/lirik?query=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.result) {
          let lyricsText = `*Lirik Lagu:* ${data.result.title || '-'}\n\n`;
          lyricsText += data.result.lyrics || 'Lirik tidak ditemukan';

          await Lyrra.reply(lyricsText);
        } else {
          Lyrra.reply('Lirik tidak ditemukan.');
        }
      } catch (err) {
        Lyrra.reply('Terjadi kesalahan: ' + err.message);
      }
    }
    break;

    case 'akiyama':
    case 'ana':
    case 'art':
    case 'asuna':
    case 'ayuzawa':
    case 'boruto':
    case 'bts':
    case 'cartoon':
    case 'chiho':
    case 'chitoge':
    case 'cosplay':
    case 'cosplayloli':
    case 'cosplaysagiri':
    case 'cyber':
    case 'deidara':
    case 'doraemon':
    case 'elaina':
    case 'emilia':
    case 'erza':
    case 'exo':
    case 'gamewallpaper':
    case 'gremory':
    case 'hacker':
    case 'hestia':
    case 'hinata':
    case 'husbu':
    case 'inori':
    case 'islamic':
    case 'isuzu':
    case 'itachi':
    case 'itori':
    case 'jennie':
    case 'jiso':
    case 'justina':
    case 'kaga':
    case 'kagura':
    case 'kakasih':
    case 'kaori':
    case 'keneki':
    case 'kotori':
    case 'kurumi':
    case 'lisa':
    case 'madara':
    case 'megumin':
    case 'mikasa':
    case 'mikey':
    case 'miku':
    case 'minato':
    case 'mountain':
    case 'naruto':
    case 'neko2':
    case 'nekonime':
    case 'nezuko':
    case 'onepiece':
    case 'pentol':
    case 'pokemon':
    case 'programming':
    case 'randomnime':
    case 'randomnime2':
    case 'rize':
    case 'rose':
    case 'sagiri':
    case 'sakura':
    case 'sasuke':
    case 'satanic':
    case 'shina':
    case 'shinka':
    case 'shinomiya':
    case 'shizuka':
    case 'shota':
    case 'shortquote':
    case 'space':
    case 'technology':
    case 'tejina':
    case 'toukachan':
    case 'tsunade':
    case 'yotsuba':
    case 'yuki':
    case 'yulibocil':
    case 'yumeko': {
      const keyword = command.replace('/', '')
      const mapKategori = {
        akiyama: 'akiyama',
        ana: 'ana',
        art: 'art',
        asuna: 'asuna',
        ayuzawa: 'ayuzawa',
        boruto: 'boruto',
        bts: 'bts',
        cartoon: 'kartun',
        chiho: 'chiho',
        chitoge: 'chitoge',
        cosplay: 'cosplay',
        cosplayloli: 'cosplayloli',
        cosplaysagiri: 'cosplaysagiri',
        cyber: 'cyber',
        deidara: 'deidara',
        doraemon: 'doraemon',
        elaina: 'elaina',
        emilia: 'emilia',
        erza: 'erza',
        exo: 'exo',
        gamewallpaper: 'gamewallpaper',
        gremory: 'gremory',
        hacker: 'hekel',
        hestia: 'hestia',
        hinata: 'hinata',
        husbu: 'husbu',
        inori: 'inori',
        islamic: 'islamic',
        isuzu: 'isuzu',
        itachi: 'itachi',
        itori: 'itori',
        jennie: 'jeni',
        jiso: 'jiso',
        justina: 'justina',
        kaga: 'kaga',
        kagura: 'kagura',
        kakasih: 'kakasih',
        kaori: 'kaori',
        keneki: 'keneki',
        kotori: 'kotori',
        kurumi: 'kurumi',
        lisa: 'lisa',
        madara: 'madara',
        megumin: 'megumin',
        mikasa: 'mikasa',
        mikey: 'mikey',
        miku: 'miku',
        minato: 'minato',
        mountain: 'mountain',
        naruto: 'naruto',
        neko2: 'neko2',
        nekonime: 'nekonime',
        nezuko: 'nezuko',
        onepiece: 'onepiece',
        pentol: 'pentol',
        pokemon: 'pokemon',
        programming: 'programming',
        randomnime: 'randomnime',
        randomnime2: 'randomnime2',
        rize: 'rize',
        rose: 'rose',
        sagiri: 'sagiri',
        sakura: 'sakura',
        sasuke: 'sasuke',
        satanic: 'satanic',
        shina: 'shina',
        shinka: 'shinka',
        shinomiya: 'shinomiya',
        shizuka: 'shizuka',
        shota: 'shota',
        shortquote: 'katakata',
        space: 'tatasurya',
        technology: 'technology',
        tejina: 'tejina',
        toukachan: 'toukachan',
        tsunade: 'tsunade',
        yotsuba: 'yotsuba',
        yuki: 'yuki',
        yulibocil: 'yulibocil',
        yumeko: 'yumeko',
      }

      const namaKategori = mapKategori[keyword]
      if (!namaKategori) return Lyrra.reply('Kategori tidak ditemukan.')
      await lyreact(Lyrra)

      try {
        const url = `https://raw.githubusercontent.com/Leoo7z/Image-Source/main/image/${namaKategori}.json`
        const res = await fetch(url)
        const data = await res.json()

        if (!Array.isArray(data) || data.length === 0) {
          return Lyrra.reply('Gambar tidak ditemukan.')
        }

        const randomImage = data[Math.floor(Math.random() * data.length)]
        await Lyrra.replyWithPhoto({
          url: randomImage
        }, {
          caption: `Hasil untuk ${command}`
        })
      } catch (e) {
        console.error(e)
        Lyrra.reply('Terjadi kesalahan saat mengambil gambar.')
      }
    }
    break

    // Rpg Area

    case 'joinrpg': {
      if (db.data.users[sender].rpg) return Lyrra.reply(`Kamu sudah bergabung sebelumnya.`)
      db.data.rpg[sender] = {
        rank: false,
        bank: 0,
        kapal: false,
        darahkapal: 100,
        pickaxe: false,
        darahpickaxe: 100,
        kapak: false,
        darahkapak: 100,
        bzirah: false,
        darahbzirah: 100,
        pedang: false,
        darahpedang: 100,
        darahuser: 100,
        stamina: 100,
        potion: 3,
        rumah: 0,
        common: 0,
        uncommon: 0,
        mythic: 0,
        legendary: 0,
        besi: 4,
        kayu: 2,
        emas: 0,
        perak: 0,
        emerald: 0,
        diamond: 0,
        batubara: 0,
        bulu: 0,
        kain: 0,
        botol: 0,
        kardus: 0,
        kaleng: 0,
        gelas: 0,
        plastik: 0,
        wilayah: "indonesia",
        wilayahrumah: "indonesia",
        skillselect: "",
        musuh: 0,
        dailyclaim: 0,
        weeklyclaim: 0,
        monthlyclaim: 0,
        yearlyclaim: 0,
        burutime: 0,
        lastdagang: 0,
        lastbansos: 0,
        lastkerja: 0,
        lastrampok: 0,
        sampahtime: 0,
        lastrocket: 0,
        lastmakan: 0,
        lasttidur: 0,
        lastewe: 0,
        lastopenbo: 0,
        lastdailymisi: 0,
        lastngaji: 0,
        domba: 0,
        sapi: 0,
        ayam: 0,
        banteng: 0,
        gajah: 0,
        harimau: 0,
        kambing: 0,
        panda: 0,
        buaya: 0,
        kerbau: 0,
        monyet: 0,
        babihutan: 0,
        babi: 0,
        ikan: 0,
        paus: 0,
        kepiting: 0,
        gurita: 0,
        cumi: 0,
        buntal: 0,
        dory: 0,
        lumba: 0,
        lobster: 0,
        hiu: 0,
        udang: 0,
        orca: 0,
        makanan: 0
      }
      db.data.users[sender].rpg = true
      Lyrra.reply(`Berhasil join rpg sekarang anda dapat melihat inventory dengan command ${prefix}inventory`)
    }
    break

    case 'exitrpg':
    case 'closerpg': {
      if (!db.data.users[sender].rpg) return Lyrra.reply(`Kamu tidak memiliki database rpg.`)
      delete db.data.rpg[sender]
      db.data.users[sender].rpg = false
      Lyrra.reply(`Berhasil exit rpg, semua database telah dihapus.`)
    }
    break

    case 'inv':
    case 'inventory': {
      if (!db.data.users[sender].rpg) return Lyrra.reply(`*Join RPG Terlebih Dahulu*\n\nketik .joinrpg`)
      let teks = `*⚔️ RPG - PROFILE ⚔️*

User Profile 🤺
  • Name: ${db.data.users[sender].nama}
  • Money: ${db.data.users[sender].saldo}
  • User Healthy: ${db.data.rpg[sender].darahuser}/100%
  • Skill: ${db.data.rpg[sender].skillselect ? `(${db.data.rpg[sender].skillselect})` : 'Nothing'}
  • Makanan: ${db.data.rpg[sender].makanan}
  • Potion: ${db.data.rpg[sender].potion}
  • Keberadaan: ${db.data.rpg[sender].wilayah}
  • Kapal: ${db.data.rpg[sender].kapal ? `(${db.data.rpg[sender].darahkapal}% HP)` : 'Nothing'}
  • Rumah: ${db.data.rpg[sender].rumah} Unit
  • Kapak: ${db.data.rpg[sender].kapak ? `(${db.data.rpg[sender].darahkapak}% HP)` : 'Nothing'}
  • Pickaxe: ${db.data.rpg[sender].pickaxe ? `(${db.data.rpg[sender].darahpickaxe}% HP)` : 'Nothing'}
  • Baju Zirah: ${db.data.rpg[sender].bzirah ? `(${db.data.rpg[sender].darahbzirah}% HP)` : 'Nothing'}
  • Pedang: ${db.data.rpg[sender].pedang ? `(${db.data.rpg[sender].darahpedang}% HP)` : 'Nothing'}
  • Kain: ${db.data.rpg[sender].kain} Lembar

Sumber Daya 🧰
  • Kayu: ${db.data.rpg[sender].kayu}
  • Besi: ${db.data.rpg[sender].besi}
  • Emas: ${db.data.rpg[sender].emas}
  • Perak: ${db.data.rpg[sender].perak}
  • Batubara: ${db.data.rpg[sender].batubara}
  • Emerald: ${db.data.rpg[sender].emerald}
  • Diamond: ${db.data.rpg[sender].diamond}
  • Common: ${db.data.rpg[sender].common}
  • Uncommon: ${db.data.rpg[sender].uncommon}
  • Mythic: ${db.data.rpg[sender].mythic}
  • Legendary: ${db.data.rpg[sender].legendary}

Hewan & Ternak🐄
  • Ayam: ${db.data.rpg[sender].ayam} Ekor 
  • Sapi: ${db.data.rpg[sender].sapi} Ekor
  • Domba: ${db.data.rpg[sender].domba} Ekor
  • Ikan: ${db.data.rpg[sender].ikan} Ekor
  • Banteng: ${db.data.rpg[sender].banteng} Ekor 
  • Gajah: ${db.data.rpg[sender].gajah} Ekor
  • Harimau: ${db.data.rpg[sender].harimau} Ekor
  • Kambing: ${db.data.rpg[sender].kambing} Ekor
  • Panda: ${db.data.rpg[sender].panda} Ekor
  • Buaya: ${db.data.rpg[sender].buaya} Ekor
  • Kerbau: ${db.data.rpg[sender].kerbau} Ekor
  • Monyet: ${db.data.rpg[sender].monyet} Ekor
  • Babihutan: ${db.data.rpg[sender].babihutan} Ekor
  • Babi: ${db.data.rpg[sender].babi} Ekor

Hewan Laut🌊
  • Ikan: ${db.data.rpg[sender].ikan} Ekor
  • Paus: ${db.data.rpg[sender].paus} Ekor
  • Gurita: ${db.data.rpg[sender].gurita} Ekor
  • Kepiting: ${db.data.rpg[sender].kepiting} Ekor
  • Cumi: ${db.data.rpg[sender].cumi} Ekor
  • Buntal: ${db.data.rpg[sender].buntal} Ekor
  • Dory: ${db.data.rpg[sender].dory} Ekor
  • Lumba: ${db.data.rpg[sender].lumba} Ekor
  • Lobster: ${db.data.rpg[sender].lobster} Ekor
  • Hiu: ${db.data.rpg[sender].hiu} Ekor
  • Udang: ${db.data.rpg[sender].udang} Ekor
  • Orca: ${db.data.rpg[sender].orca} Ekor
  
Items Lainnya🎗️
  • Botol: ${db.data.rpg[sender].botol}
  • Kardus: ${db.data.rpg[sender].kardus}
  • Kaleng: ${db.data.rpg[sender].kaleng}
  • Gelas: ${db.data.rpg[sender].gelas}
  • Plastik: ${db.data.rpg[sender].plastik}
  • Bulu: ${db.data.rpg[sender].bulu}`
      await Lyrra.reply(teks)
    }
    break

   // ================ New Script Update ============= //

case 'serverinfo':
case 'system':
case 'ping':
case 'ping-x':
case 'srvinfo': {
  const os = require('os');
  const nou = require('node-os-utils');
  const fs = require('fs');

  // Helper: Format bytes ke MB/GB
  const formatBytes = (bytes) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  // Helper: Format uptime (detik → hari jam menit)
  const runtime = (seconds) => {
    const d = Math.floor(seconds / 86400);
    const h = Math.floor((seconds % 86400) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    let result = '';
    if (d > 0) result += `${d} hari `;
    if (h > 0) result += `${h} jam `;
    if (m > 0) result += `${m} menit `;
    if (s > 0) result += `${s} detik`;
    return result.trim() || '0 detik';
  };

  try {
    const osType = await nou.os.type();
    const release = os.release();
    const arch = os.arch();
    const nodeVersion = process.version;
    const ip = await nou.os.ip();

    const cpus = os.cpus();
    const cpuModel = cpus[0]?.model || 'Unknown';
    const coreCount = cpus.length;
    const totalIdle = cpus.reduce((acc, cpu) => acc + cpu.times.idle, 0);
    const totalTick = cpus.reduce((acc, cpu) => acc + Object.values(cpu.times).reduce((a, b) => a + b, 0), 0);
    const cpuUsage = totalTick === 0 ? '0%' : (((totalTick - totalIdle) / totalTick) * 100).toFixed(2) + '%';
    const loadAverage = os.loadavg().map(v => v.toFixed(2)).join(', ');

    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMem = totalMem - freeMem;

    const storageInfo = await nou.drive.info();

    // Pengukuran latensi mini
    const start = process.hrtime.bigint();
    await new Promise(r => setTimeout(r, 1));
    const end = process.hrtime.bigint();
    const latensi = Number(end - start) / 1_000_000 / 1000; // detik

    const teks = `*⚙️ SERVER INFO*
• OS: ${osType} (${release})
• Arsitektur: ${arch}
• Node.js: ${nodeVersion}
• IP: ${ip}
• Runtime: ${runtime(os.uptime())}

*🖥️ CPU*
• Model: ${cpuModel}
• Core: ${coreCount}
• Beban: ${cpuUsage}
• Load Average: ${loadAverage}

*🧠 RAM*
• Total: ${formatBytes(totalMem)}
• Digunakan: ${formatBytes(usedMem)}
• Tersisa: ${formatBytes(freeMem)}

*💾 STORAGE*
• Total: ${storageInfo.totalGb} GB
• Terpakai: ${storageInfo.usedGb} GB (${storageInfo.usedPercentage}%)
• Tersedia: ${storageInfo.freeGb} GB (${storageInfo.freePercentage}%)

*📡 PING*
• Latensi: ${latensi.toFixed(4)} detik`;

    await Lyrra.reply(teks, { parse_mode: 'Markdown' });

  } catch (err) {
    console.error('❌ Error di serverinfo:', err);
    await Lyrra.reply('Terjadi kesalahan saat mengambil info server.');
  }
}
break;

case '1gb':
case '2gb':
case '3gb':
case '4gb':
case '5gb':
case '6gb':
case '7gb':
case '8gb':
case '9gb':
case '10gb':
case 'unli':
  return createPanel(Lyrra, command);

case 'addres':
case 'address':
case 'addreseller': {
  try {
    const fs = require('fs');
    const path = './x-system/telegram/database/reseller.json';
    const senderId = Lyrra.from.id.toString();
    const args = Lyrra.message.text.split(' ').slice(1);
    const targetId = args[0];

    if (String(senderId) !== String(global.idAdmins)) {
      return Lyrra.reply('❌ Fitur ini hanya untuk Owner bot.');
    }
    if (!targetId) {
      return Lyrra.reply('Gunakan format:\n/addreseller <id_telegram>');
    }
    if (!fs.existsSync(path)) {
      fs.writeFileSync(path, JSON.stringify([], null, 2));
    }
    let db = JSON.parse(fs.readFileSync(path));
    if (!Array.isArray(db)) db = [];
    if (db.includes(targetId)) {
      return Lyrra.reply('⚠️ User ini sudah menjadi reseller.');
    }
    db.push(targetId);
    fs.writeFileSync(path, JSON.stringify(db, null, 2));

    await Lyrra.reply(`✅ User dengan ID *${targetId}* berhasil ditambahkan sebagai reseller.`);
  } catch (err) {
    console.error('❌ Error addreseller:', err);
    await Lyrra.reply('❌ Terjadi kesalahan saat menambahkan reseller.');
  }
}
break;

case 'addprem':
case 'adduserprem':
case 'addpremium': {
  const sender = Lyrra.from.id.toString();
  if (String(sender) !== String(global.idAdmins)) return Lyrra.reply('❌ Hanya owner yang bisa menggunakan perintah ini.');

  const args = Lyrra.message.text.split(' ').slice(1);
  if (args.length < 2) return Lyrra.reply('📌 Contoh: /addprem @username 30d\natau /addprem 123456789 7d');

  let targetId;
  if (Lyrra.message.entities?.[1]?.type === 'text_mention') {
    targetId = Lyrra.message.entities[1].user.id.toString();
  } else if (/^\d+$/.test(args[0])) {
    targetId = args[0];
  } else {
    return Lyrra.reply('Tag user atau masukkan ID Telegram!');
  }

  const duration = parseDuration(args[1]);
  if (!duration) return Lyrra.reply('Format durasi salah! Gunakan: 1d, 12h, 30m, atau permanen');

  const premiumList = JSON.parse(fs.readFileSync(PREMIUM_FILE, 'utf8'));
  const exists = premiumList.find(u => u.id === targetId);
  if (exists) return Lyrra.reply('⚠️ User ini sudah premium!');

  premiumList.push({ id: targetId, expired: duration });
  fs.writeFileSync(PREMIUM_FILE, JSON.stringify(premiumList, null, 2));

  // Kirim notifikasi ke user
  try {
    const msg = duration === 'Permanen'
      ? `✅ Kamu telah diaktifkan sebagai *user premium PERMANEN*!`
      : `✅ Kamu telah diaktifkan sebagai *user premium* selama ${args[1]}!`;

    await Lyrra.telegram.sendMessage(targetId, msg, { parse_mode: 'Markdown' });
  } catch (e) {
    console.warn('Gagal kirim notifikasi ke user:', e.message);
  }

  Lyrra.reply(`✅ Premium berhasil ditambahkan untuk ID: ${targetId}`);
}
break;

case 'delprem':
case 'delpremium': {
  const sender = Lyrra.from.id.toString();
  if (String(sender) !== String(global.idAdmins)) return Lyrra.reply('❌ Hanya owner yang bisa menggunakan perintah ini.');

  const args = Lyrra.message.text.split(' ').slice(1);
  let targetId;

  if (Lyrra.message.entities?.[1]?.type === 'text_mention') {
    targetId = Lyrra.message.entities[1].user.id.toString();
  } else if (args[0] && /^\d+$/.test(args[0])) {
    targetId = args[0];
  } else {
    return Lyrra.reply('Tag user atau masukkan ID Telegram!');
  }

  let premiumList = JSON.parse(fs.readFileSync(PREMIUM_FILE, 'utf8'));
  const before = premiumList.length;
  premiumList = premiumList.filter(u => u.id !== targetId);

  if (premiumList.length === before) {
    return Lyrra.reply('User tidak ditemukan di daftar premium.');
  }

  fs.writeFileSync(PREMIUM_FILE, JSON.stringify(premiumList, null, 2));
  Lyrra.reply(`✅ Premium berhasil dihapus untuk ID: ${targetId}`);
}
break;

case 'listprem':
case 'listpremium':
case 'listpremiums': {
  const sender = Lyrra.from.id.toString();
  if (String(sender) !== String(global.idAdmins)) return Lyrra.reply('❌ Hanya owner yang bisa menggunakan perintah ini.');

  const premiumList = JSON.parse(fs.readFileSync(PREMIUM_FILE, 'utf8'));
  if (premiumList.length === 0) return Lyrra.reply('Belum ada user premium.');

  let msg = '📋 *Daftar User Premium:*\n\n';
  for (const user of premiumList) {
    const mention = `[${user.id}](tg://user?id=${user.id})`;
    if (user.expired === 'Permanen') {
      msg += `👤 ${mention}\n   ⏳ Permanen\n\n`;
    } else {
      const remaining = formatTime(user.expired - Date.now());
      msg += `👤 ${mention}\n   ⏳ ${remaining}\n\n`;
    }
  }

  await Lyrra.reply(msg, { parse_mode: 'Markdown' });
}
break;

case 'cekprem':
case 'cekpremium':
case 'checkprem': {
  const sender = Lyrra.from.id.toString();
  const premiumList = JSON.parse(fs.readFileSync(PREMIUM_FILE, 'utf8'));
  const user = premiumList.find(u => u.id === sender);

  if (!user) return Lyrra.reply('Kamu bukan user premium.');

  if (user.expired === 'Permanen') {
    return Lyrra.reply('✅ Kamu adalah user premium *PERMANEN*!');
  }

  const remainingMs = user.expired - Date.now();
  if (remainingMs <= 0) {
    // Hapus expired user
    const newList = premiumList.filter(u => u.id !== sender);
    fs.writeFileSync(PREMIUM_FILE, JSON.stringify(newList, null, 2));
    return Lyrra.reply('Masa premium kamu sudah habis.');
  }

  const remaining = formatTime(remainingMs);
  Lyrra.reply(`✅ Kamu adalah user premium!\n⏳ Masa berlaku: ${remaining}`);
}
break;

case 'ai':
case 'chatgpt':
case 'vreynai': {
  try {
    if (!text) return Lyrra.reply("💬 Contoh penggunaan: /ai halo apa kabar?");

    const pesan = text.toLowerCase().trim();

    const closePattern = /\b(?:coba|mohon|tolong|ayo|yuk|dong|ya|please|silakan|bisa|minta|mohonlah)?\s*(tutup|lock|kunci|nonaktifkan|matikan|diamkan|stop|disable|mode\s+diam|mute)\s*(grup|gc|gb|room|chat|obrolan|forum)\s*(ini|nya|dong|ya|sekarang|segera|plis|bang)?\b/i;
    const openPattern = /\b(?:coba|mohon|tolong|ayo|yuk|dong|ya|please|silakan|bisa|minta|mohonlah)?\s*(buka|unlock|aktifkan|hidupkan|nyalakan|izinkan|mode\s+bebas|unmute)\s*(grup|gc|gb|room|chat|obrolan|forum)\s*(ini|nya|dong|ya|sekarang|segera|plis|bang)?\b/i;

    if (closePattern.test(pesan)) {
      if (ctx.chat.type === "supergroup" || ctx.chat.type === "group") {
        if (isOwner || isAdmin) {
          await Lyrra.telegram.setChatPermissions(ctx.chat.id, { can_send_messages: false });
          return await Lyrra.reply("🔒 Grup telah dikunci oleh AI atas perintah kamu!");
        }
      }
    }

    if (openPattern.test(pesan)) {
      if (ctx.chat.type === "supergroup" || ctx.chat.type === "group") {
        if (isOwner || isAdmin) {
          await Lyrra.telegram.setChatPermissions(ctx.chat.id, {
            can_send_messages: true,
            can_send_media_messages: true,
            can_send_other_messages: true,
          });
          return await Lyrra.reply("🔓 Grup telah dibuka oleh AI!");
        }
      }
    }

    await Lyrra.reply("🤖 Sedang berpikir...");
    
    async function AI(content) {
      try {
        const response = await axios.post("https://ai.siputzx.my.id/", {
          content,
          cName: "S-AI",
          cID: "S-AIbAQ0HcC",
        });
        return response.data;
      } catch (error) {
        console.error("AI API error:", error);
        throw new Error("Gagal menghubungi server AI.");
      }
    }

    const sai = await AI(pesan);
    const hasil = sai?.result?.trim();

    if (!hasil) {
      await Lyrra.reply("⚠️ AI tidak memberikan respon. Coba lagi nanti.");
    } else {
      await Lyrra.reply(hasil);
    }

  } catch (err) {
    console.error("AI error:", err);
    await Lyrra.reply("❌ Terjadi kesalahan saat memproses permintaan kamu.");
  }
}
break;


// =============== INSTAGRAM DOWNLOADER ===============
case 'ig':
case 'igdl':
case 'instagram': {
  const url = text;
  if (!url) return Lyrra.reply('📌 Contoh: /ig https://www.instagram.com/reel/xxxxx/');
  if (!/^https?:\/\/(www\.)?instagram\.com/.test(url)) return Lyrra.reply('❌ Link harus dari Instagram.');

  await lyreact(Lyrra, '📥Instagram Sedang di Prosses...');

  try {
    const res = await fetch(`https://api.vreyn.web.id/api/download/instagram?url=${encodeURIComponent(url)}`);
    const data = await res.json();

    if (!data?.status || !data?.result?.data?.[0]?.url) {
      return Lyrra.reply('⚠️ Gagal mengambil media. Pastikan link publik & valid.');
    }

    const media = data.result.data[0];
    const isVideo = media.type === 'video';
    const profile = data.result.profile || {};
    const caption = (data.result.caption?.text || '-').slice(0, 400) + (data.result.caption?.text?.length > 400 ? '...' : '');
    const stats = data.result.statistics || {};

    const message = `📥 *Instagram Downloader*

👤 *${profile.full_name || 'Unknown'}* (@${profile.username || '-'})
${profile.is_verified ? '✅ Verified' : ''}

💬 *Caption:* ${caption}

❤️ *Likes:* ${stats.like_count || 0}
💬 *Comments:* ${stats.comment_count || 0}
▶️ *Views:* ${stats.play_count || 0}

© ${global.wm2}`;

    if (isVideo) {
      await Lyrra.replyWithVideo({ url: media.url }, { caption: message, parse_mode: 'Markdown' });
    } else {
      await Lyrra.replyWithPhoto({ url: media.url }, { caption: message, parse_mode: 'Markdown' });
    }
  } catch (err) {
    console.error('Instagram error:', err.message);
    Lyrra.reply('❌ Gagal mengunduh media Instagram.');
  }
}
break;



            
// =============== YOUTUBE MP3 (Audio) ===============
case 'play':
case 'ytplay':
case 'song':
case 'music': {
  if (!text) {
    return Lyrra.reply(`🎧 *Contoh Penggunaan:*\n/play lofi beats\n/play multo - cup of joe`);
  }

  await lyreact(Lyrra, '🔍 Mencari lagu...');

  try {
    const yts = require('yt-search');
    const searchResult = await yts(text);
    const video = searchResult.all[0]; 

    if (!video) return Lyrra.reply('❌ Tidak ditemukan hasil untuk: ' + text);

    const { url, title, author, duration, views, ago, thumbnail } = video;

    const inlineKeyboard = [
      [
        { text: '🎵 Audio MP3', callback_data: `play_audio|${url}` },
        { text: '🎥 Video MP4', callback_data: `play_video|${url}` }
      ]
    ];

    const caption = `🎧 *YouTube Music Player*\n\n🎵 *Judul:* ${title}\n👤 *Channel:* ${author.name}\n⏱️ *Durasi:* ${duration}\n👁️ *Views:* ${views}\n📅 *Upload:* ${ago}\n🔗 *Link:* [YouTube](${url})\n\nPilih format di bawah:`;

    await Lyrra.replyWithPhoto({ url: thumbnail }, {
      caption,
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: inlineKeyboard }
    });

  } catch (err) {
    console.error('Play error:', err);
    Lyrra.reply('❌ Gagal mencari lagu: ' + (err.message || err));
  }
}
break;

case 'ytmp3': {
  const link = args[0];
  if (!link) return Lyrra.reply('🎧 Contoh:\n/ytmp3 https://youtu.be/xxxx');

  await lyreact(Lyrra, '🎶 Sedang memproses audio...');

  try {
    const api = `https://api.nekolabs.web.id/downloader/youtube/v1?url=${encodeURIComponent(link)}&format=mp3`;
    const res = await fetch(api);
    const data = await res.json();

    if (!data.success || !data.result?.downloadUrl) {
      return Lyrra.reply('❌ Gagal mengambil audio dari API.');
    }

    const { title, duration, format, quality, cover, downloadUrl } = data.result;

    const head = await fetch(downloadUrl, { method: 'HEAD' });
    const size = parseInt(head.headers.get('content-length') || '0');

    if (size > 50 * 1024 * 1024) {
      // Jika lebih dari 50 MB, kirim link saja
      return Lyrra.replyWithPhoto(
        { url: cover },
        {
          caption: `🎵 *${title}*\n🕒 Durasi: ${duration}\n🎧 Format: ${format.toUpperCase()} ${quality}kbps\n\n⚠️ File terlalu besar.\n🔗 [Klik untuk Unduh Audio](${downloadUrl})\n\n© ${global.wm2}`,
          parse_mode: 'Markdown',
        }
      );
    }
    await Lyrra.replyWithAudio(
      { url: downloadUrl },
      {
        caption: `🎵 *${title}*\n🕒 Durasi: ${duration}\n🎧 Format: ${format.toUpperCase()} ${quality}kbps\n\n© ${global.wm2}`,
        parse_mode: 'Markdown',
        thumb: { url: cover },
      }
    );
  } catch (err) {
    console.error('YouTube MP3 error:', err.message);
    Lyrra.reply('❌ Gagal memproses audio YouTube.');
  }
}
break;

 

case 'pin':
case 'pinterest': {
  const query = text;
  if (!query) return Lyrra.reply('📸 Contoh: /pinterest Ado 4K Wallpaper');

  await lyreact(Lyrra, '🔍 Pinterest photo sedang diproses...');

  try {
    const res = await fetch(`https://api.siputzx.my.id/api/s/pinterest?query=${encodeURIComponent(query)}&type=image`);
    const data = await res.json();

    if (!data?.status || !data?.data?.length) {
      return Lyrra.reply('❌ Tidak ada gambar ditemukan untuk: ' + query);
    }

    const images = data.data.slice(0, 9); // maks 9 foto
    const sender = Lyrra.from.id.toString();
    const isGroup = Lyrra.chat.type !== 'private';
    // === Kirim 1 gambar ke grup (jika di perintah di grup)
    if (isGroup) {
      await Lyrra.replyWithPhoto(
        { url: images[0].image_url },
        {
          caption: `📍 *Pinterest Result*\n\nSisa ${images.length - 1} gambar lainnya telah dikirim ke DM kamu 💬\n\n© ${global.wm2}`,
          parse_mode: 'Markdown'
        }
      );
      // === Kirim sisa photo pinterest ke private chat user
      for (let i = 1; i < images.length; i++) {
        await Lyrra.telegram.sendPhoto(
          sender,
          { url: images[i].image_url },
          {
            caption: `🔍 *Pinterest* - Hasil ${i + 1} dari "${query}"\n\n© ${global.wm2}`,
            parse_mode: 'Markdown'
          }
        );
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
    else {
      for (let i = 0; i < images.length; i++) {
        await Lyrra.replyWithPhoto(
          { url: images[i].image_url },
          {
            caption: `🔍 *Pinterest* - Hasil ${i + 1} dari "${query}"\n\n© ${global.wm2}`,
            parse_mode: 'Markdown'
          }
        );
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
  } catch (err) {
    console.error('Pinterest error:', err);
    Lyrra.reply('⚠️ Terjadi kesalahan saat mengambil gambar dari Pinterest.');
  }
}
break;

case 'douyin':
case 'douyindl':
case 'ttcn': {
  const query = Lyrra.message.text.split(' ').slice(1).join(' ').trim();
  if (!query) {
    return Lyrra.reply('📌 Contoh penggunaan:\n/douyin https://v.douyin.com/xxxx\n/douyin newjeans dance');
  }

  await lyreact(Lyrra, '🔍DouyinDL sedang diproses...');

  function extractDouyinUrl(text) {
    const match = text.match(/https?:\/\/v\.douyin\.com\/[A-Za-z0-9]+/);
    return match ? match[0] : null;
  }

  async function resolveDouyinUrl(shortUrl) {
    try {
      const res = await axios.head(shortUrl, { maxRedirects: 0, validateStatus: () => true });
      return res.headers.location || shortUrl;
    } catch {
      return shortUrl;
    }
  }

  function extractFromOnclick(str) {
    if (!str) return null;
    const match = str.match(/https?:\/\/[^\s'"]+/);
    return match ? match[0] : null;
  }

  const douyinUrl = extractDouyinUrl(query);

  if (douyinUrl) {
    try {
      const resolved = await resolveDouyinUrl(douyinUrl);
      const params = new URLSearchParams();
      params.append("q", resolved);
      params.append("lang", "id");

      const dlRes = await axios.post("https://tikvideo.app/api/ajaxSearch", params, {
        headers: {
          "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
          "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
          "x-requested-with": "XMLHttpRequest",
          "referer": "https://tikvideo.app/"
        },
        timeout: 20000
      });

      if (!dlRes.data?.status || typeof dlRes.data.data !== "string")
        throw new Error("Gagal mendapatkan data dari TikVideo.app");

      const html = dlRes.data.data
        .replace(/</g, "<")
        .replace(/>/g, ">")
        .replace(/&amp;/g, "&");

      const $ = cheerio.load(html);

      let noWatermark = null;
      $("a, button, div").each((i, el) => {
        const text = $(el).text();
        const href = $(el).attr("href");
        const dataUrl = $(el).attr("data-url");
        const onclick = $(el).attr("onclick");
        const url = href || dataUrl || extractFromOnclick(onclick) || $(el).attr("data-href");
        if (/MP4/i.test(text) && !/MP3/i.test(text) && url) {
          if (text.includes("HD") || !noWatermark) noWatermark = url;
        }
      });

      if (!noWatermark) {
        const mp4Match = html.match(/https?:\/\/[^"' ]+\.mp4[^\s"'<>]*/);
        if (mp4Match) noWatermark = mp4Match[0];
      }
      if (!noWatermark) throw new Error("Tidak ditemukan link video.");

      let title = $(".tik-right").text().replace(/Download.*|Unduh.*/gi, "").trim();
      if (!title || /Download|Unduh/i.test(title)) {
        title = $("h3").text().trim() || "Video Douyin";
      }

      const thumbnail = $("img[src*='douyin']").attr("src") || null;

      await Lyrra.replyWithVideo(
        { url: noWatermark },
        {
          caption: `✅ *Douyin Download Berhasil!*
🎬 *Title:* ${title}
🔗 *Link:* [Douyin.com]${douyinUrl}
© ${global.wm2}`,
          parse_mode: 'Markdown',
          thumbnail: thumbnail ? { url: thumbnail } : undefined
        }
      );
    } catch (err) {
      console.error('Douyin Download Error:', err.message);
      Lyrra.reply(`❌ Gagal mengunduh video: ${err.message}`);
    }
  } else {
    try {
      const searchRes = await fetch(`https://api.siputzx.my.id/api/s/douyin?query=${encodeURIComponent(query)}`);
      const searchData = await searchRes.json();

      if (!searchData?.status || !searchData?.data?.length) {
        return Lyrra.reply('❌ Tidak ada hasil untuk: ' + query);
      }

      const results = searchData.data.slice(0, 5);
      let msg = `🔍 *Hasil Pencarian Douyin untuk:* _${query}_\n\n`;
      results.forEach((v, i) => {
        msg += `*${i + 1}.* ${v.title || 'Tanpa judul'}\n👤 ${v.author || 'Unknown'}\n❤️ ${v.likes || 0} | 💬 ${v.comments || 0}\n🔗 ${v.url}\n\n`;
      });
      msg += `Kirim ulang dengan link untuk download!`;

      await Lyrra.reply(msg, { parse_mode: 'Markdown' });
    } catch (err) {
      console.error('Douyin Search Error:', err.message);
      Lyrra.reply(`❌ Gagal mencari: ${err.message}`);
    }
  }
}
break;

case 'autowelcome':
case 'welcome':
  if (Lyrra.chat.type === 'private') return Lyrra.reply('❌ Hanya berlaku di grup.');
  const sender = Lyrra.from.id.toString();
  if (String(sender) !== String(global.idAdmins)) return Lyrra.reply('❌ Hanya owner yang bisa.');
  const state = args[0]?.toLowerCase();
  if (!['on', 'off'].includes(state)) return Lyrra.reply('📌 Gunakan: /autowelcome on atau off');

  welcomeConfig[Lyrra.chat.id] = welcomeConfig[Lyrra.chat.id] || {};
  welcomeConfig[Lyrra.chat.id].welcome = state === 'on';
  fs.writeFileSync(WELCOME_FILE, JSON.stringify(welcomeConfig, null, 2));
  Lyrra.reply(`✅ Auto-welcome ${state === 'on' ? 'diaktifkan' : 'dinonaktifkan'} untuk grup ini.`);
break;

case 'setwelcome': {
  if (Lyrra.chat.type === 'private')
    return Lyrra.reply('❌ Hanya berlaku di grup.');

  const sender = Lyrra.from.id.toString();
  if (String(sender) !== String(global.idAdmins))
    return Lyrra.reply('❌ Hanya owner yang bisa.');

  const newMsg = Lyrra.message.text.split(' ').slice(1).join(' ');
  if (!newMsg)
    return Lyrra.reply('📌 Contoh:\n/setwelcome Halo {user}, selamat datang di grup kami!');

  welcomeConfig[Lyrra.chat.id] = welcomeConfig[Lyrra.chat.id] || {};
  welcomeConfig[Lyrra.chat.id].welcomeText = newMsg;
  welcomeConfig[Lyrra.chat.id].welcome = true;

  fs.writeFileSync(WELCOME_FILE, JSON.stringify(welcomeConfig, null, 2));
  Lyrra.reply('✅ Pesan welcome berhasil diubah!');
}
break;

case 'autogoodbye':
case 'goodbye':
  if (Lyrra.chat.type === 'private') return Lyrra.reply('❌ Hanya berlaku di grup.');
  const sender2 = Lyrra.from.id.toString();
  if (String(sender2) !== String(global.idAdmins)) return Lyrra.reply('❌ Hanya owner yang bisa.');
  const state2 = args[0]?.toLowerCase();
  if (!['on', 'off'].includes(state2)) return Lyrra.reply('📌 Gunakan: /goodbye on atau off');

  welcomeConfig[Lyrra.chat.id] = welcomeConfig[Lyrra.chat.id] || {};
  welcomeConfig[Lyrra.chat.id].goodbye = state2 === 'on';
  fs.writeFileSync(WELCOME_FILE, JSON.stringify(welcomeConfig, null, 2));
  Lyrra.reply(`✅ Auto-goodbye ${state2 === 'on' ? 'diaktifkan' : 'dinonaktifkan'} untuk grup ini.`);
break;

case 'setgoodbye': {
  if (Lyrra.chat.type === 'private') return Lyrra.reply('❌ Hanya berlaku di grup.');
  const sender = Lyrra.from.id.toString();
  if (String(sender) !== String(global.idAdmins)) return Lyrra.reply('❌ Hanya owner yang bisa.');
  const newMsg = Lyrra.message.text.split(' ').slice(1).join(' ');
  if (!newMsg) return Lyrra.reply('📌 Contoh: /setgoodbye Selamat tinggal, {user}!');

  welcomeConfig[Lyrra.chat.id] = welcomeConfig[Lyrra.chat.id] || {};
  welcomeConfig[Lyrra.chat.id].goodbyeText = newMsg;
  fs.writeFileSync(WELCOME_FILE, JSON.stringify(welcomeConfig, null, 2));
  Lyrra.reply('✅ Pesan goodbye berhasil diubah!');
}
break;

case 'pinc':
case 'pincomment': {
  const sender = Lyrra.from.id.toString();
  if (String(sender) !== String(global.idAdmins)) return Lyrra.reply('❌ Hanya owner yang bisa.');
  if (Lyrra.chat.type === 'private') return Lyrra.reply('❌ Hanya berlaku di grup.');

  if (!Lyrra.message.reply_to_message) {
    return Lyrra.reply('📌 Reply pesan yang ingin disematkan!');
  }

  try {
    const msgId = Lyrra.message.reply_to_message.message_id;
    await Lyrra.telegram.pinChatMessage(Lyrra.chat.id, msgId, { disable_notification: true });
    Lyrra.reply('📌 Pesan telah disematkan!');
  } catch (err) {
    Lyrra.reply('❌ Gagal menyematkan pesan.');
  }
}
break;

case 'backup':
case 'scbackup':
case 'backupsc': {
  const sender = Lyrra.from.id.toString();
  if (String(sender) !== String(global.idAdmins)) {
    return Lyrra.reply('❌ Hanya owner yang bisa menggunakan perintah ini.');
  }

  await lyreact(Lyrra, '📦 Sedang membuat backup...');

  try {
    const { execSync } = require('child_process');
    const fs = require('fs');
    const path = require('path');

    const ROOT_DIR = path.resolve(__dirname, '../..');
    const TELEGRAM_DIR = __dirname; // 
    const targets = [
      path.join(ROOT_DIR, 'config-setting.json'),       
      path.join(TELEGRAM_DIR, 'database'),            
      path.join(TELEGRAM_DIR, 'lib-signal'),            
      path.join(TELEGRAM_DIR, 'Lyrra.js')
    ];

    const existingTargets = targets.filter(f => fs.existsSync(f));
    if (existingTargets.length === 0) {
      return Lyrra.reply('📁 Tidak ada file/folder valid untuk dibackup.');
    }

    const backupFile = path.join(TELEGRAM_DIR, 'x-system_backup(telegram).tar.gz');

    const escapedFiles = existingTargets.map(f => `"${f}"`).join(' ');
    execSync(`tar -czf "${backupFile}" -C "${ROOT_DIR}" ${escapedFiles.replace(new RegExp(ROOT_DIR + '/', 'g'), '')}`);

    await Lyrra.telegram.sendDocument(
      sender,
      { source: fs.createReadStream(backupFile), filename: 'x-system_backup(telegram).tar.gz' },
      { caption: '📦 *Backup Script Berhasil!*', parse_mode: 'Markdown' }
    );

    fs.unlinkSync(backupFile);

    if (Lyrra.chat.type !== 'private') {
      await Lyrra.reply('✅ Backup berhasil dikirim ke DM kamu!');
    }
  } catch (err) {
    console.error('Backup error:', err);
    Lyrra.reply(`❌ Gagal membuat backup: ${err.message}`);
  }
}
break;

case 'd':
case 'delete':
case 'del': {
  if (Lyrra.chat.type === 'private') return Lyrra.reply('❌ Hanya bisa di grup.');
  
  const replied = Lyrra.message.reply_to_message;
  if (!replied) return Lyrra.reply('❌ Reply pesan yang ingin dihapus.');

  try {
    const member = await Lyrra.telegram.getChatMember(Lyrra.chat.id, Lyrra.from.id);
    const isAdmin = ['administrator', 'creator','superadmin'].includes(member.status);
    if (!isAdmin) return Lyrra.reply('❌ Hanya admin grup yang bisa menghapus pesan.');

    await Lyrra.telegram.deleteMessage(Lyrra.chat.id, replied.message_id);
    try { await Lyrra.deleteMessage(); } catch (e) {}
  } catch (err) {
    console.error('Delete error:', err);
    Lyrra.reply('❌ Gagal menghapus pesan. Pastikan bot jadi admin.');
  }
}
break;

case 'k':
case 'kick':
case 'tendang': {
  if (Lyrra.chat.type === 'private') return Lyrra.reply('❌ Hanya bisa di grup.');

  try {
    const member = await Lyrra.telegram.getChatMember(Lyrra.chat.id, Lyrra.from.id);
    const isAdmin = ['administrator', 'creator'].includes(member.status);
    if (!isAdmin) return Lyrra.reply('❌ Hanya admin grup yang bisa menendang.');

    let targetId = null;
    const replied = Lyrra.message.reply_to_message;
    const mention = Lyrra.message.entities?.find(e => e.type === 'text_mention');

    if (replied) {
      targetId = replied.from.id;
    } else if (mention) {
      targetId = mention.user.id;
    } else {
      return Lyrra.reply('❌ Reply pesan atau tag user yang ingin ditendang.');
    }

    if (targetId == Lyrra.from.id) return Lyrra.reply('❌ Tidak bisa menendang diri sendiri.');
    if (targetId == (await Lyrra.telegram.getMe()).id) return Lyrra.reply('❌ Tidak bisa menendang bot.');

    await Lyrra.telegram.kickChatMember(Lyrra.chat.id, targetId);
    await Lyrra.reply('✅ Pengguna berhasil ditendang!');
    try { await Lyrra.deleteMessage(); } catch (e) {}
  } catch (err) {
    console.error('Kick error:', err);
    Lyrra.reply('❌ Gagal menendang. Pastikan bot jadi admin.');
  }
}
break;

// =============== FIGURINE GENERATOR (DeepFakeMaker) ===============
case 'tofigure':
case 'figure': {
  if (!Lyrra.message.reply_to_message?.photo) {
    return Lyrra.reply('📸 Balas gambar dengan perintah ini!');
  }

  await lyreact(Lyrra, '⏳');

  try {
    const file_id = Lyrra.message.reply_to_message.photo[Lyrra.message.reply_to_message.photo.length - 1].file_id;
    const fileLink = await Lyrra.telegram.getFileLink(file_id);
    const imageBuffer = await fetch(fileLink.href).then(res => res.buffer());

    const axios = require('axios');
    const FormData = require('form-data');
    const crypto = require('crypto');

    function acakName(len = 10) {
      const chars = "abcdefghijklmnopqrstuvwxyz";
      return Array.from({ length: len }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
    }

    async function autoregist() {
      const uid = crypto.randomBytes(12).toString("hex");
      const email = `figure${Date.now()}@nyahoo.com`;
      const payload = {
        uid,
        email,
        displayName: acakName(),
        photoURL: "https://i.pravatar.cc/150",
        appId: "photogpt"
      };
      const res = await axios.post(`https://ai-apps.codergautam.dev/photogpt/create-user`, payload, {
        headers: {
          "content-type": "application/json",
          "accept": "application/json",
          "user-agent": "okhttp/4.9.2"
        }
      });
      if (res.data?.success) return uid;
      throw new Error("Register gagal: " + JSON.stringify(res.data));
    }

    async function img2img(buffer, prompt, mimeType) {
      const uid = await autoregist();
      const ext = 'jpg'; // fallback
      const form = new FormData();
      form.append("image", buffer, { filename: `input.${ext}`, contentType: mimeType });
      form.append("prompt", prompt);
      form.append("userId", uid);

      const uploadRes = await axios.post(`https://ai-apps.codergautam.dev/photogpt/generate-image`, form, {
        headers: {
          ...form.getHeaders(),
          "accept": "application/json",
          "user-agent": "okhttp/4.9.2",
          "accept-encoding": "gzip"
        },
        maxBodyLength: Infinity
      });

      if (!uploadRes.data?.success) throw new Error(JSON.stringify(uploadRes.data));
      const { pollingUrl } = uploadRes.data;

      let status = "pending";
      let resultUrl = null;
      while (status !== "Ready") {
        const pollRes = await axios.get(pollingUrl, {
          headers: { "accept": "application/json", "user-agent": "okhttp/4.9.2" }
        });
        status = pollRes.data?.status;
        if (status === "Ready") {
          resultUrl = pollRes.data?.result?.url;
          break;
        }
        await new Promise(r => setTimeout(r, 3000));
      }

      if (!resultUrl) throw new Error("Tidak ada hasil dari API.");
      const resultImg = await axios.get(resultUrl, { responseType: "arraybuffer" });
      return Buffer.from(resultImg.data);
    }

    const FIGURE_PROMPT = `
Using the nano-banana model, a commercial 1/7 scale figurine of the character in the picture was created, depicting a realistic style and a realistic environment.
The figurine is placed on a computer desk with a round transparent acrylic base. There is no text on the base.
The computer screen shows the Zbrush modeling process of the figurine.
Next to the computer screen is a BANDAI-style toy box with the original painting printed on it.
-- Render the scene in LANDSCAPE orientation (16:9 aspect ratio), wide-angle composition
`.trim();

    const outBuffer = await img2img(imageBuffer, FIGURE_PROMPT, 'image/jpeg');
    await Lyrra.replyWithPhoto(
      { source: outBuffer },
      { caption: `✨ Figurine siap!\n© ${global.wm2}` }
    );

    await lyreact(Lyrra, '✅');

  } catch (err) {
    console.error('PLUGIN tofigure ERROR:', err);
    Lyrra.reply("💥 Error: " + (err.message || err));
  }
}
break;



// =============== DYNAMIC CASE MANAGER ===============


// =============== HD IMAGE PROCESSOR ===============
case 'hd':
case 'hdr':
case 'hdimg':
case 'remini':
case 'enhance':
case 'hd2':
case 'hdr2':
case 'hdimg2':
case 'remini2':
case 'enhance2': {
  const replied = Lyrra.message.reply_to_message;
  if (!replied || !replied.photo) {
    return Lyrra.reply('📸 Kirim atau reply foto dengan perintah ini!');
  }
  const isV2 = ['hd2', 'hdr2', 'hdimg2', 'remini2', 'enhance2'].includes(command);
  const modeText = isV2 ? 'Remini v2 sedang diproses...' : 'HD Photo sedang diproses...';
  await lyreact(Lyrra, `⏳ ${modeText}`);

  const tempPath = path.join(__dirname, `temp_hd_${Date.now()}.jpg`);
  try {
    const photoFileId = replied.photo[replied.photo.length - 1].file_id;
    const fileLink = await Lyrra.telegram.getFileLink(photoFileId);
    const response = await fetch(fileLink.href);
    const buffer = await response.buffer();
    fs.writeFileSync(tempPath, buffer);

    const { Pxpic, upScale, remini } = require('../../lib-signal/data-utils/scrape');

    if (isV2) {
      const CatBox = require('../../lib-signal/data-utils/catbox');
      const Enc = (str) => Buffer.from(str).toString('base64');
      const catboxUrl = await CatBox(tempPath);
      if (!catboxUrl) throw new Error('Gagal upload ke CatBox.');
      const upscaleUrl = `https://fastrestapis.fasturl.link/aiimage/upscale?imageUrl=${Enc(catboxUrl)}&resize=2`;
      try {
        await Lyrra.telegram.deleteMessage(replied.chat.id, replied.message_id);
      } catch (e) { console.warn('Gagal menghapus foto:', e.message); }
      await Lyrra.replyWithPhoto(
        { url: upscaleUrl },
        { caption: `✨ Photo Berhasil menjadi HD (v2)\n© ${global.wm2}` }
      );
    } else {
      let processedImageUrl = null;
      let caption = '✨ Photo Berhasil menjadi HD';
      try {
        const pxpicResult = await Pxpic(tempPath, 'enhance');
        if (pxpicResult?.resultImageUrl) {
          processedImageUrl = pxpicResult.resultImageUrl;
          caption = '✨ Photo Berhasil menjadi HD (Pxpic)';
        }
      } catch (e) { console.warn('Pxpic gagal:', e.message); }
      if (!processedImageUrl) {
        try {
          const upscaleResult = await upScale(tempPath, Lyrra, Lyrra, Lyrra.chat.id);
          if (upscaleResult) {
             if (Buffer.isBuffer(upscaleResult)) {
                 processedImageUrl = { source: upscaleResult };
                 caption = '✨ Photo Berhasil menjadi HD (upScale)';
             }
             else if (typeof upscaleResult === 'string') {
                 processedImageUrl = upscaleResult;
                 caption = '✨ Photo Berhasil menjadi HD (upScale)';
             }
          }
        } catch (e) { console.warn('upScale gagal:', e.message); }
      }
      if (!processedImageUrl) {
        try {
          const reminiBuffer = await remini(tempPath, 'enhance');
          if (reminiBuffer) {
            processedImageUrl = { source: reminiBuffer };
            caption = '✨ Photo Berhasil menjadi HD (remini)';
          }
        } catch (e) { console.warn('remini gagal:', e.message); }
      }
      if (processedImageUrl) {
        try {
          await Lyrra.telegram.deleteMessage(replied.chat.id, replied.message_id);
        } catch (e) { console.warn('Gagal menghapus foto:', e.message); }
        if (typeof processedImageUrl === 'string') {
          await Lyrra.replyWithPhoto(
            { url: processedImageUrl },
            { caption: `${caption}\n© ${global.wm2}` }
          );
        } else if (processedImageUrl.source) {
          await Lyrra.replyWithPhoto(
            processedImageUrl,
            { caption: `${caption}\n© ${global.wm2}` }
          );
        } else {
          await Lyrra.reply('❌ Format hasil tidak dikenal.');
        }
      } else {
        await Lyrra.reply('❌ Gagal memproses gambar. Coba metode lain atau cek file.');
      }
    }
  } catch (err) {
    console.error('HD Error:', err);
    await Lyrra.reply(`❌ Terjadi kesalahan: ${err.message}`);
  } finally {
    try {
      if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
      const tempFiles = fs.readdirSync(__dirname).filter(f => f.startsWith('temp_hd_') && f.endsWith('.jpg'));
      for (const f of tempFiles) fs.unlinkSync(path.join(__dirname, f));
    } catch (e) { /* abaikan */ }
  }
}
break;


// =============== HD VIDEO ENHANCER ===============
case 'hdvid':
case 'hdvideo':
case 'hdvidio': {
  const replied = Lyrra.message.reply_to_message;
  if (!replied || !replied.video) {
    return Lyrra.reply('🎥 Kirim atau reply video dengan perintah ini!');
  }

  await lyreact(Lyrra, '⏳ Memproses video menjadi HD...');

  const tempInput = path.join(__dirname, `temp_vid_${Date.now()}.mp4`);
  const tempOutput = path.join(__dirname, `temp_hdvid_${Date.now()}.mp4`);

  try {
    const videoFileId = replied.video.file_id;
    const fileLink = await Lyrra.telegram.getFileLink(videoFileId);
    const response = await fetch(fileLink.href);
    const buffer = await response.buffer();
    fs.writeFileSync(tempInput, buffer);

    const { hdVideo } = require('../../lib-signal/data-utils/scrape');
    await hdVideo(tempInput, tempOutput);

    await Lyrra.replyWithVideo(
      { source: tempOutput },
      {
        caption: '✨ Video berhasil diubah ke HD!\n© ' + global.wm2,
      }
    );

  } catch (err) {
    console.error('HD Video Error:', err);
    await Lyrra.reply(`❌ Terjadi kesalahan saat memproses video: ${err.message}`);
  } finally {
    try {
      if (fs.existsSync(tempInput)) fs.unlinkSync(tempInput);
      if (fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput);
    } catch (e) { /* abaikan */ }
  }
}
break;


case 'twdl':
case 'twitterdl':
case 'dltwitter':
case 'twitterdownload':
case 'downloadtwitter':
case 'twitter': {
  const url = text;
  if (!url) return Lyrra.reply('📌 Contoh: /twitter https://x.com/username/status/12345');
  if (!/https?:\/\/(x|twitter)\.com\//i.test(url)) return Lyrra.reply('❌ Link harus dari Twitter/X.');

  await lyreact(Lyrra, '🐦 Sedang memproses video Twitter...');

  try {
    const escapeHTML = (str = '') =>
      str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');

    const apiUrl = `https://api.siputzx.my.id/api/d/twitter?url=${encodeURIComponent(url)}`;
    const res = await fetch(apiUrl, { headers: { accept: '*/*' } });
    const json = await res.json();

    if (!json.status || !json.data?.downloadLink) {
      return await Lyrra.reply('⚠️ Gagal mengambil video. Pastikan link valid atau tidak privat.');
    }

    const { imgUrl, downloadLink, videoTitle, videoDescription } = json.data;

    let thumbBuffer = null;
    if (imgUrl) {
      try {
        const thumbRes = await fetch(imgUrl);
        thumbBuffer = await thumbRes.buffer();
      } catch (e) {
        console.warn('Gagal ambil thumbnail Twitter:', e.message);
      }
    }

    await Lyrra.replyWithVideo(
      { url: downloadLink },
      {
        caption: `🎬 <b>Twitter Downloader</b>\n\n🧷 <a href="${escapeHTML(url)}">Sumber Asli</a>\n📹 <b>Judul:</b> ${escapeHTML(videoTitle || 'Tanpa judul')}\n📝 <b>Deskripsi:</b>\n${escapeHTML(videoDescription || '-')}\n\n© ${global.wm2}`,
        parse_mode: 'HTML',
        ...(thumbBuffer && { thumbnail: thumbBuffer }),
      }
    );

  } catch (err) {
    console.error('🐦 Twitter Error:', err);
    await Lyrra.reply(`❌ Terjadi kesalahan saat memproses video: ${err.message}`);
  }
}
break;


case 'cekid':
case 'info':
case 'infoid': {
  try {
    const user = Lyrra.from;
    const chat = Lyrra.chat;
    const botInfo = await Lyrra.telegram.getMe();

    const userId = user.id;
    const firstName = user.first_name || '-';
    const lastName = user.last_name ? ` ${user.last_name}` : '';
    const fullName = `${firstName}${lastName}`;
    const username = user.username ? `@${user.username}` : '❌ Tidak ada username';

    const chatType = chat.type;
    const isPrivate = chatType === 'private';
    const chatTitle = chat.title || '—';
    const chatId = chat.id;

    // ====================== PRIVATE CHAT ======================
       if (isPrivate) {
    const info = `🧩 <b>Informasi Pengguna</b>\n\n` +
                 `🙋‍♂️ <b>Nama:</b> ${escapeHTML(fullName)}\n` +
                 `🆔 <b>User ID:</b> <code>${escapeHTML(String(userId))}</code>\n` +
                 `🌐 <b>Username:</b> ${escapeHTML(username)}\n\n` +
                 `© ${escapeHTML(global.wm2)}`;
           
    await Lyrra.reply(info, { parse_mode: 'HTML' });
    }

    // ====================== GRUP CHAT ======================
    else {
      const info = `🏷️ Informasi Grup\n\n` +
                   `💬 Nama Grup: ${escapeMarkdown(chatTitle)}\n` +
                   `🆔 Group ID: \`${chatId}\`\n\n` +
                   `Tekan tombol di bawah untuk cek ID kamu di chat bot!`;

      const botUsername = botInfo.username;
      const deepLink = `https://t.me/${botUsername}?start=cekid`;

  await Lyrra.reply(info, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [{ text: '🧾 CEK ID SAYA', url: deepLink }]
      ]
    }
  });
  }

  } catch (err) {
    console.error('Error infoid:', err.message);
    await Lyrra.reply('⚠️ Terjadi kesalahan saat mengambil informasi ID.');
  }
  break;
}


case 'iqc':
case 'iphonesticker':
case 'stickeriphone': {
    if (!text) return Lyrra.reply(`Example:\n${prefix}iqc Tega kamu sakitin hati aku`);

    // Jam lokal Indonesia
    let time = new Intl.DateTimeFormat('id-ID', {
        timeZone: 'Asia/Jakarta',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
    }).format(new Date());

    // Generate URL API
    let apiUrl = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(time)}&batteryPercentage=${Math.floor(Math.random() * 100) + 1}&carrierName=INDOSAT&messageText=${encodeURIComponent(text.trim())}&emojiStyle=apple`;

    await Lyrra.replyWithPhoto(
        { url: apiUrl },
        {
            caption: `Berhasil membuat iPhoneQuote\n\n© ${wm2}`,
        }
    );
}
break;



case 'delres':
case 'removereseller':
case 'deletereseller': {
  try {
    const fs = require('fs');
    const path = './x-system/telegram/database/reseller.json';
    const senderId = Lyrra.from.id.toString();
    const targetId = Lyrra.message.text.split(' ')[1];

    // Hanya owner
    if (String(senderId) !== String(global.idAdmins)) {
      return Lyrra.reply('❌ Fitur ini hanya untuk Owner bot.');
    }

    if (!targetId) return Lyrra.reply('📌 *Contoh:* /delres 123456789');

    if (!fs.existsSync(path)) return Lyrra.reply('❌ Database reseller belum dibuat.');

    let db = JSON.parse(fs.readFileSync(path));
    if (!Array.isArray(db)) db = [];

    if (!db.includes(targetId)) {
      return Lyrra.reply('⚠️ *User tersebut bukan reseller*.');
    }

    db = db.filter(id => id !== targetId);
    fs.writeFileSync(path, JSON.stringify(db, null, 2));

    await Lyrra.reply(`🗑 Reseller dengan ID \n*${targetId}* user telah dihapus dari Resseler.${wm2}`);
  } catch (err) {
    console.error('❌ Error delres:', err);
    await Lyrra.reply('❌ Terjadi kesalahan saat menghapus reseller.');
  }
}
break;

case 'listres':
case 'reslist':
case 'resellerlist': {
  try {
    const fs = require('fs');
    const path = './x-system/telegram/database/reseller.json';

    if (!fs.existsSync(path)) {
      return Lyrra.reply('📂 Belum ada reseller yang terdaftar.');
    }

    let db = JSON.parse(fs.readFileSync(path));
    if (!Array.isArray(db) || db.length === 0) {
      return Lyrra.reply('📂 Belum ada reseller yang terdaftar.');
    }

    let text = `📜 *DAFTAR RESELLER*\n━━━━━━━━━━━━━━\n`;

    for (let i = 0; i < db.length; i++) {
      const id = db[i];
      let usernameTag = id; 

      try {
        const chat = await Lyrra.telegram.getChat(id);
        if (chat.username) {
          usernameTag = `@${chat.username}`;
        } else if (chat.first_name || chat.last_name) {
          usernameTag = `${chat.first_name || ''} ${chat.last_name || ''}`.trim();
        }
      } catch (err) {
      }
      text += `${i + 1}. \`${id}\` (${usernameTag})\n`;
    }
    await Lyrra.reply(text, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error('❌ Error listres:', err);
    await Lyrra.reply('❌ Gagal memuat daftar reseller.');
  }
}
break;

case 'restart':
case 'rt':
case 'restartbot': {
    const userId = String(Lyrra.from.id);

    if (String(userId) !== String(global.idAdmins)) {
        return Lyrra.reply("❌ Kamu bukan owner!");
    }

    await Lyrra.reply(`🔁 Merestart bot *${global.wm2}*...`);
    await new Promise(res => setTimeout(res, 2000));

    await Lyrra.reply("✅ Restart success! Bot akan hidup kembali...");

    process.exit(1);
}
break;

case 'off-bot':
case 'bot-off':
case 'stopbot':
case 'stop-bot':
case 'bot-stop':
case 'botstop':
case 'bot-kill': {
  const sender = Lyrra.from.id.toString();
  const isOwner = String(sender) === String(global.idAdmins);
  if (!isOwner) {
    return Lyrra.reply('❌ Hanya owner yang bisa menggunakan perintah ini.');
  }

  await edit2("Stopped server...", "Sukses Stopped server!");
  await sleep(5000);
  process.exit(0);

}
break;


case 'tourl': {
    const { message, reply, telegram } = Lyrra;
    const quoted = message.reply_to_message;

    if (!quoted || (!quoted.document && !quoted.photo && !quoted.video))
        return reply('❌ Reply foto/video/file yang ingin diupload.');

    const axios = require("axios");
    const FormData = require("form-data");
    const { fromBuffer } = require("file-type");

    // === TERMAI CONFIG ===
    const termaiKey = "AIzaBj7z2z3xBjsk"; 
    const termaiDomain = "https://c.termai.cc";

    async function uploadTermai(buffer) {
        try {
            const { ext } = await fromBuffer(buffer);
            const form = new FormData();
            form.append("file", buffer, "file." + ext);

            const res = await axios.post(`${termaiDomain}/api/upload?key=${termaiKey}`, form, {
                headers: form.getHeaders(),
                timeout: 60000
            });

            return res.data?.status && res.data.path ? res.data.path : null;
        } catch {
            return null;
        }
    }

    async function uploadCatbox(buffer) {
        try {
            const { ext } = await fromBuffer(buffer);
            const form = new FormData();
            form.append("fileToUpload", buffer, "file." + ext);
            form.append("reqtype", "fileupload");

            const res = await axios.post("https://catbox.moe/user/api.php", form, {
                headers: form.getHeaders(),
                timeout: 60000
            });

            return (typeof res.data === "string" && res.data.startsWith("http"))
                ? res.data
                : null;
        } catch {
            return null;
        }
    }

    try {
        const fileId =
            quoted.document?.file_id ||
            (quoted.photo ? quoted.photo.slice(-1)[0].file_id : null) ||
            quoted.video?.file_id;

        const fileLink = await telegram.getFileLink(fileId);
        const fileRes = await axios.get(fileLink.href, { responseType: "arraybuffer" });
        const buffer = Buffer.from(fileRes.data);
        const [catbox, termai] = await Promise.all([
            uploadCatbox(buffer),
            uploadTermai(buffer)
        ]);

        const catboxLink = catbox || "Gagal upload Catbox";
        const termaiLink = termai || "Gagal upload Termai";

        const caption =
            `📁 *Upload Berhasil*\n\n` +
            `🌐 Catbox: ${catboxLink}\n` +
            `🌐 Termai: ${termaiLink}\n\n` +
            `Silakan pilih tombol di bawah untuk membuka.`;

        const keyboard = {
            inline_keyboard: [
                [{ text: "🌐 Buka Catbox", url: catbox ? catbox : "https://catbox.moe" }],
                [{ text: "🌐 Buka Termai", url: termai ? termai : "https://c.termai.cc" }]
            ]
        };
        await telegram.sendMessage(message.chat.id, caption, {
            parse_mode: "Markdown",
            reply_markup: keyboard
        });

    } catch (err) {
        console.error("tourl error:", err);
        reply('❌ Gagal mengupload file.');
    }
}
break;

case 'txt': {
  const reply = Lyrra.message?.reply_to_message;

  if (!reply || !reply.text) {
    return Lyrra.reply('❗ Balas pesan teks dulu, lalu ketik /txt');
  }

  const text = reply.text;
  const filename = `text-${Date.now()}.txt`;

  const buffer = Buffer.from(text, 'utf-8');

  await Lyrra.telegram.sendDocument(
    Lyrra.chat.id,
    {
      source: buffer,
      filename: filename
    },
    {
      caption: `📄 File TXT berhasil dibuat.`,
      reply_to_message_id: Lyrra.message.message_id
    }
  );
}
break;

    // ===== AUTO CASE INSERTED =====
case "ytmp4":
case "ytvideo":
case "ytv": {
    const link = args[0];
    if (!link) return Lyrra.reply("⚠️ Contoh:\n/ytmp4 https://youtu.be/xxxxx");

    const ytRegex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\//i;
    if (!ytRegex.test(link)) {
        return Lyrra.reply("❌ URL YouTube tidak valid.");
    }

    await lyreact(Lyrra, "⏳ YTMP4 sedang diproses...");
    let title, downloadURL, sizeText;
    try {
        const headers = {
            "accept": "*/*",
            "accept-language": "id-ID,id;q=0.9",
            "user-agent": "Mozilla/5.0 (Linux; Android 13)",
            "origin": "https://id.ytmp3.mobi",
            "referer": "https://id.ytmp3.mobi/"
        };

        const initRes = await fetch(`https://d.ymcdn.org/api/v1/init?p=y&_=${Date.now()}`, { headers });
        const init = await initRes.json();

        if (!init.convertURL) throw new Error("API utama gagal.");

        const idMatch = link.match(/(?:v=|youtu\.be\/|embed\/)([^&?/]+)/);
        if (!idMatch) throw new Error("Gagal membaca ID video.");
        const vid = idMatch[1];

        const convertURL = `${init.convertURL}&v=${vid}&f=mp4&_=${Math.random()}`;
        const convertRes = await fetch(convertURL, { headers });
        const convert = await convertRes.json();

        if (!convert.progressURL) throw new Error("Gagal memulai konversi.");

        let info = {};
        for (let i = 0; i < 10; i++) {
            await new Promise(r => setTimeout(r, 2000));
            const progress = await fetch(convert.progressURL, { headers });
            info = await progress.json();
            if (info.progress === 3 && info.downloadURL) break;
        }

        downloadURL = info.downloadURL || convert.downloadURL;
        if (!downloadURL) throw new Error("Tidak menemukan link download.");

        title = info.title || convert.title || "Judul tidak tersedia";
        sizeText = convert.size || "Unknown";

    } catch (err1) {
        console.log("⚠️ API utama gagal:", err1.message);

        try {
            const backupRes = await fetch(`https://yt-api.my.id/api/ytmp4?url=${encodeURIComponent(link)}`);
            const backup = await backupRes.json();
            
            if (!backup.status) throw new Error("API backup gagal.");

            title = backup.result.title;
            downloadURL = backup.result.url;
            sizeText = backup.result.size;

        } catch (err2) {
            console.log("⚠️ API backup gagal:", err2.message);

            const lastRes = await fetch(`https://api.ryzendesu.vip/api/downloader/ytmp4?url=${encodeURIComponent(link)}`);
            const last = await lastRes.json();

            if (!last.status && !last.result?.url) {
                throw new Error("Semua API gagal (utama + cadangan).");
            }

            title = last.result?.title || "Tanpa Judul";
            downloadURL = last.result?.url;
            sizeText = last.result?.size || "Unknown";
        }
    }

    if (!downloadURL) return Lyrra.reply("❌ Gagal mendapatkan link download.");

    const escapeMD = txt => txt.replace(/([_*[\]()~>#+\-=|{}.!\\])/g, "\\$1");
    const safeTitle = escapeMD(title);
    const safeLink = escapeMD(link);

    // BUAT CALLBACK UNTUK TOMBOL MP3
    const crypto = require("crypto");
    const hash = crypto.createHash("md5").update(link).digest("hex").slice(0, 10);

    global.ytmp4LinkCache.set(hash, link);

    const inlineKeyboard = [
        [{ text: "🎵 Audio MP3", callback_data: `ytmp3_req|${hash}` }]
    ];

    // KIRIM KE TELEGRAM
    await Lyrra.replyWithVideo(
        { url: downloadURL },
        {
            caption: `
📹 *Youtube Video Download*

🎥 *Title:* ${safeTitle}
💾 *Size:* ${sizeText}
🔗 *Source:* [youtube.com](${safeLink})

© ${global.wm2}
            `.trim(),
            parse_mode: "Markdown",
            reply_markup: { inline_keyboard: inlineKeyboard }
        }
    );
}
break;

    // ===== END AUTO CASE =====
case 'addcase': {
  const sender = Lyrra.from.id.toString();
  if (String(sender) !== String(global.idAdmins)) {
    return Lyrra.reply('❌ Hanya owner yang bisa menggunakan perintah ini.');
  }

  const quoted = Lyrra.message.reply_to_message;

  if (!quoted || !quoted.document) {
    return Lyrra.reply('📌 Reply sebuah file .txt atau .js berisi kode case.');
  }

  try {
    const fileId = quoted.document.file_id;
    const fileLink = await Lyrra.telegram.getFileLink(fileId);

    // Download file
    const axios = require('axios');
    const res = await axios.get(fileLink.href, { responseType: 'text' });
    const rawInput = res.data;

    const filePath = path.join(__dirname, 'Lyrra.js');
    let fileContent = fs.readFileSync(filePath, 'utf8');

    const anchor = "case 'addcase': {";
    const posisiAddcase = fileContent.indexOf(anchor);

    if (posisiAddcase === -1) {
      return Lyrra.reply('❌ Anchor addcase tidak ditemukan.');
    }

    // Backup
    const backupPath = path.join(__dirname, `vreyn_backup_${Date.now()}.js`);
    fs.writeFileSync(backupPath, fileContent);

    // Insert kode mentah TANPA ESCAPE
    const injected =
`\n\n    // ===== AUTO CASE INSERTED =====
${rawInput}
    // ===== END AUTO CASE =====\n`;

    const newContent =
      fileContent.slice(0, posisiAddcase) +
      injected +
      fileContent.slice(posisiAddcase);

    fs.writeFileSync(filePath, newContent);

    await Lyrra.reply(
      `✅ Case berhasil ditambahkan!\n📦 Backup: *${path.basename(backupPath)}*\n🔄 Silakan restart bot.`
    );

  } catch (err) {
    console.error(err);
    Lyrra.reply(`❌ Gagal menambahkan case: ${err.message}`);
  }
}
break;

case 'delcase': {
  const sender = Lyrra.from.id.toString();
  const isOwner = String(sender) === String(global.idAdmins);
  if (!isOwner) return Lyrra.reply('❌ Hanya owner yang bisa menggunakan perintah ini.');

  const caseName = Lyrra.message.text.split(' ')[1];
  if (!caseName) return Lyrra.reply('📌 Contoh: /delcase test');

  try {
    const namaFile = path.join(__dirname, 'Lyrra.js');
    let data = fs.readFileSync(namaFile, 'utf8');

    // Buat regex untuk menghapus case lengkap
    const regex = new RegExp(`case\\s+['"]${caseName}['"][\\s\\S]*?break;?`, 'g');
    const dataBaru = data.replace(regex, '').trim();

    if (dataBaru === data) {
      return Lyrra.reply(`❌ Case '${caseName}' tidak ditemukan.`);
    }

    fs.writeFileSync(namaFile, dataBaru, 'utf8');
    await Lyrra.reply('✅ Case berhasil dihapus!');

    if (Lyrra.chat.type !== 'private') {
      try {
        await Lyrra.deleteMessage();
      } catch (e) {
      }
    }

  } catch (err) {
    console.error('Error delcase:', err);
    Lyrra.reply(`❌ Gagal menghapus case: ${err.message}`);
  }
}
break;

case 'getcase': {
  const sender = Lyrra.from.id.toString();
  const isOwner = String(sender) === String(global.idAdmins);
  if (!isOwner) return Lyrra.reply('❌ Hanya owner yang bisa menggunakan perintah ini.');

  const caseNames = Lyrra.message.text.split(' ').slice(1);
  if (caseNames.length === 0) return Lyrra.reply('📌 Contoh: /getcase test1 test2');

  try {
    const namaFile = path.join(__dirname, 'Lyrra.js');
    const data = fs.readFileSync(namaFile, 'utf8');

    const hasil = [];
    for (const name of caseNames) {
      const regex = new RegExp(`case\\s+['"]${name}['"][\\s\\S]*?break;?`, 'g');
      const match = data.match(regex);
      if (match) {
        hasil.push(match[0]);
      } else {
        hasil.push(`// Case '${name}' tidak ditemukan.`);
      }
    }

    let kodeLengkap = hasil.join('\n\n');

    function escapeMarkdown(text = '') {
      return String(text)
        .replace(/([_*\[\]()~`>#+\-=|{}.!\\])/g, '\\$1');
    }

    kodeLengkap = escapeMarkdown(kodeLengkap);

    const chunks = kodeLengkap.match(/[\s\S]{1,4000}/g) || [];

    for (const chunk of chunks) {
      await Lyrra.telegram.sendMessage(sender, '```\n' + chunk + '\n```', {
        parse_mode: 'MarkdownV2',
        disable_notification: true
      });
    }

    if (Lyrra.chat.type !== 'private') {
      await Lyrra.reply('✅ Kode case telah dikirim ke DM kamu 💬');
      try {
        await Lyrra.deleteMessage();
      } catch (e) {
      }
    }

  } catch (err) {
    console.error('Error getcase:', err);
    Lyrra.reply(`❌ Gagal mengambil case: ${err.message}`);
  }
}
break;




    default:
  }
});
setupCallbackHandlers(Lyrra, handlerlist, welcomeConfig);
// =============== LAUNCH BOT ===============
Lyrra.launch()
  .then(() => console.log('Bot Telegram aktif.'))
  .catch((err) => console.error('Gagal menjalankan bot:', err.message));

process.once('SIGINT', () => Lyrra.stop('SIGINT'));
process.once('SIGTERM', () => Lyrra.stop('SIGTERM'));

return Lyrra;
} catch (err) {
  console.log(require('util').format(err));
}
}

startTelegramBot();

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(`Update ${__filename}`);
  delete require.cache[file];
  require(file);
});se: ${err.message}`);
  }
}
break;

case 'getcase': {
  const sender = Lyrra.from.id.toString();
  const isOwner = String(sender) === String(global.idAdmins);
  if (!isOwner) return Lyrra.reply('❌ Hanya owner yang bisa menggunakan perintah ini.');

  const caseNames = Lyrra.message.text.split(' ').slice(1);
  if (caseNames.length === 0) return Lyrra.reply('📌 Contoh: /getcase test1 test2');

  try {
    const namaFile = path.join(__dirname, 'Lyrra.js');
    const data = fs.readFileSync(namaFile, 'utf8');

    const hasil = [];
    for (const name of caseNames) {
      const regex = new RegExp(`case\\s+['"]${name}['"][\\s\\S]*?break;?`, 'g');
      const match = data.match(regex);
      if (match) {
        hasil.push(match[0]);
      } else {
        hasil.push(`// Case '${name}' tidak ditemukan.`);
      }
    }

    let kodeLengkap = hasil.join('\n\n');

    function escapeMarkdown(text = '') {
      return String(text)
        .replace(/([_*\[\]()~`>#+\-=|{}.!\\])/g, '\\$1');
    }

    kodeLengkap = escapeMarkdown(kodeLengkap);

    const chunks = kodeLengkap.match(/[\s\S]{1,4000}/g) || [];

    for (const chunk of chunks) {
      await Lyrra.telegram.sendMessage(sender, '```\n' + chunk + '\n```', {
        parse_mode: 'MarkdownV2',
        disable_notification: true
      });
    }

    if (Lyrra.chat.type !== 'private') {
      await Lyrra.reply('✅ Kode case telah dikirim ke DM kamu 💬');
      try {
        await Lyrra.deleteMessage();
      } catch (e) {
      }
    }

  } catch (err) {
    console.error('Error getcase:', err);
    Lyrra.reply(`❌ Gagal mengambil case: ${err.message}`);
  }
}
break;




    default:
  }
});
setupCallbackHandlers(Lyrra, handlerlist, welcomeConfig);
// =============== LAUNCH BOT ===============
Lyrra.launch()
  .then(() => console.log('Bot Telegram aktif.'))
  .catch((err) => console.error('Gagal menjalankan bot:', err.message));

process.once('SIGINT', () => Lyrra.stop('SIGINT'));
process.once('SIGTERM', () => Lyrra.stop('SIGTERM'));

return Lyrra;
} catch (err) {
  console.log(require('util').format(err));
}
}

startTelegramBot();

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(`Update ${__filename}`);
  delete require.cache[file];
  require(file);
});