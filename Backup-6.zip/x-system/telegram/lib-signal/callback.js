const fs = require('fs');
const path = require('path');
const axios = require('axios');
const crypto = require('crypto');
const os = require('os');
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
const { codeBlock } = require('telegraf/format');
const pathDb = path.join(__dirname, '../database/database.json');

module.exports = function setupCallbackHandlers(Lyrra, handlerlist, welcomeConfig) {

function getUserLang(userId) {
  try {
    if (!global.db || !global.db.data) return 'Indonesia';
    const user = global.db.data.users?.[String(userId)];
    return user?.bahasa || 'Indonesia'; // default Indonesia
  } catch {
    return 'Indonesia';
  }
}
    
// ===== Helper: safe HTML escape =====
function escapeHTML(s = '') {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function escapeMarkdown(text = '') {
  return text.replace(/([_*[\]()~`>#+\-=|{}.!\\])/g, '\\$1');
}
    
function escapeMD(text) {
    return text.replace(/([_*[\]()~`>#+\-=|{}.!\\])/g, "\\$1");
}

async function safeEdit(ctx, newText, options = {}) {
  try {
    const msg = ctx.callbackQuery?.message;
    if (msg?.photo) {
      await ctx.editMessageCaption(newText, options);
    } else {
      await ctx.editMessageText(newText, options);
    }
  } catch (err) {
    await ctx.reply(newText, options).catch(() => {});
  }
}

 // ============= YTMP3 & YTMP4 FUNCTION ============ //
const savetube = {
    api: { base: "https://media.savetube.me/api", cdn: "/random-cdn", info: "/v2/info", download: "/download" },
    headers: {
        'accept': '*/*', 'content-type': 'application/json',
        'origin': 'https://yt.savetube.me',
        'referer': 'https://yt.savetube.me/',
        'user-agent': 'Postify/1.0.0'
    },
    formats: ['mp3'],
    crypto: {
        hexToBuffer: (hex) => Buffer.from(hex.match(/.{1,2}/g).join(''), 'hex'),
        decrypt: async (enc) => {
            const secretKey = 'C5D58EF67A7584E4A29F6C35BBC4EB12';
            const data = Buffer.from(enc, 'base64');
            const iv = data.slice(0,16);
            const content = data.slice(16);
            const key = savetube.crypto.hexToBuffer(secretKey);
            const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);
            let decrypted = decipher.update(content);
            decrypted = Buffer.concat([decrypted, decipher.final()]);
            return JSON.parse(decrypted.toString());
        }
    },
    youtube: (url) => {
        if (!url) return null;
        const regex = [
            /youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
            /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
            /youtube\.com\/v\/([a-zA-Z0-9_-]{11})/,
            /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
            /youtu\.be\/([a-zA-Z0-9_-]{11})/
        ];
        for (let r of regex) if (r.test(url)) return url.match(r)[1];
        return null;
    },
    request: async (endpoint, data = {}, method='post') => {
        const { data: response } = await axios({
            method, url: `${endpoint.startsWith('http') ? '' : savetube.api.base}${endpoint}`,
            data: method==='post'?data:undefined,
            params: method==='get'?data:undefined,
            headers: savetube.headers
        });
        return { status:true, code:200, data:response };
    },
    getCDN: async () => { const res = await savetube.request(savetube.api.cdn, {}, 'get'); return res.data.cdn; },
    download: async (link, format='mp3') => {
        const id = savetube.youtube(link);
        if (!id) throw new Error('Link YouTube tidak valid');
        const cdn = await savetube.getCDN();
        const infoRes = await savetube.request(`https://${cdn}${savetube.api.info}`, { url:`https://www.youtube.com/watch?v=${id}` });
        const decrypted = await savetube.crypto.decrypt(infoRes.data.data);
        const dl = await savetube.request(`https://${cdn}${savetube.api.download}`, {
            id, downloadType: format==='mp3'?'audio':'video',
            quality: format==='mp3'?'128':'360',
            key: decrypted.key
        });
        return {
            title: decrypted.title,
            duration: decrypted.duration,
            thumbnail: decrypted.thumbnail||`https://i.ytimg.com/vi/${id}/0.jpg`,
            download: dl.data.data.downloadUrl
        };
    }
};

// ======= YTMP4 PLUGIN =======
const ytmp4 = async (url) => {
    const headers = {
        "accept":"*/*","accept-language":"id-ID,id;q=0.9,en-US;q=0.8","user-agent":"Mozilla/5.0",
        "origin":"https://id.ytmp3.mobi","referer":"https://id.ytmp3.mobi/"
    };
    const id = url.match(/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*embed\/))([^&?/]+)/)?.[1];
    if (!id) throw new Error('URL tidak valid.');
    let init = await fetch(`https://d.ymcdn.org/api/v1/init?p=y&_=${Math.random()}`, { headers });
    init = await init.json();
    const convertRes = await fetch(`${init.convertURL}&v=${id}&f=mp4&_=${Math.random()}`, { headers });
    const convert = await convertRes.json();
    let info = {};
    for (let i=0;i<5;i++) {
        const prog = await fetch(convert.progressURL, { headers });
        info = await prog.json();
        if (info.progress===3 && info.downloadURL) break;
        await new Promise(r=>setTimeout(r,1500));
    }
    return {
        title: info.title || "Unknown",
        download: info.downloadURL
    };
};
 // ================== END ================ //


  // ==================== CALLBACK QUERY (HANYA SATU) ====================
  Lyrra.on('callback_query', async (ctx) => {
    try {
      const data = ctx.callbackQuery.data;

      // ======== CALLBACK JOIN GRUP ========
      if (data === 'join_group') {
        try {
          await ctx.answerCbQuery('📨 Klik tombol link grup untuk bergabung.', { show_alert: true });
          await ctx.editMessageReplyMarkup({
            inline_keyboard: [
              [
                { text: '🌐 BUKA LINK GROUP', url: `${global.group}` }, 
                { text: '✅ VERIFIKASI', callback_data: 'verify_group' }
              ]
            ]
          });
        } catch (err) {
          console.error('Error callback JOIN GRUP:', err.message);
          await ctx.answerCbQuery('⚠️ Terjadi kesalahan saat membuka tautan.', { show_alert: true });
        }
        return;
      }

      // ======== CALLBACK VERIFIKASI ========
      if (data === 'verify_group') {
        try {
          const userId = ctx.from.id;
          const groupId = global.idgroup;
          const member = await Lyrra.telegram.getChatMember(groupId, userId);

          if (['member', 'administrator', 'creator'].includes(member.status)) {
            await ctx.answerCbQuery('🎉 Selamat! Kamu berhasil verifikasi!', { show_alert: true });
            await ctx.editMessageReplyMarkup({
              inline_keyboard: [[{ text: '📋 BUKA MENU', callback_data: 'menu_open' }]]
            });
          } else {
            await ctx.answerCbQuery(
              '🚫 KAMU BELUM JOIN KE DALAM GROUP!\nJOIN GROUP TERLEBIH DAHULU!\n\nSETELAH JOIN KETUK TOMBOL VERIFIKASI\n\n© Powered by : @rbonlym',
              { show_alert: true }
            );
          }
        } catch (err) {
          console.error('Error callback VERIFIKASI:', err.message);
          await ctx.answerCbQuery('⚠️ Gagal memeriksa status keanggotaan.', { show_alert: true });
        }
        return;
      }

      // ======== CALLBACK MENU (utama & sub-menu) ========
if (data === 'menu_open') {
  try {
    const userId = ctx.from.id;
    const lang = getUserLang(userId);

    const inlineKeyboard = [
      [{ text: '📥 Perintah', callback_data: 'menu_perintah' }, { text: '💾 Download', callback_data: 'menu_download' }],
      [{ text: '☪️ Islamic', callback_data: 'menu_islamic' }, { text: '🔍 Search', callback_data: 'menu_search' }],
      [{ text: '👑 Owner', callback_data: 'menu_owner' }, { text: '🔞 NSFW', callback_data: 'menu_nsfw' }],
      [{ text: '⚔️ RPG', callback_data: 'menu_rpg' }, { text: '🖼️ Anime', callback_data: 'menu_anime' }],
      [{ text: '📦 Other', callback_data: 'menu_other' }, { text: '⚙️ Tools', callback_data: 'menu_tools' }],
      [{ text: '🌐 Language', callback_data: 'settings_lang' }]
    ];

    const jsSnippet = `// Info Bot
✨ ${global.i18n[lang].greeting} ${global.botname2 || 'Bot'} Bot Telegram
${global.i18n[lang].help}

© ${global.wm2 || ''}`;

    const caption = `\`\`\`${global.storename2}\n${jsSnippet}\n\`\`\``;

    await safeEdit(ctx, caption, {
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: inlineKeyboard }
    });
  } catch {
    await ctx.answerCbQuery('⚠️ Gagal membuka menu utama.', { show_alert: true });
  }
  return;
}


      // ==================== CALLBACK SUB-MENU ====================
      if (data.startsWith('menu_') && !['menu_back', 'menu_open'].includes(data)) {
        const menuType = data.replace('menu_', '');
        const formatMenu = (title, items) =>
          items?.length
            ? `📋 <b>${title}</b>\n` + items.map(cmd => `${cmd}`).join('\n')
            : `📋 <b>${title}</b>\n(❌ Belum ada perintah)`;

        const menus = {
          perintah: handlerlist.perintah,
          download: handlerlist.download,
          islamic: handlerlist.islamic,
          search: handlerlist.search,
          owner: handlerlist.owner,
          nsfw: handlerlist.nsfw,
          rpg: handlerlist.rpg,
          anime: handlerlist.anime,
          other: handlerlist.other,
          tools: handlerlist.tools
        };

        const selected = menus[menuType];
        if (!selected)
          return ctx.answerCbQuery('❌ Menu tidak ditemukan.', { show_alert: true });

        await ctx.editMessageCaption(formatMenu(menuType.toUpperCase(), selected), {
          parse_mode: 'HTML',
          reply_markup: { inline_keyboard: [[{ text: '🔙 Kembali', callback_data: 'menu_back' }]] }
        });
        return;
      }

    // =============== YOUTUBE MP3 CALLBACK ===============
    if (data.startsWith('ytmp3_req|')) {
      const parts = data.split('|');
      if (parts.length < 2) return ctx.answerCbQuery('❌ Data tidak valid!');

      const linkHash = parts[1];
      const originalLink = global.ytmp4LinkCache.get(linkHash);

      if (!originalLink) {
        await ctx.answerCbQuery('❌ Link audio tidak ditemukan atau sudah kadaluarsa.');
        await ctx.editMessageReplyMarkup({
          inline_keyboard: [[{ text: '❌ Link Kadaluarsa', callback_data: 'audiodone' }]]
        });
        return;
      }

      await ctx.answerCbQuery('🎵 Mengambil audio MP3...');

      try {
        global.ytmp4LinkCache.delete(linkHash);

        const api = `https://api.nekolabs.web.id/downloader/youtube/v1?url=${encodeURIComponent(originalLink)}&format=mp3`;
        const res = await fetch(api);
        const data = await res.json();

        if (!data.success || !data.result?.downloadUrl) {
          await ctx.reply('❌ Gagal mengambil audio dari API.');
          await ctx.editMessageReplyMarkup({
            inline_keyboard: [[{ text: '❌ Gagal', callback_data: 'audiodone' }]]
          });
          return;
        }

        const result = data.result;
        const audioUrl = result.downloadUrl.trim();
        const title = result.title || 'Audio YouTube';
        const coverUrl = result.cover?.trim() || global.thumb22;

        let thumbBuffer = null;
        try {
          if (coverUrl) {
            const thumbRes = await fetch(coverUrl);
            if (thumbRes.ok) thumbBuffer = await thumbRes.buffer();
          }
        } catch (e) {
          console.warn('Gagal ambil thumbnail di callback:', e.message);
        }

        await ctx.replyWithAudio(
          { url: audioUrl },
          {
            caption: `🎧 *${title}*\n© ${global.wm2}`,
            parse_mode: 'Markdown',
            thumb: thumbBuffer ? { source: thumbBuffer } : undefined,
            title: title,
            performer: 'YouTube'
          }
        );

        await ctx.editMessageReplyMarkup({
          inline_keyboard: [[{ text: '✅ Audio MP3', callback_data: 'audiodone' }]]
        });

      } catch (err) {
        console.error('YT MP3 Callback error:', err);
        await ctx.reply('❌ Gagal memproses audio.');
        await ctx.editMessageReplyMarkup({
          inline_keyboard: [[{ text: '❌ Gagal', callback_data: 'audiodone' }]]
        });
      }
      return;
    }

// ================= CALLBACK: CEK ID USERNAME =================
if (data === 'cekid_user') {
  try {
    const user = ctx.from;
    const userId = user.id;
    const username = user.username ? `@${user.username}` : '❌ Tidak ada username';
    const firstName = user.first_name || '-';
    const lastName = user.last_name ? ` ${user.last_name}` : '';
    const fullName = `${firstName}${lastName}`;

    const popupText = 
`👤 Nama: ${fullName}
🆔 User ID: ${userId}
🌐 Username: ${username}

📋 Tekan & tahan untuk menyalin teks ini.`;

    // tampilkan popup alert dengan teks yang bisa disalin
    await ctx.answerCbQuery(popupText, { show_alert: true });
  } catch (err) {
    console.error('Error callback cekid_user:', err.message);
    await ctx.answerCbQuery('⚠️ Terjadi kesalahan saat memeriksa ID.', { show_alert: true });
  }
  return;
}


// =============== PLAY AUDIO/VIDEO CALLBACK ===============
    if (data.startsWith('play_audio|') || data.startsWith('play_video|')) {
        const [action, videoUrl] = data.split('|');
        const isAudio = action === 'play_audio';

        if (!videoUrl) return ctx.answerCbQuery('❌ Link tidak valid!');
        await ctx.answerCbQuery(`⏳ Mengambil ${isAudio ? 'Audio' : 'Video'}...`);

        try {
            let mediaUrl, title, duration, qualityText, thumbnail;

            // ============================
            // 🎧 AUDIO — NEKOLABS
            // ============================
            if (isAudio) {
                const api = `https://api.nekolabs.web.id/downloader/youtube/v1?url=${encodeURIComponent(videoUrl)}&format=mp3`;
                const res = await fetch(api);
                const result = await res.json();

                if (!result?.success || !result?.result?.downloadUrl)
                    throw new Error('AUDIO_FAILED');

                const info = result.result;

                mediaUrl = info.downloadUrl.trim();
                title = info.title || 'Audio YouTube';
                duration = info.duration || 'N/A';
                qualityText = info.format || '128';
                thumbnail = info.cover || null;

                let thumbBuffer = null;
                if (thumbnail) {
                    try {
                        const tRes = await fetch(thumbnail);
                        if (tRes.ok) thumbBuffer = await tRes.buffer();
                    } catch {}
                }

                await ctx.replyWithAudio(
                    { url: mediaUrl },
                    {
                        caption:
`🎧 *${escapeMarkdown(title)}*
⏱️ Durasi: ${duration}
🎶 Format: MP3 ${qualityText}kbps
© ${escapeMarkdown(global.wm2)}`,
                        parse_mode: "MarkdownV2",
                        thumb: thumbBuffer ? { source: thumbBuffer } : undefined,
                        title,
                        performer: "YouTube"
                    }
                );

            } 
            // ============================
            // 🎥 VIDEO — ENGINE YTMP4 (d.ymcdn → backup → last)
            // ============================
            else {

                let downloadURL, sizeText;
                const link = videoUrl;

                const headers = {
                    "accept": "*/*",
                    "accept-language": "id-ID,id;q=0.9",
                    "user-agent": "Mozilla/5.0 (Linux; Android 13)",
                    "origin": "https://id.ytmp3.mobi",
                    "referer": "https://id.ytmp3.mobi/"
                };

                try {
                    // API UTAMA
                    const initRes = await fetch(`https://d.ymcdn.org/api/v1/init?p=y&_=${Date.now()}`, { headers });
                    const init = await initRes.json();

                    if (!init.convertURL) throw new Error("API utama gagal.");

                    const idMatch = link.match(/(?:v=|youtu\.be\/|embed\/)([^&?/]+)/);
                    if (!idMatch) throw new Error("Gagal membaca ID video.");
                    const vid = idMatch[1];

                    const convertURL = `${init.convertURL}&v=${vid}&f=mp4&_=${Math.random()}`;
                    const convertRes = await fetch(convertURL, { headers });
                    const convert = await convertRes.json();

                    if (!convert.progressURL) throw new Error("Gagal mulai konversi.");

                    let info = {};
                    for (let i = 0; i < 10; i++) {
                        await new Promise(r => setTimeout(r, 2000));
                        const p = await fetch(convert.progressURL, { headers });
                        info = await p.json();
                        if (info.progress === 3 && info.downloadURL) break;
                    }

                    downloadURL = info.downloadURL || convert.downloadURL;
                    if (!downloadURL) throw new Error("Tidak menemukan link download.");

                    title = info.title || convert.title || "Tanpa judul";
                    sizeText = convert.size || "Unknown";

                } catch (err1) {
                    console.log("⚠️ API Utama gagal:", err1.message);

                    try {
                        // BACKUP API
                        const backupRes = await fetch(`https://yt-api.my.id/api/ytmp4?url=${encodeURIComponent(link)}`);
                        const backup = await backupRes.json();

                        if (!backup.status) throw new Error("Backup gagal.");

                        title = backup.result.title;
                        downloadURL = backup.result.url;
                        sizeText = backup.result.size;

                    } catch (err2) {
                        console.log("⚠️ Backup gagal:", err2.message);

                        // LAST API
                        const last = await (await fetch(`https://api.ryzendesu.vip/api/downloader/ytmp4?url=${encodeURIComponent(link)}`)).json();

                        if (!last.status && !last.result?.url)
                            throw new Error("Semua API downloader gagal.");

                        title = last.result.title || "Tanpa Judul";
                        downloadURL = last.result.url;
                        sizeText = last.result.size || "Unknown";
                    }
                }

                await ctx.replyWithVideo(
                    { url: downloadURL },
                    {
                        caption:
`📹 *YouTube Video Download*

🎥 *Title:* ${escapeMD(title)}
💾 *Size:* ${sizeText}

© ${escapeMD(global.wm2)}`,
                        parse_mode: "Markdown",
                    }
                );
            }

            // ============================
            // UPDATE BUTTON → SUCCESS
            // ============================
            try {
                const kb = ctx.callbackQuery.message.reply_markup.inline_keyboard.map(row =>
                    row.map(btn =>
                        btn.callback_data?.startsWith(action + '|')
                            ? { text: `✅ ${isAudio ? 'Audio' : 'Video'} Berhasil`, callback_data: "audiodone" }
                            : btn
                    )
                );
                await ctx.editMessageReplyMarkup({ inline_keyboard: kb });
            } catch {}

        } catch (err) {
            console.log("Callback Error:", err);

            // tombol jadi gagal tapi tetap aktif
            try {
                const kb = ctx.callbackQuery.message.reply_markup.inline_keyboard.map(row =>
                    row.map(btn =>
                        btn.callback_data === data
                            ? { text: "❌ Gagal", callback_data: btn.callback_data }
                            : btn
                    )
                );
                await ctx.editMessageReplyMarkup({ inline_keyboard: kb });
            } catch {}
        }
        return;
    }

// ================= CALLBACK SEND /TOURL =================
if (data.startsWith('sendurl|')) {
  const urlToSend = data.split('|')[1];
  await ctx.reply(`🔗 URL: ${urlToSend}`);
  await ctx.answerCbQuery('✅ URL dikirim ke chat!');
  return;
}

    // =============== TIKTOK AUDIO ===============
    if (data.startsWith('ttaudio_exec ')) {
      const url = decodeURIComponent(data.split(' ')[1]);
      await ctx.answerCbQuery('🎧 Mengambil audio TikTok...');
      const fetch = (await import('node-fetch')).default;
      const apiUrl = `https://api.nekolabs.my.id/downloader/tiktok?url=${encodeURIComponent(url)}`;
      const res = await fetch(apiUrl);
      const result = await res.json();
      if (!result?.success || !result.result?.musicUrl) throw new Error('Audio tidak ditemukan dalam hasil API.');
      const info = result.result;
      await ctx.replyWithAudio(
        { url: info.musicUrl, filename: `${(info.title || 'Audio TikTok').replace(/[\\/:*?"<>|]/g, '')}.mp3` },
        {
          caption: `🎧 *Audio TikTok*\n🎶 Judul: ${info.title || 'Unknown'}\n👤 Artis: ${info.music_info?.author || info.author?.name || 'Unknown'}\n© ${global.wm2}`,
          parse_mode: 'Markdown'
        }
      );
      return;
    }


// =============== KEMBALI KE MENU ===============
if (data === 'menu_back') {
  try {
    const userId = ctx.from.id;
    const lang = getUserLang(userId);

    const inlineKeyboard = [
      [
        { text: '📥 Perintah', callback_data: 'menu_perintah' },
        { text: '💾 Download', callback_data: 'menu_download' }
      ],
      [
        { text: '☪️ Islamic', callback_data: 'menu_islamic' },
        { text: '🔍 Search', callback_data: 'menu_search' }
      ],
      [
        { text: '👑 Owner', callback_data: 'menu_owner' },
        { text: '🔞 NSFW', callback_data: 'menu_nsfw' }
      ],
      [
        { text: '⚔️ RPG', callback_data: 'menu_rpg' },
        { text: '🖼️ Anime', callback_data: 'menu_anime' }
      ],
      [
        { text: '📦 Other', callback_data: 'menu_other' },
        { text: '⚙️ Tools', callback_data: 'menu_tools' }
      ]
    ];

    // Buat snippet JavaScript seperti sebelumnya
    const jsSnippet = `// Info Bot
✨ ${global.i18n[lang].greeting} Saya ${global.botname2 || 'Bot'} Bot Telegram
${global.i18n[lang].help}

Fitur Aktif: ${global.featuredTotals || '0'}
© ${global.wm2 || ''}`;

    const caption = `\`\`\`${global.storename2}\n${jsSnippet}\n\`\`\``;

    await safeEdit(ctx, caption, {
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: inlineKeyboard }
    });
  } catch {
    await ctx.answerCbQuery('⚠️ Gagal kembali ke menu utama.', { show_alert: true });
  }
  return;
}
// =============== INFO & SETTINGS ===============
if (data === 'show_info') {
  try {
    const userId = ctx.from.id;
    const lang = getUserLang(userId);

    const botInfo = await Lyrra.telegram.getMe();

    const jsSnippet = `// Info Bot
🤖 ${global.i18n[lang].bot_label}: @${botInfo.username || 'Bot'}
💡 ${global.i18n[lang].made_by} @rbonlym
© ${global.wm2 || ''}`;

    const caption = `\`\`\`${global.storename2}\n${jsSnippet}\n\`\`\``;

    const inlineKeyboard = [
      [{ text: '⬅️ Kembali', callback_data: 'back_to_start' }]
    ];

    await safeEdit(ctx, caption, {
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: inlineKeyboard }
    });
  } catch {
    await ctx.answerCbQuery('⚠️ Gagal memuat info bot.', { show_alert: true });
  }
  return;
}


// ================= SETTINGS BUTTON =================
if (data === 'show_settings') {
  try {
    const userId = String(ctx.from.id);
    const user = global.db.data.users[userId];
    const currentLang = user?.bahasa || 'Indonesia';

    const settingsMenu = `
⚙️ <b>Pengaturan Bot</b>

🗣️ Bahasa saat ini: <code>${escapeHTML(currentLang)}</code>

Pilih menu di bawah untuk mengubah:
`;

    await safeEdit(ctx, settingsMenu, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🌐 Ganti Bahasa', callback_data: 'settings_lang' }],
          [{ text: '⬅️ Kembali', callback_data: 'back_to_start' }]
        ]
      }
    });
  } catch (err) {
    console.error('❌ Gagal menampilkan settings:', err);
    await ctx.answerCbQuery('⚠️ Gagal membuka pengaturan.', { show_alert: true });
  }
  return;
}

// ================= SETTINGS: GANTI BAHASA =================
if (data === 'settings_lang') {
  try {
    const langMenu = `
🌐 <b>Pilih Bahasa</b>

Silakan pilih bahasa yang ingin digunakan:
`;

    await safeEdit(ctx, langMenu, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🇮🇩 Indonesia', callback_data: 'set_lang_id' },
            { text: '🇲🇾 Melayu', callback_data: 'set_lang_my' }
          ],
          [
            { text: '🇺🇸 English', callback_data: 'set_lang_en' },
            { text: '🇯🇵 日本語', callback_data: 'set_lang_jp' }
          ],
          [
            { text: '🇨🇳 中文（简体）', callback_data: 'set_lang_cn' }
          ],
          [{ text: '⬅️ Kembali', callback_data: 'show_settings' }]
        ]
      }
    });
  } catch (err) {
    console.error('❌ Gagal menampilkan daftar bahasa:', err);
    await ctx.answerCbQuery('⚠️ Gagal memuat daftar bahasa.', { show_alert: true });
  }
  return;
}

// ================= SET BAHASA =================
const langMap = {
  set_lang_id: 'Indonesia',
  set_lang_my: 'Melayu',
  set_lang_en: 'English',
  set_lang_jp: '日本語',
  set_lang_cn: '中文'
};

if (Object.keys(langMap).includes(data)) {
  try {
    const chosenLang = langMap[data];
    const userId = String(ctx.from.id);

    if (!global.db.data.users[userId]) global.db.data.users[userId] = {};

    global.db.data.users[userId].bahasa = chosenLang;
    saveDatabase(global.db);

    const langSetText =
      global.i18n?.[chosenLang]?.lang_set || 'Bahasa berhasil diubah ke';

    await ctx.answerCbQuery(`✅ ${langSetText} ${chosenLang}`, { show_alert: true });

    await safeEdit(ctx,
      `✅ <b>${langSetText} ${chosenLang}</b>\n\nGunakan tombol di bawah untuk kembali.`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '⬅️ Kembali ke Settings', callback_data: 'show_settings' }],
            [{ text: '🏠 Menu Utama', callback_data: 'back_to_start' }]
          ]
        }
      }
    );
  } catch (err) {
    console.error('❌ Gagal menyimpan bahasa:', err);
    await ctx.answerCbQuery('⚠️ Gagal menyimpan bahasa.', { show_alert: true });
  }
  return;
}

// ================= BACK TO START =================
if (data === 'back_to_start') {
  try {
    const userId = ctx.from.id;
    const lang = getUserLang(userId);

    const jsSnippet = `// Info Bot
✨ ${global.i18n[lang].greeting} ${global.botname2 || 'Bot'} Bot Telegram
${global.i18n[lang].help}

© ${global.wm2 || ''}`;

    const caption = `\`\`\`${global.storename2}\n${jsSnippet}\n\`\`\``;

    const inlineKeyboard = [
      [
        { text: 'ℹ️ Info', callback_data: 'show_info' },
        { text: '⚙️ Settings', callback_data: 'show_settings' }
      ],
      [
        { text: '📋 Buka Menu', callback_data: 'menu_open' }
      ]
    ];

    await safeEdit(ctx, caption, {
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: inlineKeyboard }
    });
  } catch {
    await ctx.answerCbQuery('⚠️ Gagal kembali ke menu.', { show_alert: true });
  }
  return;
}


// =============== DUMMY CALLBACKS ===============
if (data === 'audiodone' || data === 'playdone') {
  return await ctx.answerCbQuery('✅ Berhasil.', { show_alert: false });
}



// =============== CALLBACK DEFAULT (TIDAK DIKENALI) ===============
      await ctx.answerCbQuery('⚠️ Perintah tidak dikenali.');
    } catch (err) {
      console.error('Callback error:', err);
      await ctx.reply('❌ Terjadi kesalahan saat memproses tombol.');
    }
  });

  // =============== WELCOME & GOODBYE ===============
  Lyrra.on('message', async (ctx) => {
    if (!ctx.message?.new_chat_members && !ctx.message.left_chat_member) return;
    const chatId = ctx.chat.id;
    const config = welcomeConfig[chatId] || {};

    const formatMention = (user) => {
      if (user.username) return `@${user.username}`;
      const safeName = (user.first_name || 'User').replace(/</g, "&lt;").replace(/>/g, "&gt;");
      return `<a href="tg://user?id=${user.id}">${safeName}</a>`;
    };

    try {
      if (ctx.message.new_chat_members && config.welcome) {
        const newUser = ctx.message.new_chat_members[0];
        const msg = (config.welcomeText || '👋 Halo {user}, selamat datang!')
          .replace(/{user}/g, formatMention(newUser));
        await ctx.reply(msg, { parse_mode: 'HTML' });
      }

      if (ctx.message.left_chat_member && config.goodbye) {
        const user = ctx.message.left_chat_member;
        const msg = (config.goodbyeText || '👋 Selamat tinggal {user}!')
          .replace(/{user}/g, formatMention(user));
        await ctx.reply(msg, { parse_mode: 'HTML' });
      }
    } catch (err) {
      console.error('Welcome/Goodbye Error:', err.message);
    }
  });
};