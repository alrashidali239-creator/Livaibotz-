const fs = require('fs')
const path = require('path')
const similarity = require('node-pretier')
const fetch = require('node-fetch');

const filePath = path.join(__dirname, '../Lyrra.js')

function getDetectedCommands() {
  const fileContent = fs.readFileSync(filePath, 'utf8')
  const commandMatches = fileContent.match(/case\s+['"`](.*?)['"`]/g) || []
  return commandMatches.map(match => match.replace(/case\s+['"`](.*?)['"`]/, '$1'))
}

function checkSimilarity(inputCommand, threshold = 0.6) {
  const commands = getDetectedCommands()
  let bestMatch = ''
  let highest = 0

  for (const cmd of commands) {
    const score = similarity(inputCommand.toLowerCase(), cmd.toLowerCase())
    if (score > highest) {
      highest = score
      bestMatch = cmd
    }
  }

  return highest >= threshold && inputCommand.toLowerCase() !== bestMatch.toLowerCase()
    ? { match: bestMatch, similarity: Math.round(highest * 100) }
    : null
}

const totalFitur = () => {
  const mytext = fs.readFileSync(filePath).toString()
  const regex = /case\s+['"`](.*?)['"`]\s*:/g
  const matches = [...mytext.matchAll(regex)]
  return matches.length
}

const PANEL_CONFIG = {
  '1gb': { memory: 1024, disk: 1024, cpu: 20 },
  '2gb': { memory: 2048, disk: 2048, cpu: 30 },
  '3gb': { memory: 3072, disk: 3072, cpu: 40 },
  '4gb': { memory: 4096, disk: 4096, cpu: 50 },
  '5gb': { memory: 5120, disk: 5120, cpu: 60 },
  '6gb': { memory: 6144, disk: 6144, cpu: 70 },
  '7gb': { memory: 7168, disk: 7168, cpu: 80 },
  '8gb': { memory: 8192, disk: 8192, cpu: 90 },
  '9gb': { memory: 9216, disk: 9216, cpu: 120 },
  '10gb': { memory: 10240, disk: 10240, cpu: 140 },
  'unli': { memory: 0, disk: 0, cpu: 0 }
};

function generateSecurePassword() {
  const length = 12;
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+';
  let pass = '';
  for (let i = 0; i < length; i++) {
    pass += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return pass;
}

async function createPanel(Lyrraa, size) {
  try {
    const resellerPath = path.join(__dirname, '..', 'database', 'reseller.json');
    if (!fs.existsSync(resellerPath)) fs.writeFileSync(resellerPath, '[]');
    const resellerList = JSON.parse(fs.readFileSync(resellerPath, 'utf8'));
    const sender = Lyrraa.from.id.toString();
    const { domain, apikey, eggs, locc, idAdmins } = global;

    if (!domain || !apikey) return Lyrraa.reply('❌ Konfigurasi panel tidak ditemukan.');

    let fixedDomain = domain;
    if (!fixedDomain.startsWith('http')) fixedDomain = 'https://' + fixedDomain;
    if (!fixedDomain.endsWith('/')) fixedDomain += '/';

    const isOwner = String(sender) === String(idAdmins);
    const isReseller = Array.isArray(resellerList) && resellerList.includes(sender);
    if (!isOwner && !isReseller) return Lyrraa.reply('❌ Fitur ini khusus reseller panel.');

    const username = Lyrraa.message.text.split(' ')[1];
    if (!username) return Lyrraa.reply(`📋 Contoh: /${size} username`);

    const config = PANEL_CONFIG[size];
    if (!config) return Lyrraa.reply('❌ Tipe panel tidak valid.');

    const email = `${username}@gmail.com`;
    const password = generateSecurePassword();
    const deskripsi = size === 'unli' ? `Panel Unli ${username}` : `Panel User ${username}`;

    await Lyrraa.reply(`_Sedang membuat server ${size.toUpperCase()}..._`);

    // === Buat User ===
    const userRes = await fetch(`${fixedDomain}api/application/users`, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apikey}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: 'en',
        password
      })
    });

    const userData = await userRes.json();
    if (userData.errors) return Lyrraa.reply('❌ Gagal membuat user panel.');
    const user = userData.attributes;

    // === Ambil Egg Startup ===
    const eggId = parseInt(eggs);
    const loc = parseInt(locc);
    const eggRes = await fetch(`${fixedDomain}api/application/nests/5/eggs/${eggId}`, {
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apikey}`
      }
    });
    const eggData = await eggRes.json();
    const startup_cmd = eggData?.attributes?.startup || 'npm start';

    // === Buat Server ===
    const serverRes = await fetch(`${fixedDomain}api/application/servers`, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apikey}`
      },
      body: JSON.stringify({
        name: username,
        description: deskripsi,
        user: user.id,
        egg: eggId,
        docker_image: 'ghcr.io/parkervcp/yolks:nodejs_18',
        startup: startup_cmd,
        environment: {
          INST: 'npm',
          USER_UPLOAD: '0',
          AUTO_UPDATE: '0',
          CMD_RUN: 'npm start',
          JS_FILE: './x-system/index.js'
        },
        limits: {
          memory: config.memory,
          swap: 0,
          disk: config.disk,
          io: 500,
          cpu: config.cpu
        },
        feature_limits: {
          databases: 0,
          backups: 0,
          allocations: 0
        },
        deploy: {
          locations: [loc],
          dedicated_ip: false,
          port_range: []
        }
      })
    });

    const serverData = await serverRes.json();
    if (serverData.errors) return Lyrraa.reply('❌ Gagal membuat server.');

    // === Format Pesan ===
    const ramDisplay = size === 'unli' ? 'Unlimited' : `${config.memory / 1024}GB`;
    const diskDisplay = size === 'unli' ? 'Unlimited' : `${config.disk}MB`;
    const cpuDisplay = size === 'unli' ? 'Unlimited' : `${config.cpu}%`;

    const info = `*🎉 PANEL ${size.toUpperCase()} BERHASIL DIBUAT!*
📧 Email: \`${email}\`
👤 Username: \`${username}\`
🔑 Password: \`${password}\`
💾 RAM: ${ramDisplay}
🧮 CPU: ${cpuDisplay}
📦 Disk: ${diskDisplay}
🌐 Panel: ${fixedDomain}`;

    if (Lyrraa.chat.type !== 'private') {
      await Lyrraa.telegram.sendMessage(sender, info, { parse_mode: 'Markdown' });
      Lyrraa.reply('✅ Data panel telah dikirim ke DM kamu!');
    } else {
      Lyrraa.reply(info, { parse_mode: 'Markdown' });
    }
  } catch (err) {
    console.error(`Error create ${size}:`, err);
    Lyrraa.reply(`❌ Terjadi kesalahan saat membuat panel ${size.toUpperCase()}.`);
  }
}

module.exports = { checkSimilarity, totalFitur, createPanel }

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)})