function escapeMarkdown(text = '') {
  return text.replace(/([_*[\]()~`>#+-=|{}.!\\])/g, '\\$1');
}

function codeBlock(language, code) {
  return `\`\`\`${language}\n${escapeMarkdown(code)}\n\`\`\``;
}

module.exports = { 
    codeBlock, 
    escapeMarkdown 
};