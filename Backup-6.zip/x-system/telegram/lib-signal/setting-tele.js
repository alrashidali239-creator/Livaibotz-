const fs = require('fs')


// Ini Settingan Telegram Bot

// ================= [ BOT PROFILE SETTINGS ] ================= //
global.storename2 = "LuccaneXz Store" // Store name
global.botname2 = "𝕷𝖎𝖛𝖆𝖎𝕭𝖔𝖙𝖟 人工知能" // Bot name
global.ownername2 = "@kyyyXz1" // Owner name
global.version2 = "2.3.2" // Version
global.wm2 = "Powered by - @kyyyXz1" // Watermark thumbnail

// ================= [ TELEGRAM SETTINGS ] ================= //

global.teleToken = "8542083554:AAHdZjxz64kPLgi0-LIbfN35J6V7jwNRfbY"
//Token tele, ambil di @BotFather (Telegram search)
global.idAdmins = "392836663"
// .cekid private bot mu untuk melihat ID username 
global.group = "https://t.me/livaibotz"
// url invite group telegram
global.idgroup = "-100000000"
// .cekid menggunakan bot didalam group
global.userLang = {}; // Simpan preferensi bahasa user berdasarkan ID(ga ush di delete)
 
global.domain = "https://panel.co.id" //domain panel petrodactyl
global.apikey = "ptla_abcd" //plta
global.capikey = "ptlc_abcd" //pltc
global.eggs = "15"
global.locc = "1"

global.messWait = "Tunggu sebentar..." // Please wait untuk message info telegram 

// ================== [ ID LINKS ] ================== //
global.stg2 = "https://t.me/@kyyyXz1"
global.syt2 = "https://youtube.com/"
global.sig2 = "https://instagram.com/rasaka_vibes"

// ================== [ MEDIA & REACTIONS ] ================== //
global.thumb22 = "https://files.catbox.moe/vh3dln.jpg" // Utama 
global.thumb33 = "https://files.catbox.moe/vh3dln.jpg"
global.audiofetch2 = "https://files.catbox.moe/fa9u0q.mp3" // Audio


// ================= [ AUTO RELOAD CONFIG ] ================= //
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`)
  delete require.cache[file]
  require(file)
})) => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`)
  delete require.cache[file]
  require(file)
})