require('../telegram/lib-signal/setting-tele');
const {
  Telegraf,
  Markup
} = require('telegraf');
const fetch = require('node-fetch');
const axios = require('axios');
const BOT_TOKEN = global.teleToken;
const fs = require('fs')
const chalk = require('chalk')
const cheerio = require("cheerio")
const path = require('path');
const pathDb = path.resolve(__dirname, 'database/database.json')
let settingPath = path.resolve(__dirname, 'config-setting.json')
let setting = JSON.parse(fs.readFileSync(settingPath));
const {
  checkSimilarity,
  totalFitur
} = require('../telegram/lib-signal/handler')
const teaturedtotals = totalFitur();

const lyreact = async (Lyrraa, emoji = messWait) => {
  await Lyrraa.reply(emoji, {
    reply_to_message_id: Lyrraa.message.message_id
  })
}

let rawDb = {};
try {
  rawDb = JSON.parse(fs.readFileSync(pathDb));
  rawDb.data = {
    users: {},
    rpg: {},
    others: {},
    settings: {},
    ...(rawDb.data || {})
  };
} catch (err) {
  console.error('Gagal memuat database. Coba hapus file dan jalankan ulang.');
  rawDb = {
    data: {
      users: {},
      rpg: {},
      others: {},
      settings: {}
    }
  };
}

function saveDatabase() {
  fs.writeFileSync(pathDb, JSON.stringify(db, null, 2));
}

function createAutoSaveProxy(obj) {
  return new Proxy(obj, {
    set(target, prop, value) {
      target[prop] = (typeof value === 'object' && value !== null) ?
        createAutoSaveProxy(value) :
        value;
      saveDatabase();
      return true;
    },
    deleteProperty(target, prop) {
      delete target[prop];
      saveDatabase();
      return true;
    },
    get(target, prop) {
      if (typeof target[prop] === 'object' && target[prop] !== null) {
        return createAutoSaveProxy(target[prop]);
      }
      return target[prop];
    }
  });
}
const db = createAutoSaveProxy(rawDb)

const CONFIG_TELE = {
  ADMIN_IDS: [idAdmins],
  ERROR_CHANNEL_ID: -1001234567890,
  COMMANDS: {
    START: 'start',
    HELP: 'help',
    INFO: 'info',
    SETTINGS: 'settings',
    STATS: 'stats'
  },
  MESSAGES: {
    WELCOME: `✨ Hallo! Saya ${botname2} bot Telegram canggih, Yang diciptakan oleh seorang jenius yang bernama ${ownername2}\nGunakan /help untuk melihat fitur yang tersedia.`,
    HELP: `📋 <b>Perintah yang tersedia:</b>
/start - Mulai bot
/help - Bantuan
/info - Informasi bot
/settings - Pengaturan


🌴 <b>List Menu</b>
/allmenu - Menampilkan All Menu
/menuperintah - Menampilkan Menu Perintah / help
/menudownload - Menampilkan Menu Download
/menuislamic - Menampung Menu Islam
/menusearch - Menampilkan Menu Search
/menuowner - Menampilkan Menu Owner
/menunsfw - Menampilkan Nsfw Menu
/menurpg - Menampilkan Rpg Menu
/menuanime - Menampilkan Anime Menu
/menuother - Menampilkan Other Menu

Feature Aktif : ${teaturedtotals}
©${botname2}`,
  },
  ERROR_MESSAGES: {
    DEFAULT: '⚠️ Terjadi kesalahan. Silakan coba lagi nanti.',
    ADMIN_ONLY: '⛔ Perintah ini hanya untuk admin!'
  }
};

const handlerlist = {
  perintah: [
    '/start',
    '/help',
    '/info',
    '/settings'
  ],
  download: [
    '/tiktok',
    '/instagram',
    '/mediafire',
    '/facebook',
    '/twitter',
    '/threads',
    '/capcut',
    '/spotify',
    '/gdrive',
    '/terabox',
    '/xvideodl',
    '/xnxxdl',
    '/pinterest',
    '/pastebin',
    '/lirik',
    '/ytmp3',
    '/ytmp4'
  ],
  islamic: [
    '/jadwalsholat',
    '/alquran',
    '/asmaulhusna',
    '/niatsholat',
    '/surah',
    '/berdoa',
    '/ayatkursi',
    '/gislam',
    '/kataislam',
    '/pantunislam'
  ],
  search: [
    '/play'
  ],
  owner: [],
  nsfw: [
    '/waifu',
    '/paptt',
    '/neko',
    '/shinobu',
    '/megumin',
    '/bully',
    '/cuddle',
    '/cry',
    '/hug',
    '/awoo',
    '/kiss',
    '/lick',
    '/pat',
    '/smug',
    '/bonk',
    '/yeet',
    '/blush',
    '/smile',
    '/wave',
    '/highfive',
    '/handhold',
    '/nom',
    '/bite',
    '/glomp',
    '/slap',
    '/kill',
    '/happy',
    '/wink',
    '/poke',
    '/dance',
    '/cringe',
    '/trap',
    '/blowjob',
    '/hentai',
    '/boobs',
    '/ass',
    '/pussy',
    '/thighs',
    '/lesbian',
    '/lewdneko',
    '/cum'
  ],
  rpg: [
    '/joinrpg',
    '/exitrpg',
    '/inventory'
  ],
  anime: [
    '/akiyama',
    '/ana',
    '/art',
    '/asuna',
    '/ayuzawa',
    '/boruto',
    '/bts',
    '/cartoon',
    '/chiho',
    '/chitoge',
    '/cosplay',
    '/cosplayloli',
    '/cosplaysagiri',
    '/cyber',
    '/deidara',
    '/doraemon',
    '/elaina',
    '/emilia',
    '/erza',
    '/exo',
    '/gamewallpaper',
    '/gremory',
    '/hacker',
    '/hestia',
    '/hinata',
    '/husbu',
    '/inori',
    '/islamic',
    '/isuzu',
    '/itachi',
    '/itori',
    '/jennie',
    '/jiso',
    '/justina',
    '/kaga',
    '/kagura',
    '/kakasih',
    '/kaori',
    '/keneki',
    '/kotori',
    '/kurumi',
    '/lisa',
    '/madara',
    '/megumin',
    '/mikasa',
    '/mikey',
    '/miku',
    '/minato',
    '/mountain',
    '/naruto',
    '/neko2',
    '/nekonime',
    '/nezuko',
    '/onepiece',
    '/pentol',
    '/pokemon',
    '/programming',
    '/randomnime',
    '/randomnime2',
    '/rize',
    '/rose',
    '/sagiri',
    '/sakura',
    '/sasuke',
    '/satanic',
    '/shina',
    '/shinka',
    '/shinomiya',
    '/shizuka',
    '/shota',
    '/shortquote',
    '/space',
    '/technology',
    '/tejina',
    '/toukachan',
    '/tsunade',
    '/yotsuba',
    '/yuki',
    '/yulibocil',
    '/yumeko'
  ],
  other: [
    '/daftar',
    '/sticker',
    '/totalfitur'
  ]
}

const startTelegramBot = () => {
try {
  console.log('Bot telegram berhasil tersambung..');
  if (!BOT_TOKEN) {
    console.error('Token Telegram kamu tidak valid / tidak ditemukan!');
    return;
  }

  const Lyrra = new Telegraf(BOT_TOKEN);

  Lyrra.use(async (Lyrraa, next) => {
    try {
      await next();
    } catch (err) {
      console.error('Bot error:', err);
      if (Lyrraa.reply) {
        await Lyrraa.reply(CONFIG_TELE.ERROR_MESSAGES.DEFAULT);
      }
      await Lyrra.telegram.sendMessage(
        CONFIG_TELE.ERROR_CHANNEL_ID,
        `🚨 <b>Error:</b>\n<code>${err.message}</code>`, {
          parse_mode: 'HTML'
        }
      );
    }
  });

  Lyrra.use((Lyrraa, next) => {
    Lyrraa.isAdmin = Lyrraa.from?.id && CONFIG_TELE.ADMIN_IDS.includes(Lyrraa.from.id);
    return next();
  });

  Lyrra.on('message', async (Lyrraa, next) => {
    const sender = Lyrraa.from.id.toString();
    if (!db.data.users[sender]) {
      db.data.users[sender] = {
        nama: Lyrraa.from.first_name,
        umur: 0,
        daftar: false,
        banned: false,
        Lyrra: false,
        rpg: false,
        saldo: 5000,
        limit: 200,
        exp: 3357
      };
    }
    next();
  })

  Lyrra.on('text', async (Lyrraa) => {
    const fullText = Lyrraa.message.text || '';
    const prefix = fullText.match(/^[°zZ#@+,.?=''():√%!¢£¥€π¤ΠΦ_&™©®Δ^βα¦|/\\©^]/)?.[0] || '.';
    const isCmd = fullText.startsWith(prefix);
    const command = isCmd ? fullText.slice(prefix.length).trim().split(' ')[0].toLowerCase() : '';
    const text = fullText.split(' ').slice(1).join(' ');
    const isAdmin = Lyrraa.isAdmin;
    const args = fullText.split(' ').slice(1)
    const sender = Lyrraa.from.id.toString()

    if (Lyrraa.message && Lyrraa.message.text && isCmd) {
      const user = Lyrraa.from;
      const time = new Date().toLocaleTimeString('id-ID', {
        hour12: false
      });
      const isGroup = !!Lyrraa.chat?.type?.includes('group');
      const senderName = user.first_name || 'Unknown';
      const args = fullText.split(' ').slice(1)

      const getDtckMsg = `
✧⋅──────⋅✦⋅──────⋅✧
│  ${chalk.bold.magenta('✧ TELEGRAM MESSAGE ✧')}
✧⋅──────⋅✦⋅──────⋅✧
│  ${chalk.cyan('⏳')} ${chalk.white('Time   :')} ${chalk.yellow(time)}
│  ${chalk.cyan('📩')} ${chalk.white('Chat   :')} ${chalk.green(isGroup ? 'Group 👥' : 'Private 🔒')}
│  ${chalk.cyan('👤')} ${chalk.white('Sender :')} ${chalk.hex('#FFA500')(senderName)}
│  ${chalk.cyan('✨')} ${chalk.white('Cmd    :')} ${chalk.redBright(command)}
✧⋅──────⋅✦⋅──────⋅✧`;

      console.log(getDtckMsg);
    }

    if (isCmd) {
      if (!["start", "info", "settings", "help", "stats"].includes(command)) {
        const similar = checkSimilarity(command)
        if (similar) {
          await Lyrraa.reply(`⚠️ *Command tidak ditemukan* Mungkin maksud kamu: /${similar.match} Kemiripan: ${similar.similarity}%`)
          return
        }
      }
    }

    if (isCmd) {
      if (db.data.users[sender].limit < 1) return Lyrraa.reply(`Limit kamu sudah habis`)
      db.data.users[sender].limit -= 1
    }

    switch (command) {
    case `${CONFIG_TELE.COMMANDS.START}`: {
      return Lyrraa.replyWithHTML(CONFIG_TELE.MESSAGES.WELCOME, Markup.inlineKeyboard([
        Markup.button.callback('ℹ️ Info', 'show_info'),
        Markup.button.callback('⚙️ Settings', 'show_settings')
      ]));
    }
    break

    case 'menu':
    case `${CONFIG_TELE.COMMANDS.HELP}`: {
      const caption = CONFIG_TELE.MESSAGES.HELP
      const maxLength = 1024
      const photo = {
        url: thumb22
      }

      if (caption.length <= maxLength) {
        return Lyrraa.replyWithPhoto(photo, {
          caption,
          parse_mode: 'HTML'
        })
      } else {
        await Lyrraa.replyWithPhoto(photo, {
          caption: caption.slice(0, maxLength),
          parse_mode: 'HTML'
        })

        return Lyrraa.reply(caption.slice(maxLength), {
          parse_mode: 'HTML'
        })
      }
    }
    break

    case 'menuall':
    case 'allmenu': {
      let text = '';
      Object.keys(handlerlist).forEach(key => {
        if (key === 'perintah') {
          text += `📋 ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'download') {
          text += `💾 ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'islamic') {
          text += `☪️ ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'search') {
          text += `🔍 ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'owner') {
          text += `👑 ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'nsfw') {
          text += `🔞 ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'rpg') {
          text += `⚔️ ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'anime') {
          text += `🖼️ ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        } else if (key === 'other') {
          text += `📥 ${key.charAt(0).toUpperCase() + key.slice(1)}\n`;
        }
        handlerlist[key].forEach(item => {
          text += `${item}\n`;
        });
        text += '\n';
      })
      Lyrraa.reply(text)
    }
    break

    case 'perintahmenu':
    case 'menuperintah': {
      let text = '📋 Perintah Menu\n';
      handlerlist.perintah.forEach(item => {
        text += `${item}\n`;
      });
      Lyrraa.reply(text);
    }
    break

    case 'downloadmenu':
    case 'menudownload': {
      let text = '💾 Download Menu\n';
      handlerlist.download.forEach(item => {
        text += `${item}\n`;
      });
      Lyrraa.reply(text);
    }
    break

    case 'islamicmenu':
    case 'menuislamic': {
      let text = '☪️ Islamic Menu\n';
      handlerlist.islamic.forEach(item => {
        text += `${item}\n`;
      });
      Lyrraa.reply(text);
    }
    break

    case 'searchmenu':
    case 'menusearch': {
      let text = '🔍 Search Menu\n';
      handlerlist.search.forEach(item => {
        text += `${item}\n`;
      });
      Lyrraa.reply(text);
    }
    break

    case 'ownermenu':
    case 'menuowner': {
      let text = '👑 Owner Menu\n';
      handlerlist.owner.forEach(item => {
        text += `${item}\n`;
      });
      Lyrraa.reply(text);
    }
    break

    case 'nsfwmenu':
    case 'menunsfw': {
      let text = '🔞 Nsfw Menu\n';
      handlerlist.nsfw.forEach(item => {
        text += `${item}\n`;
      });
      Lyrraa.reply(text);
    }
    break

    case 'rpgmenu':
    case 'menurpg': {
      let text = '⚔️ Rpg Menu\n';
      handlerlist.rpg.forEach(item => {
        text += `${item}\n`;
      });
      Lyrraa.reply(text);
    }
    break

    case 'animemenu':
    case 'menuanime': {
      let text = '🖼️ Anime Menu\n';
      handlerlist.anime.forEach(item => {
        text += `${item}\n`;
      });
      Lyrraa.reply(text);
    }
    break

    case 'othermenu':
    case 'menuother': {
      let text = '📥 Other Menu\n';
      handlerlist.other.forEach(item => {
        text += `${item}\n`;
      });
      Lyrraa.reply(text);
    }
    break

    case `${CONFIG_TELE.COMMANDS.INFO}`: {
      const botInfo = await Lyrra.telegram.getMe();
      return Lyrraa.replyWithHTML(`🤖 <b>Bot:</b> @${botInfo.username}`);
    }
    break

    case `${CONFIG_TELE.COMMANDS.STATS}`: {
      if (!isAdmin) return Lyrraa.reply(CONFIG_TELE.ERROR_MESSAGES.ADMIN_ONLY);
      return Lyrraa.reply(`📊 Total uptime: ${process.uptime().toFixed(1)}s`);
    }
    break

    case 'jadwalsholat': {
      if (!text) return Lyrraa.reply('Mau kota mana?')
      const kota = text.toLowerCase().replace(/\s+/g, '-')
      try {
        const {
          data
        } = await axios.get(`https://jadwal-sholat.tirto.id/kota-${kota}`)
        const $ = cheerio.load(data)
        const jadwalHariIni = $('tr.currDate td').map((i, el) => $(el).text()).get()

        const [tanggal, subuh, duha, dzuhur, ashar, maghrib, isya] = jadwalHariIni

        const jdwl = `
*JADWAL SHOLAT UNTUK HARI INI*
Tanggal: ${tanggal}
- Subuh: ${subuh}
- Dhuha: ${duha}
- Dzuhur: ${dzuhur}
- Ashar: ${ashar}
- Maghrib: ${maghrib}
- Isya: ${isya}
      `.trim()

        Lyrraa.reply(jdwl)
      } catch (err) {
        console.error(err)
        Lyrraa.reply('Terjadi kesalahan: ' + err.message)
      }
    }
    break

    case 'alquran': {
      if (!(args[0] && args[1])) {
        return Lyrraa.reply(`• *Contoh:* /alquran 1 2\nHasilnya adalah surah Al-Fatihah ayat 2`, {
          parse_mode: "Markdown"
        })
      }

      if (isNaN(args[0]) || isNaN(args[1])) {
        return Lyrraa.reply(`• *Contoh:* /alquran 1 2\nGunakan angka untuk surah dan ayat`, {
          parse_mode: "Markdown"
        })
      }

      try {
        const res = await fetch(`https://kalam.sindonews.com/ayat/${args[1]}/${args[0]}`)
        if (!res.ok) return Lyrraa.reply('Terjadi kesalahan saat mengambil data.')

        const html = await res.text()
        const $ = cheerio.load(html)
        const content = $('body > main > div > div.content.clearfix > div.news > section > div.list-content.clearfix')
        const Surah = $(content).find('div.ayat-title > h1').text()
        const arab = $(content).find('div.ayat-detail > div.ayat-arab').text()
        const latin = $(content).find('div.ayat-detail > div.ayat-latin').text()
        const terjemahan = $(content).find('div.ayat-detail > div.ayat-detail-text').text()

        let tafsir = ''
        $(content).find('div.ayat-detail > div.tafsir-box > div').each(function () {
          tafsir += $(this).text() + '\n'
        })
        tafsir = tafsir.trim()

        const hasil = `
${arab}
${latin}

${terjemahan}
${tafsir}

( ${Surah} )
`.trim()

        Lyrraa.reply(hasil)
      } catch (err) {
        console.error(err)
        Lyrraa.reply('Terjadi kesalahan: ' + err)
      }
    }
    break

    case 'asmaulhusna': {
      try {
        const res = await fetch('https://islamic-api-zhirrr.vercel.app/api/asmaulhusna');
        const data = await res.json();
        const ye = data.data;

        const tks = '*ASMAUL HUSNA*\n\n' + ye.map((item) => {
          return `Urutan: ${item.index}\nLatin: ${item.latin}\nArab: ${item.arabic}\nTerjemahan ID: ${item.translation_id}\nTerjemahan EN: ${item.translation_en}\n`;
        }).join('\n');

        await Lyrraa.reply(tks, {
          parse_mode: 'Markdown'
        });
      } catch (err) {
        console.error(err);
        await Lyrraa.reply('Error cuy, coba lagi ntar!');
      }
    }
    break

    case 'niatsholat': {
      const fullText = Lyrraa.message.text || '';
      const text = fullText.split(' ').slice(1).join(' ');

      try {
        const res = await fetch('https://islamic-api-zhirrr.vercel.app/api/niatshalat');
        const niatSholat = await res.json();

        if (!text) {
          let daftarNiat = '*DAFTAR NIAT SHOLAT*\n\n' + niatSholat.map((item) => `- ${item.name}`).join('\n');
          daftarNiat += `\n\nKetik *${Lyrraa.message.text.split(' ')[0]} [nama sholat]* untuk melihat niat\nContoh: *${Lyrraa.message.text.split(' ')[0]} subuh*`;
          await Lyrraa.reply(daftarNiat, {
            parse_mode: 'Markdown'
          });
        } else {
          const hasil = niatSholat.find((item) =>
            item.name.toLowerCase().includes(text.toLowerCase())
          );

          if (hasil) {
            const tks = `*${hasil.name.toUpperCase()}*\n\n` +
              `*Arab:* ${hasil.arabic}\n` +
              `*Latin:* ${hasil.latin}\n` +
              `*Terjemahan:* ${hasil.terjemahan}`;
            await Lyrraa.reply(tks, {
              parse_mode: 'Markdown'
            });
          } else {
            await Lyrraa.reply('Niat sholat yang kamu cari tidak ditemukan. Coba cek lagi nama sholatnya!');
          }
        }
      } catch (err) {
        console.error(err);
        await Lyrraa.reply('Error cuy, coba lagi ntar!');
      }
    }
    break

    case 'surah': {
      try {
        if (!text) {
          await Lyrraa.reply('Ketik nomor surahnya! Contoh: *.surah 1* buat ambil ayat-ayat dari Al-Fatihah')
          return
        }

        const res = await fetch(`https://api.siputzx.my.id/api/s/surah?no=${text}`)
        const json = await res.json()
        const data = json.data

        if (data && data.length > 0) {
          let surahText = data.map((ayat, index) =>
            `Ayat ${index + 1}:\n` +
            `Arab: ${ayat.arab}\n` +
            `Latin: ${ayat.latin}\n` +
            `Terjemahan: ${ayat.indo}\n`
          ).join('\n\n')

          await Lyrraa.reply(surahText)
        } else {
          await Lyrraa.reply('Gak ketemu, cek lagi nomor surahnya!')
        }
      } catch (err) {
        console.error(err)
        await Lyrraa.reply('Terjadi kesalahan: ' + err)
      }
    }
    break

    case 'kataislam': {
      async function AI(content) {
        try {
          const response = await axios.post('https://luminai.my.id/', {
            content,
            cName: "S-AI",
            cID: "S-AIbAQ0HcC"
          });

          return response.data
        } catch (error) {
          console.error(error)
          throw error
        }
      }

      let prompt = 'Berikan satu kata-kata atau quotes Islamic random yang sangat memotivasi, dan menginspirasi, jawab langsung ke intinya!'
      let hasil = await AI(prompt)
      Lyrraa.reply(hasil.result)
    }
    break

    case 'pantunislam': {
      async function AI(content) {
        try {
          const response = await axios.post('https://luminai.my.id/', {
            content,
            cName: "S-AI",
            cID: "S-AIbAQ0HcC"
          });

          return response.data
        } catch (error) {
          console.error(error)
          throw error
        }
      }

      let prompt = 'Berikan satu kata-kata pantun Islamic random yang sangat memotivasi, dan menginspirasi, jawab langsung ke intinya!'
      let hasil = await AI(prompt)
      Lyrraa.reply(hasil.result)
    }
    break

    case 'berdoa': {
      try {
        const res = await fetch('https://doa-doa-api-ahmadramadhan.fly.dev/api')
        const daftarDoa = await res.json()

        if (!text) {
          let listDoa = '*DAFTAR DOA*\n\n' + daftarDoa.map((item) => `- ${item.doa}`).join('\n')
          listDoa += '\n\nKetik *.doa [nama doa]* untuk melihat doa, contoh: *.doa doa sebelum tidur*'
          await Lyrraa.reply(listDoa)
        } else {
          let hasil = daftarDoa.find((item) =>
            item.doa.toLowerCase().includes(text.toLowerCase())
          )

          if (hasil) {
            let tks = `*${hasil.doa.toUpperCase()}*\n\n` +
              `Ayat: ${hasil.ayat}\n` +
              `Latin: ${hasil.latin}\n` +
              `Artinya: ${hasil.artinya}`
            await Lyrraa.reply(tks)
          } else {
            await Lyrraa.reply('Doa yang lu cari ga ketemu cuy. Cek lagi nama doanya!')
          }
        }
      } catch (err) {
        console.error(err)
        await Lyrraa.reply('Error cuy, coba lagi ntar!')
      }
    }
    break

    case 'gislam': {
      if (!text) return Lyrraa.reply('Mau cari tentang apa?')

      async function islam(query) {
        try {
          const response = await fetch(`https://artikel-islam.netlify.app/.netlify/functions/api/ms?page=1&s=${encodeURIComponent(query)}`)
          const json = await response.json()
          if (json.success) {
            const articles = json.data.data
            let message = `Total artikel: ${articles.length}\n\n`
            articles.forEach((article, index) => {
              message += `${index + 1}. Judul: ${article.title}\nURL: ${article.url}\n\n`
            })
            return message
          } else {
            return 'Gagal mengambil data'
          }
        } catch (error) {
          return 'Terjadi kesalahan saat mengambil data'
        }
      }

      let hasil = await islam(text)
      Lyrraa.reply(hasil)
    }
    break

    case 'ayatkursi': {
      try {
        const caption = `
*「 Ayat Kursi 」*

اللَّهُ لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ وَلَا يَئُودُهُ حِفْظُهُمَا وَهُوَ الْعَلِيُّ الْعَظِيمُ

“Alloohu laa ilaaha illaa huwal hayyul qoyyuum, laa ta’khudzuhuu sinatuw walaa naum. Lahuu maa fissamaawaati wa maa fil ardli man dzal ladzii yasyfa’u ‘indahuu illaa biidznih, ya’lamu maa baina aidiihim wamaa kholfahum wa laa yuhiithuuna bisyai’im min ‘ilmihii illaa bimaa syaa’ wasi’a kursiyyuhus samaawaati wal ardlo walaa ya’uuduhuu hifdhuhumaa wahuwal ‘aliyyul ‘adhiim.”

*Artinya:*
Allah, tidak ada Tuhan (yang berhak disembah) melainkan Dia Yang Hidup kekal lagi terus menerus mengurus (makhluk-Nya); tidak mengantuk dan tidak tidur. Kepunyaan-Nya apa yang di langit dan di bumi. Tiada yang dapat memberi syafa'at di sisi Allah tanpa izin-Nya.
Allah mengetahui apa-apa yang di hadapan mereka dan di belakang mereka, dan mereka tidak mengetahui apa-apa dari ilmu Allah melainkan apa yang dikehendaki-Nya. Kursi Allah meliputi langit dan bumi. Dan Allah tidak merasa berat memelihara keduanya, dan Allah Maha Tinggi lagi Maha Besar." 
(QS. Al Baqarah: 255)`

        await Lyrraa.reply(caption)

      } catch (err) {
        console.error(err)
        await Lyrraa.reply('Gagal mengirim ayat kursi. Coba lagi nanti.')
      }
    }
    break

    case 'regristasi':
    case 'daftar': {
      if (db.data.users[sender].daftar) return Lyrraa.reply('Kamu sudah terdaftar')
      const args = Lyrraa.message.text.split(' ');

      if (args.length < 3) return Lyrraa.reply('Format salah!\nGunakan: /daftar Nama Umur');

      const nama = args[1];
      const umur = parseInt(args[2]);
      if (isNaN(umur)) return Lyrraa.reply('Umur harus berupa angka!');

      db.data.users[sender].nama = nama
      db.data.users[sender].umur = umur
      db.data.users[sender].daftar = true
      Lyrraa.reply(`Berhasil mendaftar!\nNama: ${nama}\nUmur: ${umur}`);
    }
    break

    case 's':
    case 'stiker':
    case 'sticker': {
      const message = Lyrraa.message;
      const reply = message.reply_to_message;

      if (!reply || (!reply.photo && !reply.video)) {
        return Lyrraa.reply('Balas gambar atau video (≤10 detik) dengan perintah *sticker*');
      }

      try {
        if (reply.photo) {
          const file = reply.photo[reply.photo.length - 1].file_id;
          const fileLink = await Lyrraa.telegram.getFileLink(file);
          await Lyrraa.replyWithSticker({
            url: fileLink.href
          });
        } else if (reply.video) {
          const file = reply.video.file_id;
          if (reply.video.duration > 10) return Lyrraa.reply('Videonya maksimal 10 detik ya!');
          const fileLink = await Lyrraa.telegram.getFileLink(file);
          await Lyrraa.replyWithSticker({
            url: fileLink.href
          });
        }
      } catch (err) {
        console.error(err);
        Lyrraa.reply('Gagal membuat stiker!');
      }
    }
    break

    case 'ttf':
    case 'totalfeature':
    case 'totalfitur': {
      const jumlah = totalFitur();
      Lyrraa.reply(`Total fitur aktif di bot ini: *${jumlah}*`, {
        parse_mode: 'Markdown'
      });
    }
    break

    case 'waifu':
    case 'neko':
    case 'shinobu':
    case 'megumin':
    case 'bully':
    case 'cuddle':
    case 'cry':
    case 'hug':
    case 'awoo':
    case 'kiss':
    case 'lick':
    case 'pat':
    case 'smug':
    case 'bonk':
    case 'yeet':
    case 'blush':
    case 'smile':
    case 'wave':
    case 'highfive':
    case 'handhold':
    case 'nom':
    case 'bite':
    case 'glomp':
    case 'slap':
    case 'kill':
    case 'happy':
    case 'wink':
    case 'poke':
    case 'dance':
    case 'cringe':
    case 'trap':
    case 'blowjob':
    case 'hentai':
    case 'boobs':
    case 'ass':
    case 'pussy':
    case 'thighs':
    case 'lesbian':
    case 'lewdneko':
    case 'cum': {
      if (!Lyrraa.chat?.type?.includes('private')) return Lyrraa.reply('Fitur ini hanya bisa digunakan di chat pribadi!');

      try {
        let res = await fetch(`https://rule34.xxx/index.php?page=dapi&s=post&q=index&tags=${command}&json=1`)
        let data = await res.json()
        if (data && data[0]?.file_url) {
          return Lyrraa.replyWithPhoto({
            url: data[0].file_url
          }, {
            caption: global.wm2
          })
        }
      } catch (err1) {
        try {
          let res2 = await fetch(`https://api.waifu.pics/nsfw/${command}`)
          let data2 = await res2.json()
          if (data2.url) {
            return Lyrraa.replyWithPhoto({
              url: data2.url
            }, {
              caption: global.wm2
            })
          }
        } catch (err2) {
          try {
            let res3 = await fetch(`https://api.waifu.pics/sfw/${command}`)
            let data3 = await res3.json()
            if (data3.url) {
              return Lyrraa.replyWithPhoto({
                url: data3.url
              }, {
                caption: global.wm2
              })
            }
          } catch (err3) {
            Lyrraa.reply('Gagal mengambil gambar. Coba lagi nanti.')
          }
        }
      }
    }
    break

    case 'paptt':
    case 'pap-tt':
    case 'bokeptt': {
      global.paptt = [
        "https://telegra.ph/file/5c62d66881100db561c9f.mp4",
        "https://telegra.ph/file/a5730f376956d82f9689c.jpg",
        "https://telegra.ph/file/8fb304f891b9827fa88a5.jpg",
        "https://telegra.ph/file/0c8d173a9cb44fe54f3d3.mp4",
        "https://telegra.ph/file/b58a5b8177521565c503b.mp4",
        "https://telegra.ph/file/34d9348cd0b420eca47e5.jpg",
        "https://telegra.ph/file/73c0fecd276c19560133e.jpg",
        "https://telegra.ph/file/af029472c3fcf859fd281.jpg",
        "https://telegra.ph/file/0e5be819fa70516f63766.jpg",
        "https://telegra.ph/file/29146a2c1a9836c01f5a3.jpg",
        "https://telegra.ph/file/85883c0024081ffb551b8.jpg",
        "https://telegra.ph/file/d8b79ac5e98796efd9d7d.jpg",
        "https://telegra.ph/file/267744a1a8c897b1636b9.jpg",
      ];

      // Pilih acak
      let url = global.paptt[Math.floor(Math.random() * global.paptt.length)];

      if (url.endsWith('.mp4')) {
        await Lyrraa.replyWithVideo({
          url
        }, {
          caption: 'Tch, sangean🤧'
        });
      } else {
        await Lyrraa.replyWithPhoto({
          url
        }, {
          caption: 'Tch, sangean🤧'
        });
      }
    }
    break

    // TikTok Downloader
    case 'tiktok':
    case 'tt':
    case 'ttdl': {
      if (!text) return Lyrraa.reply('Contoh: /tiktok https://www.tiktok.com/...');
      if (!text.includes('tiktok.com')) return Lyrraa.reply('Harus berupa link TikTok!');
      await lyreact(Lyrraa)
      try {
        const res = await fetch(`https://vapis.my.id/api/ttdl?url=${text}`);
        const jir = await res.json();

        if (jir.status && jir.data) {
          const nowmVideo = jir.data.data.find(item => item.type === 'nowatermark');
          if (nowmVideo) {
            return await Lyrraa.replyWithVideo({
              url: nowmVideo.url
            }, {
              caption: `© ${wm2}`,
              reply_markup: {
                inline_keyboard: [
                  [{
                    text: '🎵 Audio Music',
                    callback_data: `tt_audio ${text}`
                  }]
                ]
              }
            });
          }
        }

        throw new Error('Gagal ambil dari API pertama');
      } catch (err1) {
        try {
          const res2 = await fetch(`https://api.vreden.web.id/api/tiktok?url=${text}`);
          const anu = await res2.json();
          const result = anu.result.data;

          for (let i = 0; i < result.length; i++) {
            const item = result[i];
            if (item.type === 'nowatermark') {
              return await Lyrraa.replyWithVideo({
                url: item.url
              }, {
                caption: `© ${wm2}`,
                reply_markup: {
                  inline_keyboard: [
                    [{
                      text: '🎵 Audio Music',
                      callback_data: `tt_audio ${text}`
                    }]
                  ]
                }
              });
            }
            if (item.type === 'photo') {
              await Lyrraa.replyWithPhoto({
                url: item.url
              });
            }
          }
        } catch (err2) {
          console.error('API kedua gagal:', err2.message);
          return Lyrraa.reply('Terjadi kesalahan saat memproses link TikTok.');
        }
      }
    }
    break;

    // Instagram Downloader
    case 'igdl':
    case 'instagram': {
      if (!text) return Lyrraa.reply('Contoh: /igdl https://www.instagram.com/...');
      if (!text.includes('instagram.com')) return Lyrraa.reply('Harus berupa link Instagram!');
      await lyreact(Lyrraa)
      try {
        const res = await fetch(`https://vapis.my.id/api/igdl?url=${encodeURIComponent(text)}`);
        const jor = await res.json();

        if (jor.data && jor.data[0]?.url?.includes('.mp4')) {
          return await Lyrraa.replyWithVideo({
            url: jor.data[0].url
          }, {
            caption: `© ${wm2}`
          });
        } else {
          return await Lyrraa.replyWithPhoto({
            url: jor.data[0].url
          }, {
            caption: `© ${wm2}`
          });
        }
      } catch (err) {
        console.error('Kesalahan saat ambil media IG:', err.message);
        return Lyrraa.reply('Terjadi kesalahan saat mengambil media Instagram.');
      }
    }
    break;

    // MediaFire Downloader
    case 'mediafiredown':
    case 'mfdown':
    case 'mf':
    case 'mediafire':
    case 'mfdl': {
      try {
        if (!text) return Lyrraa.reply(`Contoh: /mfdown linknya`);
        if (!text.includes('mediafire.com')) return Lyrraa.reply('Harus berupa link mediafire!');
        await lyreact(Lyrraa)
        let api = await fetch(`https://api.vreden.web.id/api/mediafiredl?url=${text}`);
        let data = await api.json();
        data = data.result?.[0];

        if (!data || !data.link) {
          return Lyrraa.reply('Gagal mendapatkan link download dari MediaFire.');
        }

        let fileNama = decodeURIComponent(data.nama || 'file.zip');
        let extension = fileNama.split('.').pop().toLowerCase();

        let mimetype = '';
        if (extension === 'mp4') mimetype = 'video/mp4';
        else if (extension === 'mp3') mimetype = 'audio/mp3';
        else mimetype = `application/${extension}`;

        await Lyrraa.replyWithDocument({
          url: data.link
        }, {
          filename: fileNama,
          caption: `© ${wm2}`
        });
      } catch (err) {
        console.error('MediaFire error:', err);
        Lyrraa.reply('Terjadi kesalahan: ' + err.message);
      }
    }
    break;

    // Yt Downloader   

    case 'ytplay':
    case 'play': {
      const {
        ytdlv2
      } = require('very-zeld');
      const ytdl = require('youku-search');
      const query = args.join(' ');

      if (!query) {
        return Lyrraa.reply(`Masukkan judul lagu!\n\nContoh:\n${command} My Little Dark Age`);
      }

      await lyreact(Lyrraa);

      try {
        const search = await ytdl.search(query);
        const video = search.results.find(v => v.type === 'video');
        if (!video) return Lyrraa.reply('Video tidak ditemukan.');

        const {
          title,
          url,
          thumbnail,
          timestamp,
          ago
        } = video;
        const imageBuffer = (await axios.get(thumbnail, {
          responseType: 'arraybuffer'
        })).data;
        await Lyrraa.replyWithPhoto({
          source: Buffer.from(imageBuffer)
        }, {
          caption: `*${title}*\n\nDurasi: ${timestamp}\nUpload: ${ago}\nLink: ${url}\n\nPlease wait sending audio..`,
          parse_mode: 'Markdown'
        });

        const quality = 128;
        const result = await ytdlv2(url, 'mp3', quality);
        if (!result.download) return Lyrraa.reply('Gagal mengambil audio.');

        await Lyrraa.replyWithAudio({
          source: fs.createReadStream(result.download)
        }, {
          caption: `Judul: ${result.file_name}\nUkuran: ${result.file_size}`
        });

        fs.unlinkSync(result.download);
      } catch (err) {
        console.error(err);
        Lyrraa.reply('Terjadi kesalahan saat mengunduh atau mengirim audio.');
      }
    }
    break

    case 'ytmp3':
    case 'yta':
    case 'ytaudio': {
      const text = Lyrraa.message.text || ''
      const args = text.split(' ').slice(1)
      const link = args[0]
      const quality = args[1] ? args[1] : 128

      if (!link) {
        return Lyrraa.reply(`Contoh: ${command} https://youtu.be/xxxx 128\nKualitas default: 128kbps`)
      }
      await lyreact(Lyrraa)
      try {
        const {
          ytdlv2
        } = require('@leoo-vanth/zarv-vz')
        const result = await ytdlv2(link, 'mp3', quality)

        if (!result.download) {
          return Lyrraa.reply('Gagal mengambil audio.')
        }

        await Lyrraa.replyWithAudio({
          source: fs.createReadStream(result.download)
        }, {
          caption: `Judul: ${result.file_name}\nUkuran: ${result.file_size}`,
        })

        fs.unlinkSync(result.download)
      } catch (err) {
        console.error(err)
        Lyrraa.reply('Terjadi kesalahan saat mengunduh audio.')
      }
    }
    break

    case 'ytmp4':
    case 'ytv':
    case 'ytvideo': {
      const text = Lyrraa.message.text || ''
      const args = text.split(' ').slice(1)
      const link = args[0]
      const quality = args[1] ? args[1] : 480

      if (!link) {
        return Lyrraa.reply(`Contoh: ${command} https://youtu.be/xxxx 480\nKualitas default: 480`)
      }
      await lyreact(Lyrraa)
      try {
        const {
          ytdlv2
        } = require('@leoo-vanth/zarv-vz')
        const result = await ytdlv2(link, 'mp4', quality)

        if (!result.download) {
          return Lyrraa.reply('Gagal mengambil video.')
        }

        await Lyrraa.replyWithVideo({
          source: fs.createReadStream(result.download)
        }, {
          caption: `Judul: ${result.file_name}\nUkuran: ${result.file_size}`,
        })

        fs.unlinkSync(result.download)
      } catch (err) {
        console.error(err)
        Lyrraa.reply('Terjadi kesalahan saat mengunduh video.')
      }
    }
    break

    // Facebook Downloader
    case 'fb':
    case 'fbdl':
    case 'facebook': {
      try {
        if (!text) return Lyrraa.reply(`Contoh: /fbdl linknya`);
        if (!text.includes('facebook.com')) return Lyrraa.reply('Harus berupa link facebook!');
        await lyreact(Lyrraa)
        let jor = await fetch(`https://api.agatz.xyz/api/facebook?url=${encodeURIComponent(text)}`);
        jor = await jor.json();

        await Lyrraa.replyWithVideo({
          url: jor.data.sd
        }, {
          caption: `© ${wm2}`
        });
      } catch (err) {
        console.error('Facebook error:', err);
        Lyrraa.reply('Terjadi kesalahan: ' + err.message);
      }
    }
    break;

    // Twitter Downloader
    case 'twdl':
    case 'twitter': {
      try {
        if (!text) return Lyrraa.reply(`Contoh: /twdl linknya`);
        await lyreact(Lyrraa)

        const response = await fetch(`https://api.agatz.xyz/api/twitter?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        const videoUrl = data.data.video_sd || data.data.video_hd || data.data.audio;

        await Lyrraa.replyWithVideo({
          url: videoUrl
        }, {
          caption: `© ${wm2}`,
        });
      } catch (err) {
        Lyrraa.reply(`Terjadi kesalahan: ${err.message}`);
      }
    }
    break;

    // Threads Downloader
    case 'thdl':
    case 'threads': {
      try {
        if (!text) return Lyrraa.reply(`Contoh: /thdl linknya`);
        if (!text.includes('threads.net')) return Lyrraa.reply('Harus berupa link threads!');
        await lyreact(Lyrraa)
        const response = await fetch(`https://api.vreden.web.id/api/threads?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.result && data.result.video) {
          await Lyrraa.replyWithVideo({
            url: data.result.video
          }, {
            caption: `© ${wm2}`
          });
        } else {
          Lyrraa.reply('Tidak dapat menemukan video dari link tersebut.');
        }
      } catch (err) {
        Lyrraa.reply(`Terjadi kesalahan: ${err.message}`);
      }
    }
    break;

    // CapCut Downloader
    case 'ccdl':
    case 'capcut': {
      try {
        if (!text) return Lyrraa.reply(`Contoh: /capcut linknya`);
        if (!text.includes('capcut.com') && !text.includes('capcut.net'))
          return Lyrraa.reply('Harus berupa link capcut!');
        await lyreact(Lyrraa)
        const response = await fetch(`https://api.vreden.web.id/api/capcut?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.result && data.result.video) {
          await Lyrraa.replyWithVideo({
            url: data.result.video
          }, {
            caption: `© ${wm2}`
          });
        } else {
          Lyrraa.reply('Tidak dapat menemukan video dari link tersebut.');
        }
      } catch (err) {
        console.error(err);
        Lyrraa.reply('Terjadi kesalahan');
      }
    }
    break;

    // Spotify Downloader
    case 'spotify':
    case 'spotifydl': {
      if (!text) return Lyrraa.reply(`Contoh: /spotify linknya`);
      if (!text.includes('spotify.com') && !text.includes('open.spotify'))
        return Lyrraa.reply('Harus berupa link Spotify!');
      await lyreact(Lyrraa)
      try {
        const response = await fetch(`https://api.vreden.web.id/api/spotify?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.result && data.result.audio) {
          await Lyrraa.replyWithAudio({
            url: data.result.audio
          }, {
            title: data.result.title || 'Spotify Audio',
            performer: data.result.artist || 'Unknown Artist',
            caption: `© ${wm2}`
          });
        } else {
          Lyrraa.reply('Tidak dapat menemukan audio dari link tersebut.');
        }
      } catch (err) {
        Lyrraa.reply('Terjadi kesalahan: ' + err.message);
      }
    }
    break;

    // Google Drive Downloader
    case 'gddl':
    case 'gdrive': {
      try {
        if (!text) return Lyrraa.reply(`Contoh: /gdrive linknya`);
        await lyreact(Lyrraa)
        const response = await fetch(`https://api.siputzx.my.id/api/d/gdrive?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.data && data.data.download) {
          await Lyrraa.replyWithDocument({
            url: data.data.download
          }, {
            filename: data.data.name || 'gdrive_download.zip',
            caption: `© ${wm2}`
          });
        } else {
          Lyrraa.reply('Tidak dapat mengunduh file dari Google Drive.');
        }
      } catch (err) {
        console.error('Google Drive error:', err);
        Lyrraa.reply('Terjadi kesalahan');
      }
    }
    break;

    // Terabox Downloader
    case 'terabox': {
      try {
        if (!text) return Lyrraa.reply(`Contoh: /terabox linknya`);
        await lyreact(Lyrraa)
        const response = await fetch(`https://api.vreden.web.id/api/terabox?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.result && data.result.download) {
          await Lyrraa.replyWithDocument({
            url: data.result.download
          }, {
            filename: data.result.file_name || 'terabox_download.zip',
            caption: `© ${wm2}`
          });
        } else {
          Lyrraa.reply('Tidak dapat mengunduh file dari Terabox.');
        }
      } catch (err) {
        Lyrraa.reply('Terjadi kesalahan: ' + err.message);
      }
    }
    break;

    // XVideos Downloader
    case 'xvideodl':
    case 'xvidl': {
      if (!text) return Lyrraa.reply(`Contoh: /xvideodl linknya`);
      await lyreact(Lyrraa)
      try {
        let res = await fetch(`https://api.agatz.xyz/api/xvideodown?url=${encodeURIComponent(text)}`);
        let data = await res.json();

        if (data.data && data.data.url) {
          await Lyrraa.replyWithVideo({
            url: data.data.url
          }, {
            caption: `*XVideos Download*\n\nJudul: ${data.data.title || '-'}\n© ${wm2}`
          });
        } else {
          Lyrraa.reply('Tidak dapat mengunduh video dari XVideos.');
        }
      } catch (err) {
        console.error(err);
        Lyrraa.reply('Terjadi kesalahan');
      }
    }
    break;

    // XNXX Downloader
    case 'xnxxdl':
    case 'xnxdl': {
      if (!text) return Lyrraa.reply(`Contoh: /xnxxdl linknya`);
      await lyreact(Lyrraa)
      try {
        let res = await fetch(`https://api.agatz.xyz/api/xnxxdown?url=${encodeURIComponent(text)}`);
        let data = await res.json();

        if (data.data && data.data.files && data.data.files.low) {
          await Lyrraa.replyWithVideo({
            url: data.data.files.low
          }, {
            caption: `*XNXX Download*\n\nJudul: ${data.data.title || '-'}\nDurasi: ${data.data.duration || '-'}\n© ${wm2}`
          });
        } else {
          Lyrraa.reply('Tidak dapat mengunduh video dari XNXX.');
        }
      } catch (err) {
        console.error(err);
        Lyrraa.reply('Terjadi kesalahan');
      }
    }
    break;

    // Pinterest Downloader
    case 'pindl':
    case 'pinterest': {
      if (!text) return Lyrraa.reply(`Contoh: /pinterest linknya`);
      await lyreact(Lyrraa)
      try {
        const response = await fetch(`https://api.vreden.web.id/api/pinterest?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.result && data.result.image) {
          await Lyrraa.replyWithPhoto({
            url: data.result.image
          }, {
            caption: `*Pinterest Download*\n\nJudul: ${data.result.title || '-'}\n© ${wm2}`
          });
        } else {
          Lyrraa.reply('Tidak dapat mengunduh gambar dari Pinterest.');
        }
      } catch (err) {
        Lyrraa.reply('Terjadi kesalahan: ' + err.message);
      }
    }
    break;

    // Pastebin Getter
    case 'pastebin': {
      if (!text) return Lyrraa.reply(`Contoh: /pastebin linknya`);
      await lyreact(Lyrraa)
      try {
        const response = await fetch(`https://vapis.my.id/api/pastebin?url=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.data) {
          // Send as document if content is long
          if (data.data.length > 1000) {
            await Lyrraa.replyWithDocument({
              source: Buffer.from(data.data),
              filename: 'pastebin_content.txt'
            }, {
              caption: `© ${wm2}`
            });
          } else {
            await Lyrraa.reply(`Pastebin Content:\n\n${data.data}`);
          }
        } else {
          Lyrraa.reply('Tidak dapat mengambil konten dari Pastebin.');
        }
      } catch (err) {
        Lyrraa.reply('Terjadi kesalahan: ' + err.message);
      }
    }
    break;

    // Lyrics Getter
    case 'lirikget':
    case 'getlirik':
    case 'lirik': {
      if (!text) return Lyrraa.reply(`Contoh: /lirik judul_lagu`);
      await lyreact(Lyrraa)
      try {
        const response = await fetch(`https://api.vreden.web.id/api/lirik?query=${encodeURIComponent(text)}`);
        const data = await response.json();

        if (data.result) {
          let lyricsText = `*Lirik Lagu:* ${data.result.title || '-'}\n\n`;
          lyricsText += data.result.lyrics || 'Lirik tidak ditemukan';

          await Lyrraa.reply(lyricsText);
        } else {
          Lyrraa.reply('Lirik tidak ditemukan.');
        }
      } catch (err) {
        Lyrraa.reply('Terjadi kesalahan: ' + err.message);
      }
    }
    break;

    case 'akiyama':
    case 'ana':
    case 'art':
    case 'asuna':
    case 'ayuzawa':
    case 'boruto':
    case 'bts':
    case 'cartoon':
    case 'chiho':
    case 'chitoge':
    case 'cosplay':
    case 'cosplayloli':
    case 'cosplaysagiri':
    case 'cyber':
    case 'deidara':
    case 'doraemon':
    case 'elaina':
    case 'emilia':
    case 'erza':
    case 'exo':
    case 'gamewallpaper':
    case 'gremory':
    case 'hacker':
    case 'hestia':
    case 'hinata':
    case 'husbu':
    case 'inori':
    case 'islamic':
    case 'isuzu':
    case 'itachi':
    case 'itori':
    case 'jennie':
    case 'jiso':
    case 'justina':
    case 'kaga':
    case 'kagura':
    case 'kakasih':
    case 'kaori':
    case 'keneki':
    case 'kotori':
    case 'kurumi':
    case 'lisa':
    case 'madara':
    case 'megumin':
    case 'mikasa':
    case 'mikey':
    case 'miku':
    case 'minato':
    case 'mountain':
    case 'naruto':
    case 'neko2':
    case 'nekonime':
    case 'nezuko':
    case 'onepiece':
    case 'pentol':
    case 'pokemon':
    case 'programming':
    case 'randomnime':
    case 'randomnime2':
    case 'rize':
    case 'rose':
    case 'sagiri':
    case 'sakura':
    case 'sasuke':
    case 'satanic':
    case 'shina':
    case 'shinka':
    case 'shinomiya':
    case 'shizuka':
    case 'shota':
    case 'shortquote':
    case 'space':
    case 'technology':
    case 'tejina':
    case 'toukachan':
    case 'tsunade':
    case 'yotsuba':
    case 'yuki':
    case 'yulibocil':
    case 'yumeko': {
      const keyword = command.replace('/', '')
      const mapKategori = {
        akiyama: 'akiyama',
        ana: 'ana',
        art: 'art',
        asuna: 'asuna',
        ayuzawa: 'ayuzawa',
        boruto: 'boruto',
        bts: 'bts',
        cartoon: 'kartun',
        chiho: 'chiho',
        chitoge: 'chitoge',
        cosplay: 'cosplay',
        cosplayloli: 'cosplayloli',
        cosplaysagiri: 'cosplaysagiri',
        cyber: 'cyber',
        deidara: 'deidara',
        doraemon: 'doraemon',
        elaina: 'elaina',
        emilia: 'emilia',
        erza: 'erza',
        exo: 'exo',
        gamewallpaper: 'gamewallpaper',
        gremory: 'gremory',
        hacker: 'hekel',
        hestia: 'hestia',
        hinata: 'hinata',
        husbu: 'husbu',
        inori: 'inori',
        islamic: 'islamic',
        isuzu: 'isuzu',
        itachi: 'itachi',
        itori: 'itori',
        jennie: 'jeni',
        jiso: 'jiso',
        justina: 'justina',
        kaga: 'kaga',
        kagura: 'kagura',
        kakasih: 'kakasih',
        kaori: 'kaori',
        keneki: 'keneki',
        kotori: 'kotori',
        kurumi: 'kurumi',
        lisa: 'lisa',
        madara: 'madara',
        megumin: 'megumin',
        mikasa: 'mikasa',
        mikey: 'mikey',
        miku: 'miku',
        minato: 'minato',
        mountain: 'mountain',
        naruto: 'naruto',
        neko2: 'neko2',
        nekonime: 'nekonime',
        nezuko: 'nezuko',
        onepiece: 'onepiece',
        pentol: 'pentol',
        pokemon: 'pokemon',
        programming: 'programming',
        randomnime: 'randomnime',
        randomnime2: 'randomnime2',
        rize: 'rize',
        rose: 'rose',
        sagiri: 'sagiri',
        sakura: 'sakura',
        sasuke: 'sasuke',
        satanic: 'satanic',
        shina: 'shina',
        shinka: 'shinka',
        shinomiya: 'shinomiya',
        shizuka: 'shizuka',
        shota: 'shota',
        shortquote: 'katakata',
        space: 'tatasurya',
        technology: 'technology',
        tejina: 'tejina',
        toukachan: 'toukachan',
        tsunade: 'tsunade',
        yotsuba: 'yotsuba',
        yuki: 'yuki',
        yulibocil: 'yulibocil',
        yumeko: 'yumeko',
      }

      const namaKategori = mapKategori[keyword]
      if (!namaKategori) return Lyrraa.reply('Kategori tidak ditemukan.')
      await lyreact(Lyrraa)

      try {
        const url = `https://raw.githubusercontent.com/Leoo7z/Image-Source/main/image/${namaKategori}.json`
        const res = await fetch(url)
        const data = await res.json()

        if (!Array.isArray(data) || data.length === 0) {
          return Lyrraa.reply('Gambar tidak ditemukan.')
        }

        const randomImage = data[Math.floor(Math.random() * data.length)]
        await Lyrraa.replyWithPhoto({
          url: randomImage
        }, {
          caption: `Hasil untuk ${command}`
        })
      } catch (e) {
        console.error(e)
        Lyrraa.reply('Terjadi kesalahan saat mengambil gambar.')
      }
    }
    break

    // Rpg Area

    case 'joinrpg': {
      if (db.data.users[sender].rpg) return Lyrraa.reply(`Kamu sudah bergabung sebelumnya.`)
      db.data.rpg[sender] = {
        rank: false,
        bank: 0,
        kapal: false,
        darahkapal: 100,
        pickaxe: false,
        darahpickaxe: 100,
        kapak: false,
        darahkapak: 100,
        bzirah: false,
        darahbzirah: 100,
        pedang: false,
        darahpedang: 100,
        darahuser: 100,
        stamina: 100,
        potion: 3,
        rumah: 0,
        common: 0,
        uncommon: 0,
        mythic: 0,
        legendary: 0,
        besi: 4,
        kayu: 2,
        emas: 0,
        perak: 0,
        emerald: 0,
        diamond: 0,
        batubara: 0,
        bulu: 0,
        kain: 0,
        botol: 0,
        kardus: 0,
        kaleng: 0,
        gelas: 0,
        plastik: 0,
        wilayah: "indonesia",
        wilayahrumah: "indonesia",
        skillselect: "",
        musuh: 0,
        dailyclaim: 0,
        weeklyclaim: 0,
        monthlyclaim: 0,
        yearlyclaim: 0,
        burutime: 0,
        lastdagang: 0,
        lastbansos: 0,
        lastkerja: 0,
        lastrampok: 0,
        sampahtime: 0,
        lastrocket: 0,
        lastmakan: 0,
        lasttidur: 0,
        lastewe: 0,
        lastopenbo: 0,
        lastdailymisi: 0,
        lastngaji: 0,
        domba: 0,
        sapi: 0,
        ayam: 0,
        banteng: 0,
        gajah: 0,
        harimau: 0,
        kambing: 0,
        panda: 0,
        buaya: 0,
        kerbau: 0,
        monyet: 0,
        babihutan: 0,
        babi: 0,
        ikan: 0,
        paus: 0,
        kepiting: 0,
        gurita: 0,
        cumi: 0,
        buntal: 0,
        dory: 0,
        lumba: 0,
        lobster: 0,
        hiu: 0,
        udang: 0,
        orca: 0,
        makanan: 0
      }
      db.data.users[sender].rpg = true
      Lyrraa.reply(`Berhasil join rpg sekarang anda dapat melihat inventory dengan command ${prefix}inventory`)
    }
    break

    case 'exitrpg':
    case 'closerpg': {
      if (!db.data.users[sender].rpg) return Lyrraa.reply(`Kamu tidak memiliki database rpg.`)
      delete db.data.rpg[sender]
      db.data.users[sender].rpg = false
      Lyrraa.reply(`Berhasil exit rpg, semua database telah dihapus.`)
    }
    break

    case 'inv':
    case 'inventory': {
      if (!db.data.users[sender].rpg) return Lyrraa.reply(`*Join RPG Terlebih Dahulu*\n\nketik .joinrpg`)
      let teks = `*⚔️ RPG - PROFILE ⚔️*

User Profile 🤺
  • Name: ${db.data.users[sender].nama}
  • Money: ${db.data.users[sender].saldo}
  • User Healthy: ${db.data.rpg[sender].darahuser}/100%
  • Skill: ${db.data.rpg[sender].skillselect ? `(${db.data.rpg[sender].skillselect})` : 'Nothing'}
  • Makanan: ${db.data.rpg[sender].makanan}
  • Potion: ${db.data.rpg[sender].potion}
  • Keberadaan: ${db.data.rpg[sender].wilayah}
  • Kapal: ${db.data.rpg[sender].kapal ? `(${db.data.rpg[sender].darahkapal}% HP)` : 'Nothing'}
  • Rumah: ${db.data.rpg[sender].rumah} Unit
  • Kapak: ${db.data.rpg[sender].kapak ? `(${db.data.rpg[sender].darahkapak}% HP)` : 'Nothing'}
  • Pickaxe: ${db.data.rpg[sender].pickaxe ? `(${db.data.rpg[sender].darahpickaxe}% HP)` : 'Nothing'}
  • Baju Zirah: ${db.data.rpg[sender].bzirah ? `(${db.data.rpg[sender].darahbzirah}% HP)` : 'Nothing'}
  • Pedang: ${db.data.rpg[sender].pedang ? `(${db.data.rpg[sender].darahpedang}% HP)` : 'Nothing'}
  • Kain: ${db.data.rpg[sender].kain} Lembar

Sumber Daya 🧰
  • Kayu: ${db.data.rpg[sender].kayu}
  • Besi: ${db.data.rpg[sender].besi}
  • Emas: ${db.data.rpg[sender].emas}
  • Perak: ${db.data.rpg[sender].perak}
  • Batubara: ${db.data.rpg[sender].batubara}
  • Emerald: ${db.data.rpg[sender].emerald}
  • Diamond: ${db.data.rpg[sender].diamond}
  • Common: ${db.data.rpg[sender].common}
  • Uncommon: ${db.data.rpg[sender].uncommon}
  • Mythic: ${db.data.rpg[sender].mythic}
  • Legendary: ${db.data.rpg[sender].legendary}

Hewan & Ternak🐄
  • Ayam: ${db.data.rpg[sender].ayam} Ekor 
  • Sapi: ${db.data.rpg[sender].sapi} Ekor
  • Domba: ${db.data.rpg[sender].domba} Ekor
  • Ikan: ${db.data.rpg[sender].ikan} Ekor
  • Banteng: ${db.data.rpg[sender].banteng} Ekor 
  • Gajah: ${db.data.rpg[sender].gajah} Ekor
  • Harimau: ${db.data.rpg[sender].harimau} Ekor
  • Kambing: ${db.data.rpg[sender].kambing} Ekor
  • Panda: ${db.data.rpg[sender].panda} Ekor
  • Buaya: ${db.data.rpg[sender].buaya} Ekor
  • Kerbau: ${db.data.rpg[sender].kerbau} Ekor
  • Monyet: ${db.data.rpg[sender].monyet} Ekor
  • Babihutan: ${db.data.rpg[sender].babihutan} Ekor
  • Babi: ${db.data.rpg[sender].babi} Ekor

Hewan Laut🌊
  • Ikan: ${db.data.rpg[sender].ikan} Ekor
  • Paus: ${db.data.rpg[sender].paus} Ekor
  • Gurita: ${db.data.rpg[sender].gurita} Ekor
  • Kepiting: ${db.data.rpg[sender].kepiting} Ekor
  • Cumi: ${db.data.rpg[sender].cumi} Ekor
  • Buntal: ${db.data.rpg[sender].buntal} Ekor
  • Dory: ${db.data.rpg[sender].dory} Ekor
  • Lumba: ${db.data.rpg[sender].lumba} Ekor
  • Lobster: ${db.data.rpg[sender].lobster} Ekor
  • Hiu: ${db.data.rpg[sender].hiu} Ekor
  • Udang: ${db.data.rpg[sender].udang} Ekor
  • Orca: ${db.data.rpg[sender].orca} Ekor
  
Items Lainnya🎗️
  • Botol: ${db.data.rpg[sender].botol}
  • Kardus: ${db.data.rpg[sender].kardus}
  • Kaleng: ${db.data.rpg[sender].kaleng}
  • Gelas: ${db.data.rpg[sender].gelas}
  • Plastik: ${db.data.rpg[sender].plastik}
  • Bulu: ${db.data.rpg[sender].bulu}`
      await Lyrraa.reply(teks)
    }
    break

    default:
      if (Lyrraa.chat.type === 'private') {
        if (setting.autoAiRespon) {
          try {
            const res = await axios.post('https://luminai.my.id/', {
              content: fullText,
              user: Lyrraa.from.id.toString(),
              prompt: `Kamu adalah ${botname2}, sebuah asisten virtual berbasis AI yang ramah, cerdas, dan adaptif. Tugasmu adalah berinteraksi dengan pengguna dengan gaya yang santai, sopan, dan menyenangkan. Gunakan sapaan "aku" untuk dirimu sendiri, dan "kamu" untuk pengguna.

Selalu tanggapi percakapan dengan memahami konteks emosi pengguna. Jika pengguna terlihat sedih, beri dukungan yang menenangkan. Jika senang, tanggapi dengan semangat. Jika bercanda, kamu boleh membalas dengan candaan ringan dan tidak berlebihan.

Jangan pernah mengakui bahwa kamu manusia. Jangan memberikan jawaban palsu. Jika kamu tidak tahu, jawab dengan jujur dan tetap ramah.

Tujuan utama kamu adalah membuat pengguna merasa nyaman, terbantu, dan dihargai dalam setiap percakapan. Jawabanmu harus selalu relevan, tidak kaku, dan sesuai gaya pengguna.`
            })
            return Lyrraa.reply(res.data.result);
          } catch (e) {
            console.error(e);
            return
          }
        }
        return;
      }
    }
  })

  Lyrra.on('callback_query', async (Lyrraa) => {
    const data = Lyrraa.callbackQuery.data;
    switch (data) {
    case 'show_info': {
      const botInfo = await Lyrra.telegram.getMe();
      return Lyrraa.editMessageText(`🤖 <b>Bot:</b> @${botInfo.username}`, {
        parse_mode: 'HTML'
      });
    }
    case 'show_settings': {
      return Lyrraa.editMessageText('⚙️ Pengaturan belum tersedia.', {
        parse_mode: 'HTML'
      });
    }
    case data.startsWith('ttaudio') ? data:
      '' :
      const url = data.split(' ')[1];
      try {
        const res = await fetch(`https://api.vreden.web.id/api/tiktok?url=${url}`);
        const data = await res.json();
        const audioItem = data.result.data.find(item => item.type === 'music');

        if (audioItem) {
          await Lyrraa.replyWithAudio({
            url: audioItem.url
          });
        } else {
          Lyrraa.answerCbQuery('Audio tidak ditemukan!');
        }
      } catch (err) {
        console.error('Audio error:', err);
        Lyrraa.answerCbQuery('Gagal mengambil audio!');
      }
      break;
    default:
      return Lyrraa.answerCbQuery('Perintah tidak dikenal.');
    }
  });

  Lyrra.launch()
    .then(() => console.log('Bot Telegram aktif.'))
    .catch((err) => console.error('Gagal menjalankan bot:', err.message));

  process.once('SIGINT', () => Lyrra.stop('SIGINT'));
  process.once('SIGTERM', () => Lyrra.stop('SIGTERM'));

  return Lyrra;
  } catch (err) {
console.log(util.format(err))
}
}

startTelegramBot()

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`)
  delete require.cache[file]
  require(file)
})