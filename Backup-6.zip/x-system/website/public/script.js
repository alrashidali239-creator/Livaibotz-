// 
async function loadUsers() {
  const userList = document.getElementById('user-list')
  userList.innerHTML = '<p>Loading users...</p>'

  try {
    const res = await fetch('/api')
    const data = await res.json()

    userList.innerHTML = ''

    data.forEach(user => {
      const card = document.createElement('div')
      card.className = 'user-card'
      card.innerHTML = `
        <img src="${user.image}" alt="${user.name}" />
        <h3>${user.name}</h3>
        <p>${user.email}</p>
      `
      userList.appendChild(card)
    })

  } catch (error) {
    userList.innerHTML = `<p style="color:red;">Failed to load users: ${error.message}</p>`
  }
}