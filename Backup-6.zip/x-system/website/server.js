require('@setting/settings')
const express = require('express')
const cors = require('cors')
const path = require('path')
const chalk = require('chalk')
const fs = require('fs')

async function localwebs() {
  if (localweb) {
    const app = express()
    // Port localhost random http://localhost:8693 < bagian angka
    const PORT = Math.floor(Math.random() * (9999 - 3000 + 1)) + 3000

    const users = [{
      id: 1,
      name: botname,
      owner: ownername,
      image: thumb
    }] // isi json api bisa kamu ganti atau pasang menggunakan scrape

    app.use(cors())

    // ini struktur buat api nya, contoh http://localhost:8693/api <
    app.get('/api', (req, res) => {
      res.json(users) // mengirim variabel users dengan hasil json
    })

    // menghubungkan ke folder isi web dari html, css, js, untuk tampilan web nya
    app.use(express.static(path.join(__dirname, 'public')))

    app.listen(PORT, () => {
      console.log(chalk.blue.bold(`Web Localhost Berhasil Terkoneksi Ke: http://localhost:${PORT}`))
    })
  }
}

localwebs()

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`)
  delete require.cache[file]
  require(file)
})